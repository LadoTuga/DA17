/*! Common */
if (
    ("undefined" == typeof window.Shopify && (window.Shopify = {}),
    (Shopify.bind = function (a, b) {
        return function () {
            return a.apply(b, arguments);
        };
    }),
    (Shopify.setSelectorByValue = function (a, b) {
        for (var c = 0, d = a.options.length; d > c; c++) {
            var e = a.options[c];
            if (b == e.value || b == e.innerHTML) return (a.selectedIndex = c), c;
        }
    }),
    (Shopify.addListener = function (a, b, c) {
        a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent("on" + b, c);
    }),
    (Shopify.postLink = function (a, b) {
        b = b || {};
        var c = b.method || "post",
            d = b.parameters || {},
            e = document.createElement("form");
        e.setAttribute("method", c), e.setAttribute("action", a);
        for (var f in d) {
            var g = document.createElement("input");
            g.setAttribute("type", "hidden"), g.setAttribute("name", f), g.setAttribute("value", d[f]), e.appendChild(g);
        }
        document.body.appendChild(e), e.submit(), document.body.removeChild(e);
    }),
    (Shopify.CountryProvinceSelector = function (a, b, c) {
        (this.countryEl = document.getElementById(a)),
            (this.provinceEl = document.getElementById(b)),
            (this.provinceContainer = document.getElementById(c.hideElement || b)),
            Shopify.addListener(this.countryEl, "change", Shopify.bind(this.countryHandler, this)),
            this.initCountry(),
            this.initProvince();
    }),
    (Shopify.CountryProvinceSelector.prototype = {
        initCountry: function () {
            var a = this.countryEl.getAttribute("data-default");
            Shopify.setSelectorByValue(this.countryEl, a), this.countryHandler();
        },
        initProvince: function () {
            var a = this.provinceEl.getAttribute("data-default");
            a && this.provinceEl.options.length > 0 && Shopify.setSelectorByValue(this.provinceEl, a);
        },
        countryHandler: function (a) {
            var b = this.countryEl.options[this.countryEl.selectedIndex],
                c = b.getAttribute("data-provinces"),
                d = JSON.parse(c);
            if ((this.clearOptions(this.provinceEl), d && 0 == d.length)) this.provinceContainer.style.display = "none";
            else {
                for (var e = 0; e < d.length; e++) {
                    var b = document.createElement("option");
                    (b.value = d[e][0]), (b.innerHTML = d[e][1]), this.provinceEl.appendChild(b);
                }
                this.provinceContainer.style.display = "";
            }
        },
        clearOptions: function (a) {
            for (; a.firstChild; ) a.removeChild(a.firstChild);
        },
        setOptions: function (a, b) {
            var c = 0;
            for (b.length; c < b.length; c++) {
                var d = document.createElement("option");
                (d.value = b[c]), (d.innerHTML = b[c]), a.appendChild(d);
            }
        },
    }),
    (Shopify.CustomerAddress = {
        toggleForm: function (a) {
            var b = document.getElementById("view_addresses"),
                c = document.getElementById("edit_address_" + a);
            return (b.style.display = "none" == b.style.display ? "" : "none"), (c.style.display = "none" == c.style.display ? "" : "none"), !1;
        },
        toggleNewForm: function () {
            var a = document.getElementById("add_address"),
                b = document.getElementById("address_tables");
            return (a.style.display = "none" == a.style.display ? "" : "none"), (b.style.display = "none" == a.style.display ? "" : "none"), !1;
        },
        destroy: function (a, b) {
            confirm(b || "Are you sure you wish to delete this address?") && Shopify.postLink("/account/addresses/" + a, { parameters: { _method: "delete" } });
        },
    }),
    (Shopify.queryParams = {}),
    location.search.length)
)
    for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split("&"); i < aCouples.length; i++)
        (aKeyValue = aCouples[i].split("=")), aKeyValue.length > 1 && (Shopify.queryParams[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]));
/*! Bootstrap  */
!(function (r) {
    "use strict";
    (r.fn.emulateTransitionEnd = function (n) {
        var t = !1,
            i = this;
        r(this).one("bsTransitionEnd", function () {
            t = !0;
        });
        return (
            setTimeout(function () {
                t || r(i).trigger(r.support.transition.end);
            }, n),
            this
        );
    }),
        r(function () {
            (r.support.transition = (function () {
                var n = document.createElement("bootstrap"),
                    t = { WebkitTransition: "webkitTransitionEnd", MozTransition: "transitionend", OTransition: "oTransitionEnd otransitionend", transition: "transitionend" };
                for (var i in t) if (void 0 !== n.style[i]) return { end: t[i] };
                return !1;
            })()),
                r.support.transition &&
                    (r.event.special.bsTransitionEnd = {
                        bindType: r.support.transition.end,
                        delegateType: r.support.transition.end,
                        handle: function (n) {
                            if (r(n.target).is(this)) return n.handleObj.handler.apply(this, arguments);
                        },
                    });
        });
})(jQuery);
!(function (t) {
    "function" == typeof define && define.amd ? define(["jquery"], t) : t("object" == typeof exports ? require("jquery") : jQuery);
})(function (t) {
    function e(e, i, n) {
        var i = { content: { message: "object" == typeof i ? i.message : i, title: i.title ? i.title : "", icon: i.icon ? i.icon : "", url: i.url ? i.url : "#", target: i.target ? i.target : "-" } };
        (n = t.extend(!0, {}, i, n)),
            (this.settings = t.extend(!0, {}, s, n)),
            (this._defaults = s),
            "-" == this.settings.content.target && (this.settings.content.target = this.settings.url_target),
            (this.animations = { start: "webkitAnimationStart oanimationstart MSAnimationStart animationstart", end: "webkitAnimationEnd oanimationend MSAnimationEnd animationend" }),
            "number" == typeof this.settings.offset && (this.settings.offset = { x: this.settings.offset, y: this.settings.offset }),
            this.init();
    }
    var s = {
        element: "body",
        position: null,
        type: "info",
        allow_dismiss: !0,
        newest_on_top: !1,
        placement: { from: "top", align: "right" },
        offset: 20,
        spacing: 10,
        z_index: 2031,
        delay: 5e3,
        timer: 1e3,
        url_target: "_blank",
        mouse_over: null,
        animate: { enter: "animated fadeInDown", exit: "animated fadeOutUp" },
        onShow: null,
        onShown: null,
        onClose: null,
        onClosed: null,
        icon_type: "class",
        template:
            '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert"><button type="button" aria-hidden="true" class="close" data-notify="dismiss">&times;</button><span data-notify="icon"></span> <span data-notify="title">{1}</span> <span data-notify="message">{2}</span><div class="progress" data-notify="progressbar"><div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div></div><a href="{3}" target="{4}" data-notify="url"></a></div>',
    };
    (String.format = function () {
        for (var t = arguments[0], e = 1; e < arguments.length; e++) t = t.replace(RegExp("\\{" + (e - 1) + "\\}", "gm"), arguments[e]);
        return t;
    }),
        t.extend(e.prototype, {
            init: function () {
                var t = this;
                this.buildNotify(),
                    this.settings.content.icon && this.setIcon(),
                    "#" != this.settings.content.url && this.styleURL(),
                    this.placement(),
                    this.bind(),
                    (this.notify = {
                        $ele: this.$ele,
                        update: function (e, s) {
                            switch (e) {
                                case "type":
                                    this.$ele.removeClass("alert-" + t.settings.type),
                                        this.$ele.find('[data-notify="progressbar"] > .progress-bar').removeClass("progress-bar-" + t.settings.type),
                                        (t.settings.type = s),
                                        this.$ele
                                            .addClass("alert-" + s)
                                            .find('[data-notify="progressbar"] > .progress-bar')
                                            .addClass("progress-bar-" + s);
                                    break;
                                case "icon":
                                    var i = this.$ele.find('[data-notify="icon"]');
                                    "class" == t.settings.icon_type.toLowerCase() ? i.removeClass(t.settings.content.icon).addClass(s) : (i.is("img") || i.find("img"), i.attr("src", s));
                                    break;
                                case "url":
                                    this.$ele.find('[data-notify="url"]').attr("href", s);
                                    break;
                                case "target":
                                    this.$ele.find('[data-notify="url"]').attr("target", s);
                                    break;
                                default:
                                    this.$ele.find('[data-notify="' + e + '"]').html(s);
                            }
                            var n = this.$ele.outerHeight() + parseInt(t.settings.spacing) + parseInt(t.settings.offset.y);
                            t.reposition(n);
                        },
                        close: function () {
                            t.close();
                        },
                    });
            },
            buildNotify: function () {
                var e = this.settings.content;
                (this.$ele = t(String.format(this.settings.template, this.settings.type, e.title, e.message, e.url, e.target))),
                    this.$ele.attr("data-notify-position", this.settings.placement.from + "-" + this.settings.placement.align),
                    this.settings.allow_dismiss || this.$ele.find('[data-notify="dismiss"]').css("display", "none"),
                    this.settings.delay <= 0 && this.$ele.find('[data-notify="progressbar"]').remove();
            },
            setIcon: function () {
                "class" == this.settings.icon_type.toLowerCase()
                    ? this.$ele.find('[data-notify="icon"]').addClass(this.settings.content.icon)
                    : this.$ele.find('[data-notify="icon"]').is("img")
                    ? this.$ele.find('[data-notify="icon"]').attr("src", this.settings.content.icon)
                    : this.$ele.find('[data-notify="icon"]').append('<img src="' + this.settings.content.icon + '" alt="Notify Icon" />');
            },
            styleURL: function () {
                this.$ele
                    .find('[data-notify="url"]')
                    .css({
                        backgroundImage: "url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)",
                        height: "100%",
                        left: "0px",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                        zIndex: this.settings.z_index + 1,
                    }),
                    this.$ele.find('[data-notify="dismiss"]').css({ position: "absolute", right: "10px", top: "5px", zIndex: this.settings.z_index + 2 });
            },
            placement: function () {
                var e = this,
                    s = this.settings.offset.y,
                    i = {
                        display: "inline-block",
                        margin: "0px auto",
                        position: this.settings.position ? this.settings.position : "body" === this.settings.element ? "fixed" : "absolute",
                        transition: "all .5s ease-in-out",
                        zIndex: this.settings.z_index,
                    },
                    n = !1,
                    a = this.settings;
                switch (
                    (t('[data-notify-position="' + this.settings.placement.from + "-" + this.settings.placement.align + '"]:not([data-closing="true"])').each(function () {
                        return (s = Math.max(s, parseInt(t(this).css(a.placement.from)) + parseInt(t(this).outerHeight()) + parseInt(a.spacing)));
                    }),
                    1 == this.settings.newest_on_top && (s = this.settings.offset.y),
                    (i[this.settings.placement.from] = s + "px"),
                    this.settings.placement.align)
                ) {
                    case "left":
                    case "right":
                        i[this.settings.placement.align] = this.settings.offset.x + "px";
                        break;
                    case "center":
                        (i.left = 0), (i.right = 0);
                }
                this.$ele.css(i).addClass(this.settings.animate.enter),
                    t(this.settings.element).append(this.$ele),
                    1 == this.settings.newest_on_top && ((s = parseInt(s) + parseInt(this.settings.spacing) + this.$ele.outerHeight()), this.reposition(s)),
                    t.isFunction(e.settings.onShow) && e.settings.onShow.call(this.$ele),
                    this.$ele
                        .one(this.animations.start, function () {
                            n = !0;
                        })
                        .one(this.animations.end, function () {
                            t.isFunction(e.settings.onShown) && e.settings.onShown.call(this);
                        }),
                    setTimeout(function () {
                        n || (t.isFunction(e.settings.onShown) && e.settings.onShown.call(this));
                    }, 600);
            },
            bind: function () {
                var e = this;
                if (
                    (this.$ele.find('[data-notify="dismiss"]').on("click", function () {
                        e.close();
                    }),
                    this.$ele
                        .mouseover(function () {
                            t(this).data("data-hover", "true");
                        })
                        .mouseout(function () {
                            t(this).data("data-hover", "false");
                        }),
                    this.$ele.data("data-hover", "false"),
                    this.settings.delay > 0)
                ) {
                    e.$ele.data("notify-delay", e.settings.delay);
                    var s = setInterval(function () {
                        var t = parseInt(e.$ele.data("notify-delay")) - e.settings.timer;
                        if (("false" === e.$ele.data("data-hover") && "pause" == e.settings.mouse_over) || "pause" != e.settings.mouse_over) {
                            var i = ((e.settings.delay - t) / e.settings.delay) * 100;
                            e.$ele.data("notify-delay", t),
                                e.$ele
                                    .find('[data-notify="progressbar"] > div')
                                    .attr("aria-valuenow", i)
                                    .css("width", i + "%");
                        }
                        t <= -e.settings.timer && (clearInterval(s), e.close());
                    }, e.settings.timer);
                }
            },
            close: function () {
                var e = this,
                    s = parseInt(this.$ele.css(this.settings.placement.from)),
                    i = !1;
                this.$ele.data("closing", "true").addClass(this.settings.animate.exit),
                    e.reposition(s),
                    t.isFunction(e.settings.onClose) && e.settings.onClose.call(this.$ele),
                    this.$ele
                        .one(this.animations.start, function () {
                            i = !0;
                        })
                        .one(this.animations.end, function () {
                            t(this).remove(), t.isFunction(e.settings.onClosed) && e.settings.onClosed.call(this);
                        }),
                    setTimeout(function () {
                        i || (e.$ele.remove(), e.settings.onClosed && e.settings.onClosed(e.$ele));
                    }, 600);
            },
            reposition: function (e) {
                var s = this,
                    i = '[data-notify-position="' + this.settings.placement.from + "-" + this.settings.placement.align + '"]:not([data-closing="true"])',
                    n = this.$ele.nextAll(i);
                1 == this.settings.newest_on_top && (n = this.$ele.prevAll(i)),
                    n.each(function () {
                        t(this).css(s.settings.placement.from, e), (e = parseInt(e) + parseInt(s.settings.spacing) + t(this).outerHeight());
                    });
            },
        }),
        (t.notify = function (t, s) {
            var i = new e(this, t, s);
            return i.notify;
        }),
        (t.notifyDefaults = function (e) {
            return (s = t.extend(!0, {}, s, e));
        }),
        (t.notifyClose = function (e) {
            "undefined" == typeof e || "all" == e
                ? t("[data-notify]").find('[data-notify="dismiss"]').trigger("click")
                : t('[data-notify-position="' + e + '"]')
                      .find('[data-notify="dismiss"]')
                      .trigger("click");
        });
});
/*! Others */
!(function (n, e) {
    "function" == typeof define && define.amd ? define(e) : "object" == typeof exports ? (module.exports = e()) : (n.NProgress = e());
})(this, function () {
    function n(n, e, t) {
        return e > n ? e : n > t ? t : n;
    }
    function e(n) {
        return 100 * (-1 + n);
    }
    function t(n, t, r) {
        var i;
        return (
            (i = "translate3d" === c.positionUsing ? { transform: "translate3d(" + e(n) + "%,0,0)" } : "translate" === c.positionUsing ? { transform: "translate(" + e(n) + "%,0)" } : { "margin-left": e(n) + "%" }),
            (i.transition = "all " + t + "ms " + r),
            i
        );
    }
    function r(n, e) {
        var t = "string" == typeof n ? n : s(n);
        return t.indexOf(" " + e + " ") >= 0;
    }
    function i(n, e) {
        var t = s(n),
            i = t + e;
        r(t, e) || (n.className = i.substring(1));
    }
    function o(n, e) {
        var t,
            i = s(n);
        r(n, e) && ((t = i.replace(" " + e + " ", " ")), (n.className = t.substring(1, t.length - 1)));
    }
    function s(n) {
        return (" " + ((n && n.className) || "") + " ").replace(/\s+/gi, " ");
    }
    function a(n) {
        n && n.parentNode && n.parentNode.removeChild(n);
    }
    var u = {};
    u.version = "0.2.0";
    var c = (u.settings = {
        minimum: 0.08,
        easing: "linear",
        positionUsing: "",
        speed: 350,
        trickle: !0,
        trickleSpeed: 250,
        showSpinner: !0,
        barSelector: '[role="bar"]',
        spinnerSelector: '[role="spinner"]',
        parent: "body",
        template: '<div class="bar" role="bar"><div class="peg"></div></div><div class="spinner" role="spinner"><div class="spinner-icon"></div></div>',
    });
    (u.configure = function (n) {
        var e, t;
        for (e in n) (t = n[e]), void 0 !== t && n.hasOwnProperty(e) && (c[e] = t);
        return this;
    }),
        (u.status = null),
        (u.set = function (e) {
            var r = u.isStarted();
            (e = n(e, c.minimum, 1)), (u.status = 1 === e ? null : e);
            var i = u.render(!r),
                o = i.querySelector(c.barSelector),
                s = c.speed,
                a = c.easing;
            return (
                i.offsetWidth,
                l(function (n) {
                    "" === c.positionUsing && (c.positionUsing = u.getPositioningCSS()),
                        d(o, t(e, s, a)),
                        1 === e
                            ? (d(i, { transition: "none", opacity: 1 }),
                              i.offsetWidth,
                              setTimeout(function () {
                                  d(i, { transition: "all " + s + "ms linear", opacity: 0 }),
                                      setTimeout(function () {
                                          u.remove(), n();
                                      }, s);
                              }, s))
                            : setTimeout(n, s);
                }),
                this
            );
        }),
        (u.isStarted = function () {
            return "number" == typeof u.status;
        }),
        (u.start = function () {
            u.status || u.set(0);
            var n = function () {
                setTimeout(function () {
                    u.status && (u.trickle(), n());
                }, c.trickleSpeed);
            };
            return c.trickle && n(), this;
        }),
        (u.done = function (n) {
            return n || u.status ? u.inc(0.3 + 0.5 * Math.random()).set(1) : this;
        }),
        (u.inc = function (e) {
            var t = u.status;
            return t
                ? t > 1
                    ? void 0
                    : ("number" != typeof e &&
                          (e = t >= 0 && 0.25 > t ? (3 * Math.random() + 3) / 100 : t >= 0.25 && 0.65 > t ? (3 * Math.random()) / 100 : t >= 0.65 && 0.9 > t ? (2 * Math.random()) / 100 : t >= 0.9 && 0.99 > t ? 0.005 : 0),
                      (t = n(t + e, 0, 0.994)),
                      u.set(t))
                : u.start();
        }),
        (u.trickle = function () {
            return u.inc();
        }),
        (function () {
            var n = 0,
                e = 0;
            u.promise = function (t) {
                return t && "resolved" !== t.state()
                    ? (0 === e && u.start(),
                      n++,
                      e++,
                      t.always(function () {
                          e--, 0 === e ? ((n = 0), u.done()) : u.set((n - e) / n);
                      }),
                      this)
                    : this;
            };
        })(),
        (u.render = function (n) {
            if (u.isRendered()) return document.getElementById("nprogress");
            i(document.documentElement, "nprogress-busy");
            var t = document.createElement("div");
            (t.id = "nprogress"), (t.innerHTML = c.template);
            var r,
                o = t.querySelector(c.barSelector),
                s = n ? "-100" : e(u.status || 0),
                l = document.querySelector(c.parent);
            return (
                d(o, { transition: "all 0 linear", transform: "translate3d(" + s + "%,0,0)" }),
                c.showSpinner || ((r = t.querySelector(c.spinnerSelector)), r && a(r)),
                l != document.body && i(l, "nprogress-custom-parent"),
                l.appendChild(t),
                t
            );
        }),
        (u.remove = function () {
            o(document.documentElement, "nprogress-busy"), i(document.documentElement, "nprogress-done"), o(document.querySelector(c.parent), "nprogress-custom-parent");
            var n = document.getElementById("nprogress");
            n && a(n);
        }),
        (u.isRendered = function () {
            return !!document.getElementById("nprogress");
        }),
        (u.getPositioningCSS = function () {
            var n = document.body.style,
                e = "WebkitTransform" in n ? "Webkit" : "MozTransform" in n ? "Moz" : "msTransform" in n ? "ms" : "OTransform" in n ? "O" : "";
            return e + "Perspective" in n ? "translate3d" : e + "Transform" in n ? "translate" : "margin";
        });
    var l = (function () {
            function n() {
                var t = e.shift();
                t && t(n);
            }
            var e = [];
            return function (t) {
                e.push(t), 1 == e.length && n();
            };
        })(),
        d = (function () {
            function n(n) {
                return n.replace(/^-ms-/, "ms-").replace(/-([\da-z])/gi, function (n, e) {
                    return e.toUpperCase();
                });
            }
            function e(n) {
                var e = document.body.style;
                if (n in e) return n;
                for (var t, r = i.length, o = n.charAt(0).toUpperCase() + n.slice(1); r--; ) if (((t = i[r] + o), t in e)) return t;
                return n;
            }
            function t(t) {
                return (t = n(t)), o[t] || (o[t] = e(t));
            }
            function r(n, e, r) {
                (e = t(e)), (n.style[e] = r);
            }
            var i = ["Webkit", "O", "Moz", "ms"],
                o = {};
            return function (n, e) {
                var t,
                    i,
                    o = arguments;
                if (2 == o.length) for (t in e) (i = e[t]), void 0 !== i && e.hasOwnProperty(t) && r(n, t, i);
                else r(n, o[1], o[2]);
            };
        })();
    return u;
});
!(function (a, b) {
    "function" == typeof define && define.amd ? define(["jquery"], b) : b(a.jQuery);
})(this, function (a) {
    "use strict";
    function e(d, e) {
        (this.element = d), (this.$element = a(this.element)), (this.options = a.extend({}, c, e)), (this._defaults = c), (this._name = b), this.init();
    }
    var b = "scrolly",
        c = { bgParallax: !1 };
    (e.prototype.init = function () {
        var b = this;
        (this.startPosition = this.$element.position().top),
            (this.offsetTop = this.$element.offset().top),
            (this.height = this.$element.outerHeight(!0)),
            (this.velocity = this.$element.attr("data-velocity")),
            (this.bgStart = parseInt(this.$element.attr("data-fit"), 10)),
            a(document).scroll(function () {
                b.didScroll = !0;
            }),
            setInterval(function () {
                b.didScroll && ((b.didScroll = !1), b.scrolly());
            }, 10);
    }),
        (e.prototype.scrolly = function () {
            var b = a(window).scrollTop(),
                c = a(window).height(),
                d = this.startPosition;
            this.offsetTop >= b + c
                ? this.$element.addClass("scrolly-invisible")
                : (d = this.$element.hasClass("scrolly-invisible") ? this.startPosition + (b + (c - this.offsetTop)) * this.velocity : this.startPosition + b * this.velocity),
                this.bgStart && (d += this.bgStart),
                this.options.bgParallax === !0 ? this.$element.css({ backgroundPosition: "50% " + d + "px" }) : this.$element.css({ top: d });
        }),
        (a.fn[b] = function (c) {
            return this.each(function () {
                a.data(this, "plugin_" + b) || a.data(this, "plugin_" + b, new e(this, c));
            });
        });
});
!(function (a, b) {
    "function" == typeof define && define.amd
        ? define(function () {
              return b(a);
          })
        : "object" == typeof exports
        ? (module.exports = b)
        : (a.echo = b(a));
})(this, function (a) {
    "use strict";
    var b,
        c,
        d,
        e,
        f,
        g = {},
        h = function () {},
        i = function (a) {
            return null === a.offsetParent;
        },
        j = function (a, b) {
            if (i(a)) return !1;
            var c = a.getBoundingClientRect();
            return c.right >= b.l && c.bottom >= b.t && c.left <= b.r && c.top <= b.b;
        },
        k = function () {
            (!e && c) ||
                (clearTimeout(c),
                (c = setTimeout(function () {
                    g.render(), (c = null);
                }, d)));
        };
    return (
        (g.init = function (c) {
            c = c || {};
            var i = c.offset || 0,
                j = c.offsetVertical || i,
                l = c.offsetHorizontal || i,
                m = function (a, b) {
                    return parseInt(a || b, 10);
                };
            (b = { t: m(c.offsetTop, j), b: m(c.offsetBottom, j), l: m(c.offsetLeft, l), r: m(c.offsetRight, l) }),
                (d = m(c.throttle, 250)),
                (e = c.debounce !== !1),
                (f = !!c.unload),
                (h = c.callback || h),
                g.render(),
                document.addEventListener ? (a.addEventListener("scroll", k, !1), a.addEventListener("load", k, !1)) : (a.attachEvent("onscroll", k), a.attachEvent("onload", k));
        }),
        (g.render = function () {
            for (
                var c,
                    d,
                    e = document.querySelectorAll("img[data-echo], [data-echo-background]"),
                    i = e.length,
                    k = { l: 0 - b.l, t: 0 - b.t, b: (a.innerHeight || document.documentElement.clientHeight) + b.b, r: (a.innerWidth || document.documentElement.clientWidth) + b.r },
                    l = 0;
                l < i;
                l++
            )
                (d = e[l]),
                    j(d, k)
                        ? (f && d.setAttribute("data-echo-placeholder", d.src),
                          null !== d.getAttribute("data-echo-background") ? (d.style.backgroundImage = "url(" + d.getAttribute("data-echo-background") + ")") : (d.src = d.getAttribute("data-echo")),
                          f || (d.removeAttribute("data-echo"), d.removeAttribute("data-echo-background")),
                          h(d, "load"))
                        : f &&
                          (c = d.getAttribute("data-echo-placeholder")) &&
                          (null !== d.getAttribute("data-echo-background") ? (d.style.backgroundImage = "url(" + c + ")") : (d.src = c), d.removeAttribute("data-echo-placeholder"), h(d, "unload"));
            i || g.detach();
        }),
        (g.detach = function () {
            document.removeEventListener ? a.removeEventListener("scroll", k) : a.detachEvent("onscroll", k), clearTimeout(c);
        }),
        g
    );
}),
    echo.init({ offset: 100, throttle: 200, unload: !1, callback: function (a, b) {} }),
    setInterval(function () {
        echo.render();
    }, 800);
!(function (a, b, c, d) {
    function e(b, c) {
        (this.settings = null),
            (this.options = a.extend({}, e.Defaults, c)),
            (this.$element = a(b)),
            (this._handlers = {}),
            (this._plugins = {}),
            (this._supress = {}),
            (this._current = null),
            (this._speed = null),
            (this._coordinates = []),
            (this._breakpoint = null),
            (this._width = null),
            (this._items = []),
            (this._clones = []),
            (this._mergers = []),
            (this._widths = []),
            (this._invalidated = {}),
            (this._pipe = []),
            (this._drag = { time: null, target: null, pointer: null, stage: { start: null, current: null }, direction: null }),
            (this._states = { current: {}, tags: { initializing: ["busy"], animating: ["busy"], dragging: ["interacting"] } }),
            a.each(
                ["onResize", "onThrottledResize"],
                a.proxy(function (b, c) {
                    this._handlers[c] = a.proxy(this[c], this);
                }, this)
            ),
            a.each(
                e.Plugins,
                a.proxy(function (a, b) {
                    this._plugins[a.charAt(0).toLowerCase() + a.slice(1)] = new b(this);
                }, this)
            ),
            a.each(
                e.Workers,
                a.proxy(function (b, c) {
                    this._pipe.push({ filter: c.filter, run: a.proxy(c.run, this) });
                }, this)
            ),
            this.setup(),
            this.initialize();
    }
    (e.Defaults = {
        items: 3,
        loop: !1,
        center: !1,
        rewind: !1,
        checkVisibility: !0,
        mouseDrag: !0,
        touchDrag: !0,
        pullDrag: !0,
        freeDrag: !1,
        margin: 0,
        stagePadding: 0,
        merge: !1,
        mergeFit: !0,
        autoWidth: !1,
        startPosition: 0,
        rtl: !1,
        smartSpeed: 250,
        fluidSpeed: !1,
        dragEndSpeed: !1,
        responsive: {},
        responsiveRefreshRate: 200,
        responsiveBaseElement: b,
        fallbackEasing: "swing",
        slideTransition: "",
        info: !1,
        nestedItemSelector: !1,
        itemElement: "div",
        stageElement: "div",
        refreshClass: "owl-refresh",
        loadedClass: "owl-loaded owl-carousel owl-theme",
        loadingClass: "owl-loading",
        rtlClass: "owl-rtl",
        responsiveClass: "owl-responsive",
        dragClass: "owl-drag",
        itemClass: "owl-item",
        stageClass: "owl-stage",
        stageOuterClass: "owl-stage-outer",
        grabClass: "owl-grab",
    }),
        (e.Width = { Default: "default", Inner: "inner", Outer: "outer" }),
        (e.Type = { Event: "event", State: "state" }),
        (e.Plugins = {}),
        (e.Workers = [
            {
                filter: ["width", "settings"],
                run: function () {
                    this._width = this.$element.width();
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function (a) {
                    a.current = this._items && this._items[this.relative(this._current)];
                },
            },
            {
                filter: ["items", "settings"],
                run: function () {
                    this.$stage.children(".cloned").remove();
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function (a) {
                    var b = this.settings.margin || "",
                        c = !this.settings.autoWidth,
                        d = this.settings.rtl,
                        e = { width: "auto", "margin-left": d ? b : "", "margin-right": d ? "" : b };
                    !c && this.$stage.children().css(e), (a.css = e);
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function (a) {
                    var b = (this.width() / this.settings.items).toFixed(3) - this.settings.margin,
                        c = null,
                        d = this._items.length,
                        e = !this.settings.autoWidth,
                        f = [];
                    for (a.items = { merge: !1, width: b }; d--; )
                        (c = this._mergers[d]), (c = (this.settings.mergeFit && Math.min(c, this.settings.items)) || c), (a.items.merge = c > 1 || a.items.merge), (f[d] = e ? b * c : this._items[d].width());
                    this._widths = f;
                },
            },
            {
                filter: ["items", "settings"],
                run: function () {
                    var b = [],
                        c = this._items,
                        d = this.settings,
                        e = Math.max(2 * d.items, 4),
                        f = 2 * Math.ceil(c.length / 2),
                        g = d.loop && c.length ? (d.rewind ? e : Math.max(e, f)) : 0,
                        h = "",
                        i = "";
                    for (g /= 2; g > 0; ) b.push(this.normalize(b.length / 2, !0)), (h += c[b[b.length - 1]][0].outerHTML), b.push(this.normalize(c.length - 1 - (b.length - 1) / 2, !0)), (i = c[b[b.length - 1]][0].outerHTML + i), (g -= 1);
                    (this._clones = b), a(h).addClass("cloned").appendTo(this.$stage), a(i).addClass("cloned").prependTo(this.$stage);
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function () {
                    for (var a = this.settings.rtl ? 1 : -1, b = this._clones.length + this._items.length, c = -1, d = 0, e = 0, f = []; ++c < b; )
                        (d = f[c - 1] || 0), (e = this._widths[this.relative(c)] + this.settings.margin), f.push(d + e * a);
                    this._coordinates = f;
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function () {
                    var a = this.settings.stagePadding,
                        b = this._coordinates,
                        c = { width: Math.ceil(Math.abs(b[b.length - 1])) + 2 * a, "padding-left": a || "", "padding-right": a || "" };
                    this.$stage.css(c);
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function (a) {
                    var b = this._coordinates.length,
                        c = !this.settings.autoWidth,
                        d = this.$stage.children();
                    if (c && a.items.merge) for (; b--; ) (a.css.width = this._widths[this.relative(b)]), d.eq(b).css(a.css);
                    else c && ((a.css.width = a.items.width), d.css(a.css));
                },
            },
            {
                filter: ["items"],
                run: function () {
                    this._coordinates.length < 1 && this.$stage.removeAttr("style");
                },
            },
            {
                filter: ["width", "items", "settings"],
                run: function (a) {
                    (a.current = a.current ? this.$stage.children().index(a.current) : 0), (a.current = Math.max(this.minimum(), Math.min(this.maximum(), a.current))), this.reset(a.current);
                },
            },
            {
                filter: ["position"],
                run: function () {
                    this.animate(this.coordinates(this._current));
                },
            },
            {
                filter: ["width", "position", "items", "settings"],
                run: function () {
                    var a,
                        b,
                        c,
                        d,
                        e = this.settings.rtl ? 1 : -1,
                        f = 2 * this.settings.stagePadding,
                        g = this.coordinates(this.current()) + f,
                        h = g + this.width() * e,
                        i = [];
                    for (c = 0, d = this._coordinates.length; c < d; c++)
                        (a = this._coordinates[c - 1] || 0), (b = Math.abs(this._coordinates[c]) + f * e), ((this.op(a, "<=", g) && this.op(a, ">", h)) || (this.op(b, "<", g) && this.op(b, ">", h))) && i.push(c);
                    this.$stage.children(".active").removeClass("active"),
                        this.$stage.children(":eq(" + i.join("), :eq(") + ")").addClass("active"),
                        this.$stage.children(".center").removeClass("center"),
                        this.settings.center && this.$stage.children().eq(this.current()).addClass("center");
                },
            },
        ]),
        (e.prototype.initializeStage = function () {
            (this.$stage = this.$element.find("." + this.settings.stageClass)),
                this.$stage.length ||
                    (this.$element.addClass(this.options.loadingClass),
                    (this.$stage = a("<" + this.settings.stageElement + ">", { class: this.settings.stageClass }).wrap(a("<div/>", { class: this.settings.stageOuterClass }))),
                    this.$element.append(this.$stage.parent()));
        }),
        (e.prototype.initializeItems = function () {
            var b = this.$element.find(".owl-item");
            if (b.length)
                return (
                    (this._items = b.get().map(function (b) {
                        return a(b);
                    })),
                    (this._mergers = this._items.map(function () {
                        return 1;
                    })),
                    void this.refresh()
                );
            this.replace(this.$element.children().not(this.$stage.parent())), this.isVisible() ? this.refresh() : this.invalidate("width"), this.$element.removeClass(this.options.loadingClass).addClass(this.options.loadedClass);
        }),
        (e.prototype.initialize = function () {
            if ((this.enter("initializing"), this.trigger("initialize"), this.$element.toggleClass(this.settings.rtlClass, this.settings.rtl), this.settings.autoWidth && !this.is("pre-loading"))) {
                var a, b, c;
                (a = this.$element.find("img")), (b = this.settings.nestedItemSelector ? "." + this.settings.nestedItemSelector : d), (c = this.$element.children(b).width()), a.length && c <= 0 && this.preloadAutoWidthImages(a);
            }
            this.initializeStage(), this.initializeItems(), this.registerEventHandlers(), this.leave("initializing"), this.trigger("initialized");
        }),
        (e.prototype.isVisible = function () {
            return !this.settings.checkVisibility || this.$element.is(":visible");
        }),
        (e.prototype.setup = function () {
            var b = this.viewport(),
                c = this.options.responsive,
                d = -1,
                e = null;
            c
                ? (a.each(c, function (a) {
                      a <= b && a > d && (d = Number(a));
                  }),
                  (e = a.extend({}, this.options, c[d])),
                  "function" == typeof e.stagePadding && (e.stagePadding = e.stagePadding()),
                  delete e.responsive,
                  e.responsiveClass && this.$element.attr("class", this.$element.attr("class").replace(new RegExp("(" + this.options.responsiveClass + "-)\\S+\\s", "g"), "$1" + d)))
                : (e = a.extend({}, this.options)),
                this.trigger("change", { property: { name: "settings", value: e } }),
                (this._breakpoint = d),
                (this.settings = e),
                this.invalidate("settings"),
                this.trigger("changed", { property: { name: "settings", value: this.settings } });
        }),
        (e.prototype.optionsLogic = function () {
            this.settings.autoWidth && ((this.settings.stagePadding = !1), (this.settings.merge = !1));
        }),
        (e.prototype.prepare = function (b) {
            var c = this.trigger("prepare", { content: b });
            return (
                c.data ||
                    (c.data = a("<" + this.settings.itemElement + "/>")
                        .addClass(this.options.itemClass)
                        .append(b)),
                this.trigger("prepared", { content: c.data }),
                c.data
            );
        }),
        (e.prototype.update = function () {
            for (
                var b = 0,
                    c = this._pipe.length,
                    d = a.proxy(function (a) {
                        return this[a];
                    }, this._invalidated),
                    e = {};
                b < c;

            )
                (this._invalidated.all || a.grep(this._pipe[b].filter, d).length > 0) && this._pipe[b].run(e), b++;
            (this._invalidated = {}), !this.is("valid") && this.enter("valid");
        }),
        (e.prototype.width = function (a) {
            switch ((a = a || e.Width.Default)) {
                case e.Width.Inner:
                case e.Width.Outer:
                    return this._width;
                default:
                    return this._width - 2 * this.settings.stagePadding + this.settings.margin;
            }
        }),
        (e.prototype.refresh = function () {
            this.enter("refreshing"),
                this.trigger("refresh"),
                this.setup(),
                this.optionsLogic(),
                this.$element.addClass(this.options.refreshClass),
                this.update(),
                this.$element.removeClass(this.options.refreshClass),
                this.leave("refreshing"),
                this.trigger("refreshed");
        }),
        (e.prototype.onThrottledResize = function () {
            b.clearTimeout(this.resizeTimer), (this.resizeTimer = b.setTimeout(this._handlers.onResize, this.settings.responsiveRefreshRate));
        }),
        (e.prototype.onResize = function () {
            return (
                !!this._items.length &&
                this._width !== this.$element.width() &&
                !!this.isVisible() &&
                (this.enter("resizing"), this.trigger("resize").isDefaultPrevented() ? (this.leave("resizing"), !1) : (this.invalidate("width"), this.refresh(), this.leave("resizing"), void this.trigger("resized")))
            );
        }),
        (e.prototype.registerEventHandlers = function () {
            a.support.transition && this.$stage.on(a.support.transition.end + ".owl.core", a.proxy(this.onTransitionEnd, this)),
                !1 !== this.settings.responsive && this.on(b, "resize", this._handlers.onThrottledResize),
                this.settings.mouseDrag &&
                    (this.$element.addClass(this.options.dragClass),
                    this.$stage.on("mousedown.owl.core", a.proxy(this.onDragStart, this)),
                    this.$stage.on("dragstart.owl.core selectstart.owl.core", function () {
                        return !1;
                    })),
                this.settings.touchDrag && (this.$stage.on("touchstart.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("touchcancel.owl.core", a.proxy(this.onDragEnd, this)));
        }),
        (e.prototype.onDragStart = function (b) {
            var d = null;
            3 !== b.which &&
                (a.support.transform
                    ? ((d = this.$stage
                          .css("transform")
                          .replace(/.*\(|\)| /g, "")
                          .split(",")),
                      (d = { x: d[16 === d.length ? 12 : 4], y: d[16 === d.length ? 13 : 5] }))
                    : ((d = this.$stage.position()), (d = { x: this.settings.rtl ? d.left + this.$stage.width() - this.width() + this.settings.margin : d.left, y: d.top })),
                this.is("animating") && (a.support.transform ? this.animate(d.x) : this.$stage.stop(), this.invalidate("position")),
                this.$element.toggleClass(this.options.grabClass, "mousedown" === b.type),
                this.speed(0),
                (this._drag.time = new Date().getTime()),
                (this._drag.target = a(b.target)),
                (this._drag.stage.start = d),
                (this._drag.stage.current = d),
                (this._drag.pointer = this.pointer(b)),
                a(c).on("mouseup.owl.core touchend.owl.core", a.proxy(this.onDragEnd, this)),
                a(c).one(
                    "mousemove.owl.core touchmove.owl.core",
                    a.proxy(function (b) {
                        var d = this.difference(this._drag.pointer, this.pointer(b));
                        a(c).on("mousemove.owl.core touchmove.owl.core", a.proxy(this.onDragMove, this)), (Math.abs(d.x) < Math.abs(d.y) && this.is("valid")) || (b.preventDefault(), this.enter("dragging"), this.trigger("drag"));
                    }, this)
                ));
        }),
        (e.prototype.onDragMove = function (a) {
            var b = null,
                c = null,
                d = null,
                e = this.difference(this._drag.pointer, this.pointer(a)),
                f = this.difference(this._drag.stage.start, e);
            this.is("dragging") &&
                (a.preventDefault(),
                this.settings.loop
                    ? ((b = this.coordinates(this.minimum())), (c = this.coordinates(this.maximum() + 1) - b), (f.x = ((((f.x - b) % c) + c) % c) + b))
                    : ((b = this.settings.rtl ? this.coordinates(this.maximum()) : this.coordinates(this.minimum())),
                      (c = this.settings.rtl ? this.coordinates(this.minimum()) : this.coordinates(this.maximum())),
                      (d = this.settings.pullDrag ? (-1 * e.x) / 5 : 0),
                      (f.x = Math.max(Math.min(f.x, b + d), c + d))),
                (this._drag.stage.current = f),
                this.animate(f.x));
        }),
        (e.prototype.onDragEnd = function (b) {
            var d = this.difference(this._drag.pointer, this.pointer(b)),
                e = this._drag.stage.current,
                f = (d.x > 0) ^ this.settings.rtl ? "left" : "right";
            a(c).off(".owl.core"),
                this.$element.removeClass(this.options.grabClass),
                ((0 !== d.x && this.is("dragging")) || !this.is("valid")) &&
                    (this.speed(this.settings.dragEndSpeed || this.settings.smartSpeed),
                    this.current(this.closest(e.x, 0 !== d.x ? f : this._drag.direction)),
                    this.invalidate("position"),
                    this.update(),
                    (this._drag.direction = f),
                    (Math.abs(d.x) > 3 || new Date().getTime() - this._drag.time > 300) &&
                        this._drag.target.one("click.owl.core", function () {
                            return !1;
                        })),
                this.is("dragging") && (this.leave("dragging"), this.trigger("dragged"));
        }),
        (e.prototype.closest = function (b, c) {
            var e = -1,
                f = 30,
                g = this.width(),
                h = this.coordinates();
            return (
                this.settings.freeDrag ||
                    a.each(
                        h,
                        a.proxy(function (a, i) {
                            return (
                                "left" === c && b > i - f && b < i + f
                                    ? (e = a)
                                    : "right" === c && b > i - g - f && b < i - g + f
                                    ? (e = a + 1)
                                    : this.op(b, "<", i) && this.op(b, ">", h[a + 1] !== d ? h[a + 1] : i - g) && (e = "left" === c ? a + 1 : a),
                                -1 === e
                            );
                        }, this)
                    ),
                this.settings.loop || (this.op(b, ">", h[this.minimum()]) ? (e = b = this.minimum()) : this.op(b, "<", h[this.maximum()]) && (e = b = this.maximum())),
                e
            );
        }),
        (e.prototype.animate = function (b) {
            var c = this.speed() > 0;
            this.is("animating") && this.onTransitionEnd(),
                c && (this.enter("animating"), this.trigger("translate")),
                a.support.transform3d && a.support.transition
                    ? this.$stage.css({ transform: "translate3d(" + b + "px,0px,0px)", transition: this.speed() / 1e3 + "s" + (this.settings.slideTransition ? " " + this.settings.slideTransition : "") })
                    : c
                    ? this.$stage.animate({ left: b + "px" }, this.speed(), this.settings.fallbackEasing, a.proxy(this.onTransitionEnd, this))
                    : this.$stage.css({ left: b + "px" });
        }),
        (e.prototype.is = function (a) {
            return this._states.current[a] && this._states.current[a] > 0;
        }),
        (e.prototype.current = function (a) {
            if (a === d) return this._current;
            if (0 === this._items.length) return d;
            if (((a = this.normalize(a)), this._current !== a)) {
                var b = this.trigger("change", { property: { name: "position", value: a } });
                b.data !== d && (a = this.normalize(b.data)), (this._current = a), this.invalidate("position"), this.trigger("changed", { property: { name: "position", value: this._current } });
            }
            return this._current;
        }),
        (e.prototype.invalidate = function (b) {
            return (
                "string" === a.type(b) && ((this._invalidated[b] = !0), this.is("valid") && this.leave("valid")),
                a.map(this._invalidated, function (a, b) {
                    return b;
                })
            );
        }),
        (e.prototype.reset = function (a) {
            (a = this.normalize(a)) !== d && ((this._speed = 0), (this._current = a), this.suppress(["translate", "translated"]), this.animate(this.coordinates(a)), this.release(["translate", "translated"]));
        }),
        (e.prototype.normalize = function (a, b) {
            var c = this._items.length,
                e = b ? 0 : this._clones.length;
            return !this.isNumeric(a) || c < 1 ? (a = d) : (a < 0 || a >= c + e) && (a = ((((a - e / 2) % c) + c) % c) + e / 2), a;
        }),
        (e.prototype.relative = function (a) {
            return (a -= this._clones.length / 2), this.normalize(a, !0);
        }),
        (e.prototype.maximum = function (a) {
            var b,
                c,
                d,
                e = this.settings,
                f = this._coordinates.length;
            if (e.loop) f = this._clones.length / 2 + this._items.length - 1;
            else if (e.autoWidth || e.merge) {
                if ((b = this._items.length)) for (c = this._items[--b].width(), d = this.$element.width(); b-- && !((c += this._items[b].width() + this.settings.margin) > d); );
                f = b + 1;
            } else f = e.center ? this._items.length - 1 : this._items.length - e.items;
            return a && (f -= this._clones.length / 2), Math.max(f, 0);
        }),
        (e.prototype.minimum = function (a) {
            return a ? 0 : this._clones.length / 2;
        }),
        (e.prototype.items = function (a) {
            return a === d ? this._items.slice() : ((a = this.normalize(a, !0)), this._items[a]);
        }),
        (e.prototype.mergers = function (a) {
            return a === d ? this._mergers.slice() : ((a = this.normalize(a, !0)), this._mergers[a]);
        }),
        (e.prototype.clones = function (b) {
            var c = this._clones.length / 2,
                e = c + this._items.length,
                f = function (a) {
                    return a % 2 == 0 ? e + a / 2 : c - (a + 1) / 2;
                };
            return b === d
                ? a.map(this._clones, function (a, b) {
                      return f(b);
                  })
                : a.map(this._clones, function (a, c) {
                      return a === b ? f(c) : null;
                  });
        }),
        (e.prototype.speed = function (a) {
            return a !== d && (this._speed = a), this._speed;
        }),
        (e.prototype.coordinates = function (b) {
            var c,
                e = 1,
                f = b - 1;
            return b === d
                ? a.map(
                      this._coordinates,
                      a.proxy(function (a, b) {
                          return this.coordinates(b);
                      }, this)
                  )
                : (this.settings.center ? (this.settings.rtl && ((e = -1), (f = b + 1)), (c = this._coordinates[b]), (c += ((this.width() - c + (this._coordinates[f] || 0)) / 2) * e)) : (c = this._coordinates[f] || 0), (c = Math.ceil(c)));
        }),
        (e.prototype.duration = function (a, b, c) {
            return 0 === c ? 0 : Math.min(Math.max(Math.abs(b - a), 1), 6) * Math.abs(c || this.settings.smartSpeed);
        }),
        (e.prototype.to = function (a, b) {
            var c = this.current(),
                d = null,
                e = a - this.relative(c),
                f = (e > 0) - (e < 0),
                g = this._items.length,
                h = this.minimum(),
                i = this.maximum();
            this.settings.loop
                ? (!this.settings.rewind && Math.abs(e) > g / 2 && (e += -1 * f * g), (a = c + e), (d = ((((a - h) % g) + g) % g) + h) !== a && d - e <= i && d - e > 0 && ((c = d - e), (a = d), this.reset(c)))
                : this.settings.rewind
                ? ((i += 1), (a = ((a % i) + i) % i))
                : (a = Math.max(h, Math.min(i, a))),
                this.speed(this.duration(c, a, b)),
                this.current(a),
                this.isVisible() && this.update();
        }),
        (e.prototype.next = function (a) {
            (a = a || !1), this.to(this.relative(this.current()) + 1, a);
        }),
        (e.prototype.prev = function (a) {
            (a = a || !1), this.to(this.relative(this.current()) - 1, a);
        }),
        (e.prototype.onTransitionEnd = function (a) {
            if (a !== d && (a.stopPropagation(), (a.target || a.srcElement || a.originalTarget) !== this.$stage.get(0))) return !1;
            this.leave("animating"), this.trigger("translated");
        }),
        (e.prototype.viewport = function () {
            var d;
            return (
                this.options.responsiveBaseElement !== b
                    ? (d = a(this.options.responsiveBaseElement).width())
                    : b.innerWidth
                    ? (d = b.innerWidth)
                    : c.documentElement && c.documentElement.clientWidth
                    ? (d = c.documentElement.clientWidth)
                    : console.warn("Can not detect viewport width."),
                d
            );
        }),
        (e.prototype.replace = function (b) {
            this.$stage.empty(),
                (this._items = []),
                b && (b = b instanceof jQuery ? b : a(b)),
                this.settings.nestedItemSelector && (b = b.find("." + this.settings.nestedItemSelector)),
                b
                    .filter(function () {
                        return 1 === this.nodeType;
                    })
                    .each(
                        a.proxy(function (a, b) {
                            (b = this.prepare(b)), this.$stage.append(b), this._items.push(b), this._mergers.push(1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1);
                        }, this)
                    ),
                this.reset(this.isNumeric(this.settings.startPosition) ? this.settings.startPosition : 0),
                this.invalidate("items");
        }),
        (e.prototype.add = function (b, c) {
            var e = this.relative(this._current);
            (c = c === d ? this._items.length : this.normalize(c, !0)),
                (b = b instanceof jQuery ? b : a(b)),
                this.trigger("add", { content: b, position: c }),
                (b = this.prepare(b)),
                0 === this._items.length || c === this._items.length
                    ? (0 === this._items.length && this.$stage.append(b),
                      0 !== this._items.length && this._items[c - 1].after(b),
                      this._items.push(b),
                      this._mergers.push(1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1))
                    : (this._items[c].before(b), this._items.splice(c, 0, b), this._mergers.splice(c, 0, 1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)),
                this._items[e] && this.reset(this._items[e].index()),
                this.invalidate("items"),
                this.trigger("added", { content: b, position: c });
        }),
        (e.prototype.remove = function (a) {
            (a = this.normalize(a, !0)) !== d &&
                (this.trigger("remove", { content: this._items[a], position: a }),
                this._items[a].remove(),
                this._items.splice(a, 1),
                this._mergers.splice(a, 1),
                this.invalidate("items"),
                this.trigger("removed", { content: null, position: a }));
        }),
        (e.prototype.preloadAutoWidthImages = function (b) {
            b.each(
                a.proxy(function (b, c) {
                    this.enter("pre-loading"),
                        (c = a(c)),
                        a(new Image())
                            .one(
                                "load",
                                a.proxy(function (a) {
                                    c.attr("src", a.target.src), c.css("opacity", 1), this.leave("pre-loading"), !this.is("pre-loading") && !this.is("initializing") && this.refresh();
                                }, this)
                            )
                            .attr("src", c.attr("src") || c.attr("data-src") || c.attr("data-src-retina"));
                }, this)
            );
        }),
        (e.prototype.destroy = function () {
            this.$element.off(".owl.core"), this.$stage.off(".owl.core"), a(c).off(".owl.core"), !1 !== this.settings.responsive && (b.clearTimeout(this.resizeTimer), this.off(b, "resize", this._handlers.onThrottledResize));
            for (var d in this._plugins) this._plugins[d].destroy();
            this.$stage.children(".cloned").remove(),
                this.$stage.unwrap(),
                this.$stage.children().contents().unwrap(),
                this.$stage.children().unwrap(),
                this.$stage.remove(),
                this.$element
                    .removeClass(this.options.refreshClass)
                    .removeClass(this.options.loadingClass)
                    .removeClass(this.options.loadedClass)
                    .removeClass(this.options.rtlClass)
                    .removeClass(this.options.dragClass)
                    .removeClass(this.options.grabClass)
                    .attr("class", this.$element.attr("class").replace(new RegExp(this.options.responsiveClass + "-\\S+\\s", "g"), ""))
                    .removeData("owl.carousel");
        }),
        (e.prototype.op = function (a, b, c) {
            var d = this.settings.rtl;
            switch (b) {
                case "<":
                    return d ? a > c : a < c;
                case ">":
                    return d ? a < c : a > c;
                case ">=":
                    return d ? a <= c : a >= c;
                case "<=":
                    return d ? a >= c : a <= c;
            }
        }),
        (e.prototype.on = function (a, b, c, d) {
            a.addEventListener ? a.addEventListener(b, c, d) : a.attachEvent && a.attachEvent("on" + b, c);
        }),
        (e.prototype.off = function (a, b, c, d) {
            a.removeEventListener ? a.removeEventListener(b, c, d) : a.detachEvent && a.detachEvent("on" + b, c);
        }),
        (e.prototype.trigger = function (b, c, d, f, g) {
            var h = { item: { count: this._items.length, index: this.current() } },
                i = a.camelCase(
                    a
                        .grep(["on", b, d], function (a) {
                            return a;
                        })
                        .join("-")
                        .toLowerCase()
                ),
                j = a.Event([b, "owl", d || "carousel"].join(".").toLowerCase(), a.extend({ relatedTarget: this }, h, c));
            return (
                this._supress[b] ||
                    (a.each(this._plugins, function (a, b) {
                        b.onTrigger && b.onTrigger(j);
                    }),
                    this.register({ type: e.Type.Event, name: b }),
                    this.$element.trigger(j),
                    this.settings && "function" == typeof this.settings[i] && this.settings[i].call(this, j)),
                j
            );
        }),
        (e.prototype.enter = function (b) {
            a.each(
                [b].concat(this._states.tags[b] || []),
                a.proxy(function (a, b) {
                    this._states.current[b] === d && (this._states.current[b] = 0), this._states.current[b]++;
                }, this)
            );
        }),
        (e.prototype.leave = function (b) {
            a.each(
                [b].concat(this._states.tags[b] || []),
                a.proxy(function (a, b) {
                    this._states.current[b]--;
                }, this)
            );
        }),
        (e.prototype.register = function (b) {
            if (b.type === e.Type.Event) {
                if ((a.event.special[b.name] || (a.event.special[b.name] = {}), !a.event.special[b.name].owl)) {
                    var c = a.event.special[b.name]._default;
                    (a.event.special[b.name]._default = function (a) {
                        return !c || !c.apply || (a.namespace && -1 !== a.namespace.indexOf("owl")) ? a.namespace && a.namespace.indexOf("owl") > -1 : c.apply(this, arguments);
                    }),
                        (a.event.special[b.name].owl = !0);
                }
            } else
                b.type === e.Type.State &&
                    (this._states.tags[b.name] ? (this._states.tags[b.name] = this._states.tags[b.name].concat(b.tags)) : (this._states.tags[b.name] = b.tags),
                    (this._states.tags[b.name] = a.grep(
                        this._states.tags[b.name],
                        a.proxy(function (c, d) {
                            return a.inArray(c, this._states.tags[b.name]) === d;
                        }, this)
                    )));
        }),
        (e.prototype.suppress = function (b) {
            a.each(
                b,
                a.proxy(function (a, b) {
                    this._supress[b] = !0;
                }, this)
            );
        }),
        (e.prototype.release = function (b) {
            a.each(
                b,
                a.proxy(function (a, b) {
                    delete this._supress[b];
                }, this)
            );
        }),
        (e.prototype.pointer = function (a) {
            var c = { x: null, y: null };
            return (
                (a = a.originalEvent || a || b.event),
                (a = a.touches && a.touches.length ? a.touches[0] : a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : a),
                a.pageX ? ((c.x = a.pageX), (c.y = a.pageY)) : ((c.x = a.clientX), (c.y = a.clientY)),
                c
            );
        }),
        (e.prototype.isNumeric = function (a) {
            return !isNaN(parseFloat(a));
        }),
        (e.prototype.difference = function (a, b) {
            return { x: a.x - b.x, y: a.y - b.y };
        }),
        (a.fn.owlCarousel = function (b) {
            var c = Array.prototype.slice.call(arguments, 1);
            return this.each(function () {
                var d = a(this),
                    f = d.data("owl.carousel");
                f ||
                    ((f = new e(this, "object" == typeof b && b)),
                    d.data("owl.carousel", f),
                    a.each(["next", "prev", "to", "destroy", "refresh", "replace", "add", "remove"], function (b, c) {
                        f.register({ type: e.Type.Event, name: c }),
                            f.$element.on(
                                c + ".owl.carousel.core",
                                a.proxy(function (a) {
                                    a.namespace && a.relatedTarget !== this && (this.suppress([c]), f[c].apply(this, [].slice.call(arguments, 1)), this.release([c]));
                                }, f)
                            );
                    })),
                    "string" == typeof b && "_" !== b.charAt(0) && f[b].apply(f, c);
            });
        }),
        (a.fn.owlCarousel.Constructor = e);
})(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        var e = function (b) {
            (this._core = b),
                (this._interval = null),
                (this._visible = null),
                (this._handlers = {
                    "initialized.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.autoRefresh && this.watch();
                    }, this),
                }),
                (this._core.options = a.extend({}, e.Defaults, this._core.options)),
                this._core.$element.on(this._handlers);
        };
        (e.Defaults = { autoRefresh: !0, autoRefreshInterval: 500 }),
            (e.prototype.watch = function () {
                this._interval || ((this._visible = this._core.isVisible()), (this._interval = b.setInterval(a.proxy(this.refresh, this), this._core.settings.autoRefreshInterval)));
            }),
            (e.prototype.refresh = function () {
                this._core.isVisible() !== this._visible && ((this._visible = !this._visible), this._core.$element.toggleClass("owl-hidden", !this._visible), this._visible && this._core.invalidate("width") && this._core.refresh());
            }),
            (e.prototype.destroy = function () {
                var a, c;
                b.clearInterval(this._interval);
                for (a in this._handlers) this._core.$element.off(a, this._handlers[a]);
                for (c in Object.getOwnPropertyNames(this)) "function" != typeof this[c] && (this[c] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.AutoRefresh = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        var e = function (b) {
            (this._core = b),
                (this._loaded = []),
                (this._handlers = {
                    "initialized.owl.carousel change.owl.carousel resized.owl.carousel": a.proxy(function (b) {
                        if (b.namespace && this._core.settings && this._core.settings.lazyLoad && ((b.property && "position" == b.property.name) || "initialized" == b.type)) {
                            var c = this._core.settings,
                                e = (c.center && Math.ceil(c.items / 2)) || c.items,
                                f = (c.center && -1 * e) || 0,
                                g = (b.property && b.property.value !== d ? b.property.value : this._core.current()) + f,
                                h = this._core.clones().length,
                                i = a.proxy(function (a, b) {
                                    this.load(b);
                                }, this);
                            for (c.lazyLoadEager > 0 && ((e += c.lazyLoadEager), c.loop && ((g -= c.lazyLoadEager), e++)); f++ < e; ) this.load(h / 2 + this._core.relative(g)), h && a.each(this._core.clones(this._core.relative(g)), i), g++;
                        }
                    }, this),
                }),
                (this._core.options = a.extend({}, e.Defaults, this._core.options)),
                this._core.$element.on(this._handlers);
        };
        (e.Defaults = { lazyLoad: !1, lazyLoadEager: 0 }),
            (e.prototype.load = function (c) {
                var d = this._core.$stage.children().eq(c),
                    e = d && d.find(".owl-lazy");
                !e ||
                    a.inArray(d.get(0), this._loaded) > -1 ||
                    (e.each(
                        a.proxy(function (c, d) {
                            var e,
                                f = a(d),
                                g = (b.devicePixelRatio > 1 && f.attr("data-src-retina")) || f.attr("data-src") || f.attr("data-srcset");
                            this._core.trigger("load", { element: f, url: g }, "lazy"),
                                f.is("img")
                                    ? f
                                          .one(
                                              "load.owl.lazy",
                                              a.proxy(function () {
                                                  f.css("opacity", 1), this._core.trigger("loaded", { element: f, url: g }, "lazy");
                                              }, this)
                                          )
                                          .attr("src", g)
                                    : f.is("source")
                                    ? f
                                          .one(
                                              "load.owl.lazy",
                                              a.proxy(function () {
                                                  this._core.trigger("loaded", { element: f, url: g }, "lazy");
                                              }, this)
                                          )
                                          .attr("srcset", g)
                                    : ((e = new Image()),
                                      (e.onload = a.proxy(function () {
                                          f.css({ "background-image": 'url("' + g + '")', opacity: "1" }), this._core.trigger("loaded", { element: f, url: g }, "lazy");
                                      }, this)),
                                      (e.src = g));
                        }, this)
                    ),
                    this._loaded.push(d.get(0)));
            }),
            (e.prototype.destroy = function () {
                var a, b;
                for (a in this.handlers) this._core.$element.off(a, this.handlers[a]);
                for (b in Object.getOwnPropertyNames(this)) "function" != typeof this[b] && (this[b] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.Lazy = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        var e = function (c) {
            (this._core = c),
                (this._previousHeight = null),
                (this._handlers = {
                    "initialized.owl.carousel refreshed.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.autoHeight && this.update();
                    }, this),
                    "changed.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.autoHeight && "position" === a.property.name && this.update();
                    }, this),
                    "loaded.owl.lazy": a.proxy(function (a) {
                        a.namespace && this._core.settings.autoHeight && a.element.closest("." + this._core.settings.itemClass).index() === this._core.current() && this.update();
                    }, this),
                }),
                (this._core.options = a.extend({}, e.Defaults, this._core.options)),
                this._core.$element.on(this._handlers),
                (this._intervalId = null);
            var d = this;
            a(b).on("load", function () {
                d._core.settings.autoHeight && d.update();
            }),
                a(b).resize(function () {
                    d._core.settings.autoHeight &&
                        (null != d._intervalId && clearTimeout(d._intervalId),
                        (d._intervalId = setTimeout(function () {
                            d.update();
                        }, 250)));
                });
        };
        (e.Defaults = { autoHeight: !1, autoHeightClass: "owl-height" }),
            (e.prototype.update = function () {
                var b = this._core._current,
                    c = b + this._core.settings.items,
                    d = this._core.settings.lazyLoad,
                    e = this._core.$stage.children().toArray().slice(b, c),
                    f = [],
                    g = 0;
                a.each(e, function (b, c) {
                    f.push(a(c).height());
                }),
                    (g = Math.max.apply(null, f)),
                    g <= 1 && d && this._previousHeight && (g = this._previousHeight),
                    (this._previousHeight = g),
                    this._core.$stage.parent().height(g).addClass(this._core.settings.autoHeightClass);
            }),
            (e.prototype.destroy = function () {
                var a, b;
                for (a in this._handlers) this._core.$element.off(a, this._handlers[a]);
                for (b in Object.getOwnPropertyNames(this)) "function" != typeof this[b] && (this[b] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.AutoHeight = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        var e = function (b) {
            (this._core = b),
                (this._videos = {}),
                (this._playing = null),
                (this._handlers = {
                    "initialized.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.register({ type: "state", name: "playing", tags: ["interacting"] });
                    }, this),
                    "resize.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.video && this.isInFullScreen() && a.preventDefault();
                    }, this),
                    "refreshed.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.is("resizing") && this._core.$stage.find(".cloned .owl-video-frame").remove();
                    }, this),
                    "changed.owl.carousel": a.proxy(function (a) {
                        a.namespace && "position" === a.property.name && this._playing && this.stop();
                    }, this),
                    "prepared.owl.carousel": a.proxy(function (b) {
                        if (b.namespace) {
                            var c = a(b.content).find(".owl-video");
                            c.length && (c.css("display", "none"), this.fetch(c, a(b.content)));
                        }
                    }, this),
                }),
                (this._core.options = a.extend({}, e.Defaults, this._core.options)),
                this._core.$element.on(this._handlers),
                this._core.$element.on(
                    "click.owl.video",
                    ".owl-video-play-icon",
                    a.proxy(function (a) {
                        this.play(a);
                    }, this)
                );
        };
        (e.Defaults = { video: !1, videoHeight: !1, videoWidth: !1 }),
            (e.prototype.fetch = function (a, b) {
                var c = (function () {
                        return a.attr("data-vimeo-id") ? "vimeo" : a.attr("data-vzaar-id") ? "vzaar" : "youtube";
                    })(),
                    d = a.attr("data-vimeo-id") || a.attr("data-youtube-id") || a.attr("data-vzaar-id"),
                    e = a.attr("data-width") || this._core.settings.videoWidth,
                    f = a.attr("data-height") || this._core.settings.videoHeight,
                    g = a.attr("href");
                if (!g) throw new Error("Missing video URL.");
                if (
                    ((d = g.match(
                        /(http:|https:|)\/\/(player.|www.|app.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com|be\-nocookie\.com)|vzaar\.com)\/(video\/|videos\/|embed\/|channels\/.+\/|groups\/.+\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/
                    )),
                    d[3].indexOf("youtu") > -1)
                )
                    c = "youtube";
                else if (d[3].indexOf("vimeo") > -1) c = "vimeo";
                else {
                    if (!(d[3].indexOf("vzaar") > -1)) throw new Error("Video URL not supported.");
                    c = "vzaar";
                }
                (d = d[6]), (this._videos[g] = { type: c, id: d, width: e, height: f }), b.attr("data-video", g), this.thumbnail(a, this._videos[g]);
            }),
            (e.prototype.thumbnail = function (b, c) {
                var d,
                    e,
                    f,
                    g = c.width && c.height ? "width:" + c.width + "px;height:" + c.height + "px;" : "",
                    h = b.find("img"),
                    i = "src",
                    j = "",
                    k = this._core.settings,
                    l = function (c) {
                        (e = '<div class="owl-video-play-icon"></div>'),
                            (d = k.lazyLoad ? a("<div/>", { class: "owl-video-tn " + j, srcType: c }) : a("<div/>", { class: "owl-video-tn", style: "opacity:1;background-image:url(" + c + ")" })),
                            b.after(d),
                            b.after(e);
                    };
                if ((b.wrap(a("<div/>", { class: "owl-video-wrapper", style: g })), this._core.settings.lazyLoad && ((i = "data-src"), (j = "owl-lazy")), h.length)) return l(h.attr(i)), h.remove(), !1;
                "youtube" === c.type
                    ? ((f = "//img.youtube.com/vi/" + c.id + "/hqdefault.jpg"), l(f))
                    : "vimeo" === c.type
                    ? a.ajax({
                          type: "GET",
                          url: "//vimeo.com/api/v2/video/" + c.id + ".json",
                          jsonp: "callback",
                          dataType: "jsonp",
                          success: function (a) {
                              (f = a[0].thumbnail_large), l(f);
                          },
                      })
                    : "vzaar" === c.type &&
                      a.ajax({
                          type: "GET",
                          url: "//vzaar.com/api/videos/" + c.id + ".json",
                          jsonp: "callback",
                          dataType: "jsonp",
                          success: function (a) {
                              (f = a.framegrab_url), l(f);
                          },
                      });
            }),
            (e.prototype.stop = function () {
                this._core.trigger("stop", null, "video"),
                    this._playing.find(".owl-video-frame").remove(),
                    this._playing.removeClass("owl-video-playing"),
                    (this._playing = null),
                    this._core.leave("playing"),
                    this._core.trigger("stopped", null, "video");
            }),
            (e.prototype.play = function (b) {
                var c,
                    d = a(b.target),
                    e = d.closest("." + this._core.settings.itemClass),
                    f = this._videos[e.attr("data-video")],
                    g = f.width || "100%",
                    h = f.height || this._core.$stage.height();
                this._playing ||
                    (this._core.enter("playing"),
                    this._core.trigger("play", null, "video"),
                    (e = this._core.items(this._core.relative(e.index()))),
                    this._core.reset(e.index()),
                    (c = a('<iframe frameborder="0" allowfullscreen mozallowfullscreen webkitAllowFullScreen ></iframe>')),
                    c.attr("height", h),
                    c.attr("width", g),
                    "youtube" === f.type
                        ? c.attr("src", "//www.youtube.com/embed/" + f.id + "?autoplay=1&rel=0&v=" + f.id)
                        : "vimeo" === f.type
                        ? c.attr("src", "//player.vimeo.com/video/" + f.id + "?autoplay=1")
                        : "vzaar" === f.type && c.attr("src", "//view.vzaar.com/" + f.id + "/player?autoplay=true"),
                    a(c).wrap('<div class="owl-video-frame" />').insertAfter(e.find(".owl-video")),
                    (this._playing = e.addClass("owl-video-playing")));
            }),
            (e.prototype.isInFullScreen = function () {
                var b = c.fullscreenElement || c.mozFullScreenElement || c.webkitFullscreenElement;
                return b && a(b).parent().hasClass("owl-video-frame");
            }),
            (e.prototype.destroy = function () {
                var a, b;
                this._core.$element.off("click.owl.video");
                for (a in this._handlers) this._core.$element.off(a, this._handlers[a]);
                for (b in Object.getOwnPropertyNames(this)) "function" != typeof this[b] && (this[b] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.Video = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        var e = function (b) {
            (this.core = b),
                (this.core.options = a.extend({}, e.Defaults, this.core.options)),
                (this.swapping = !0),
                (this.previous = d),
                (this.next = d),
                (this.handlers = {
                    "change.owl.carousel": a.proxy(function (a) {
                        a.namespace && "position" == a.property.name && ((this.previous = this.core.current()), (this.next = a.property.value));
                    }, this),
                    "drag.owl.carousel dragged.owl.carousel translated.owl.carousel": a.proxy(function (a) {
                        a.namespace && (this.swapping = "translated" == a.type);
                    }, this),
                    "translate.owl.carousel": a.proxy(function (a) {
                        a.namespace && this.swapping && (this.core.options.animateOut || this.core.options.animateIn) && this.swap();
                    }, this),
                }),
                this.core.$element.on(this.handlers);
        };
        (e.Defaults = { animateOut: !1, animateIn: !1 }),
            (e.prototype.swap = function () {
                if (1 === this.core.settings.items && a.support.animation && a.support.transition) {
                    this.core.speed(0);
                    var b,
                        c = a.proxy(this.clear, this),
                        d = this.core.$stage.children().eq(this.previous),
                        e = this.core.$stage.children().eq(this.next),
                        f = this.core.settings.animateIn,
                        g = this.core.settings.animateOut;
                    this.core.current() !== this.previous &&
                        (g &&
                            ((b = this.core.coordinates(this.previous) - this.core.coordinates(this.next)),
                            d
                                .one(a.support.animation.end, c)
                                .css({ left: b + "px" })
                                .addClass("animated owl-animated-out")
                                .addClass(g)),
                        f && e.one(a.support.animation.end, c).addClass("animated owl-animated-in").addClass(f));
                }
            }),
            (e.prototype.clear = function (b) {
                a(b.target).css({ left: "" }).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut), this.core.onTransitionEnd();
            }),
            (e.prototype.destroy = function () {
                var a, b;
                for (a in this.handlers) this.core.$element.off(a, this.handlers[a]);
                for (b in Object.getOwnPropertyNames(this)) "function" != typeof this[b] && (this[b] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.Animate = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        var e = function (b) {
            (this._core = b),
                (this._call = null),
                (this._time = 0),
                (this._timeout = 0),
                (this._paused = !0),
                (this._handlers = {
                    "changed.owl.carousel": a.proxy(function (a) {
                        a.namespace && "settings" === a.property.name ? (this._core.settings.autoplay ? this.play() : this.stop()) : a.namespace && "position" === a.property.name && this._paused && (this._time = 0);
                    }, this),
                    "initialized.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.autoplay && this.play();
                    }, this),
                    "play.owl.autoplay": a.proxy(function (a, b, c) {
                        a.namespace && this.play(b, c);
                    }, this),
                    "stop.owl.autoplay": a.proxy(function (a) {
                        a.namespace && this.stop();
                    }, this),
                    "mouseover.owl.autoplay": a.proxy(function () {
                        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
                    }, this),
                    "mouseleave.owl.autoplay": a.proxy(function () {
                        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.play();
                    }, this),
                    "touchstart.owl.core": a.proxy(function () {
                        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
                    }, this),
                    "touchend.owl.core": a.proxy(function () {
                        this._core.settings.autoplayHoverPause && this.play();
                    }, this),
                }),
                this._core.$element.on(this._handlers),
                (this._core.options = a.extend({}, e.Defaults, this._core.options));
        };
        (e.Defaults = { autoplay: !1, autoplayTimeout: 5e3, autoplayHoverPause: !1, autoplaySpeed: !1 }),
            (e.prototype._next = function (d) {
                (this._call = b.setTimeout(a.proxy(this._next, this, d), this._timeout * (Math.round(this.read() / this._timeout) + 1) - this.read())),
                    this._core.is("interacting") || c.hidden || this._core.next(d || this._core.settings.autoplaySpeed);
            }),
            (e.prototype.read = function () {
                return new Date().getTime() - this._time;
            }),
            (e.prototype.play = function (c, d) {
                var e;
                this._core.is("rotating") || this._core.enter("rotating"),
                    (c = c || this._core.settings.autoplayTimeout),
                    (e = Math.min(this._time % (this._timeout || c), c)),
                    this._paused ? ((this._time = this.read()), (this._paused = !1)) : b.clearTimeout(this._call),
                    (this._time += (this.read() % c) - e),
                    (this._timeout = c),
                    (this._call = b.setTimeout(a.proxy(this._next, this, d), c - e));
            }),
            (e.prototype.stop = function () {
                this._core.is("rotating") && ((this._time = 0), (this._paused = !0), b.clearTimeout(this._call), this._core.leave("rotating"));
            }),
            (e.prototype.pause = function () {
                this._core.is("rotating") && !this._paused && ((this._time = this.read()), (this._paused = !0), b.clearTimeout(this._call));
            }),
            (e.prototype.destroy = function () {
                var a, b;
                this.stop();
                for (a in this._handlers) this._core.$element.off(a, this._handlers[a]);
                for (b in Object.getOwnPropertyNames(this)) "function" != typeof this[b] && (this[b] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.autoplay = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        "use strict";
        var e = function (b) {
            (this._core = b),
                (this._initialized = !1),
                (this._pages = []),
                (this._controls = {}),
                (this._templates = []),
                (this.$element = this._core.$element),
                (this._overrides = { next: this._core.next, prev: this._core.prev, to: this._core.to }),
                (this._handlers = {
                    "prepared.owl.carousel": a.proxy(function (b) {
                        b.namespace && this._core.settings.dotsData && this._templates.push('<div class="' + this._core.settings.dotClass + '">' + a(b.content).find("[data-dot]").addBack("[data-dot]").attr("data-dot") + "</div>");
                    }, this),
                    "added.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.dotsData && this._templates.splice(a.position, 0, this._templates.pop());
                    }, this),
                    "remove.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._core.settings.dotsData && this._templates.splice(a.position, 1);
                    }, this),
                    "changed.owl.carousel": a.proxy(function (a) {
                        a.namespace && "position" == a.property.name && this.draw();
                    }, this),
                    "initialized.owl.carousel": a.proxy(function (a) {
                        a.namespace &&
                            !this._initialized &&
                            (this._core.trigger("initialize", null, "navigation"), this.initialize(), this.update(), this.draw(), (this._initialized = !0), this._core.trigger("initialized", null, "navigation"));
                    }, this),
                    "refreshed.owl.carousel": a.proxy(function (a) {
                        a.namespace && this._initialized && (this._core.trigger("refresh", null, "navigation"), this.update(), this.draw(), this._core.trigger("refreshed", null, "navigation"));
                    }, this),
                }),
                (this._core.options = a.extend({}, e.Defaults, this._core.options)),
                this.$element.on(this._handlers);
        };
        (e.Defaults = {
            nav: !1,
            navText: ['<span aria-label="Previous">&#x2039;</span>', '<span aria-label="Next">&#x203a;</span>'],
            navSpeed: !1,
            navElement: 'button type="button" role="presentation"',
            navContainer: !1,
            navContainerClass: "owl-nav owl-controls",
            navClass: ["owl-prev", "owl-next"],
            slideBy: 1,
            dotClass: "owl-dot",
            dotsClass: "owl-dots owl-controls",
            dots: !1,
            dotsEach: !1,
            dotsData: !1,
            dotsSpeed: !1,
            dotsContainer: !1,
        }),
            (e.prototype.initialize = function () {
                var b,
                    c = this._core.settings;
                (this._controls.$relative = (c.navContainer ? a(c.navContainer) : a("<div>").addClass(c.navContainerClass).appendTo(this.$element)).addClass("disabled")),
                    (this._controls.$previous = a("<" + c.navElement + ">")
                        .addClass(c.navClass[0])
                        .html(c.navText[0])
                        .prependTo(this._controls.$relative)
                        .on(
                            "click",
                            a.proxy(function (a) {
                                this.prev(c.navSpeed);
                            }, this)
                        )),
                    (this._controls.$next = a("<" + c.navElement + ">")
                        .addClass(c.navClass[1])
                        .html(c.navText[1])
                        .appendTo(this._controls.$relative)
                        .on(
                            "click",
                            a.proxy(function (a) {
                                this.next(c.navSpeed);
                            }, this)
                        )),
                    c.dotsData || (this._templates = [a('<button role="button">').addClass(c.dotClass).append(a("<span>")).prop("outerHTML")]),
                    (this._controls.$absolute = (c.dotsContainer ? a(c.dotsContainer) : a("<div>").addClass(c.dotsClass).appendTo(this.$element)).addClass("disabled")),
                    this._controls.$absolute.on(
                        "click",
                        "button",
                        a.proxy(function (b) {
                            var d = a(b.target).parent().is(this._controls.$absolute) ? a(b.target).index() : a(b.target).parent().index();
                            b.preventDefault(), this.to(d, c.dotsSpeed);
                        }, this)
                    );
                for (b in this._overrides) this._core[b] = a.proxy(this[b], this);
            }),
            (e.prototype.destroy = function () {
                var a, b, c, d, e;
                e = this._core.settings;
                for (a in this._handlers) this.$element.off(a, this._handlers[a]);
                for (b in this._controls) "$relative" === b && e.navContainer ? this._controls[b].html("") : this._controls[b].remove();
                for (d in this.overides) this._core[d] = this._overrides[d];
                for (c in Object.getOwnPropertyNames(this)) "function" != typeof this[c] && (this[c] = null);
            }),
            (e.prototype.update = function () {
                var a,
                    b,
                    c,
                    d = this._core.clones().length / 2,
                    e = d + this._core.items().length,
                    f = this._core.maximum(!0),
                    g = this._core.settings,
                    h = g.center || g.autoWidth || g.dotsData ? 1 : g.dotsEach || g.items;
                if (("page" !== g.slideBy && (g.slideBy = Math.min(g.slideBy, g.items)), g.dots || "page" == g.slideBy))
                    for (this._pages = [], a = d, b = 0, c = 0; a < e; a++) {
                        if (b >= h || 0 === b) {
                            if ((this._pages.push({ start: Math.min(f, a - d), end: a - d + h - 1 }), Math.min(f, a - d) === f)) break;
                            (b = 0), ++c;
                        }
                        b += this._core.mergers(this._core.relative(a));
                    }
            }),
            (e.prototype.draw = function () {
                var b,
                    c = this._core.settings,
                    d = this._core.items().length <= c.items,
                    e = this._core.relative(this._core.current()),
                    f = c.loop || c.rewind;
                this._controls.$relative.toggleClass("disabled", !c.nav || d),
                    c.nav && (this._controls.$previous.toggleClass("disabled", !f && e <= this._core.minimum(!0)), this._controls.$next.toggleClass("disabled", !f && e >= this._core.maximum(!0))),
                    this._controls.$absolute.toggleClass("disabled", !c.dots || d),
                    c.dots &&
                        ((b = this._pages.length - this._controls.$absolute.children().length),
                        c.dotsData && 0 !== b
                            ? this._controls.$absolute.html(this._templates.join(""))
                            : b > 0
                            ? this._controls.$absolute.append(new Array(b + 1).join(this._templates[0]))
                            : b < 0 && this._controls.$absolute.children().slice(b).remove(),
                        this._controls.$absolute.find(".active").removeClass("active"),
                        this._controls.$absolute.children().eq(a.inArray(this.current(), this._pages)).addClass("active"));
            }),
            (e.prototype.onTrigger = function (b) {
                var c = this._core.settings;
                b.page = { index: a.inArray(this.current(), this._pages), count: this._pages.length, size: c && (c.center || c.autoWidth || c.dotsData ? 1 : c.dotsEach || c.items) };
            }),
            (e.prototype.current = function () {
                var b = this._core.relative(this._core.current());
                return a
                    .grep(
                        this._pages,
                        a.proxy(function (a, c) {
                            return a.start <= b && a.end >= b;
                        }, this)
                    )
                    .pop();
            }),
            (e.prototype.getPosition = function (b) {
                var c,
                    d,
                    e = this._core.settings;
                return (
                    "page" == e.slideBy
                        ? ((c = a.inArray(this.current(), this._pages)), (d = this._pages.length), b ? ++c : --c, (c = this._pages[((c % d) + d) % d].start))
                        : ((c = this._core.relative(this._core.current())), (d = this._core.items().length), b ? (c += e.slideBy) : (c -= e.slideBy)),
                    c
                );
            }),
            (e.prototype.next = function (b) {
                a.proxy(this._overrides.to, this._core)(this.getPosition(!0), b);
            }),
            (e.prototype.prev = function (b) {
                a.proxy(this._overrides.to, this._core)(this.getPosition(!1), b);
            }),
            (e.prototype.to = function (b, c, d) {
                var e;
                !d && this._pages.length ? ((e = this._pages.length), a.proxy(this._overrides.to, this._core)(this._pages[((b % e) + e) % e].start, c)) : a.proxy(this._overrides.to, this._core)(b, c);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.Navigation = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        "use strict";
        var e = function (c) {
            (this._core = c),
                (this._hashes = {}),
                (this.$element = this._core.$element),
                (this._handlers = {
                    "initialized.owl.carousel": a.proxy(function (c) {
                        c.namespace && "URLHash" === this._core.settings.startPosition && a(b).trigger("hashchange.owl.navigation");
                    }, this),
                    "prepared.owl.carousel": a.proxy(function (b) {
                        if (b.namespace) {
                            var c = a(b.content).find("[data-hash]").addBack("[data-hash]").attr("data-hash");
                            if (!c) return;
                            this._hashes[c] = b.content;
                        }
                    }, this),
                    "changed.owl.carousel": a.proxy(function (c) {
                        if (c.namespace && "position" === c.property.name) {
                            var d = this._core.items(this._core.relative(this._core.current())),
                                e = a
                                    .map(this._hashes, function (a, b) {
                                        return a === d ? b : null;
                                    })
                                    .join();
                            if (!e || b.location.hash.slice(1) === e) return;
                            b.location.hash = e;
                        }
                    }, this),
                }),
                (this._core.options = a.extend({}, e.Defaults, this._core.options)),
                this.$element.on(this._handlers),
                a(b).on(
                    "hashchange.owl.navigation",
                    a.proxy(function (a) {
                        var c = b.location.hash.substring(1),
                            e = this._core.$stage.children(),
                            f = this._hashes[c] && e.index(this._hashes[c]);
                        f !== d && f !== this._core.current() && this._core.to(this._core.relative(f), !1, !0);
                    }, this)
                );
        };
        (e.Defaults = { URLhashListener: !1 }),
            (e.prototype.destroy = function () {
                var c, d;
                a(b).off("hashchange.owl.navigation");
                for (c in this._handlers) this._core.$element.off(c, this._handlers[c]);
                for (d in Object.getOwnPropertyNames(this)) "function" != typeof this[d] && (this[d] = null);
            }),
            (a.fn.owlCarousel.Constructor.Plugins.Hash = e);
    })(window.Zepto || window.jQuery, window, document),
    (function (a, b, c, d) {
        function e(b, c) {
            var e = !1,
                f = b.charAt(0).toUpperCase() + b.slice(1);
            return (
                a.each((b + " " + h.join(f + " ") + f).split(" "), function (a, b) {
                    if (g[b] !== d) return (e = !c || b), !1;
                }),
                e
            );
        }
        function f(a) {
            return e(a, !0);
        }
        var g = a("<support>").get(0).style,
            h = "Webkit Moz O ms".split(" "),
            i = {
                transition: { end: { WebkitTransition: "webkitTransitionEnd", MozTransition: "transitionend", OTransition: "oTransitionEnd", transition: "transitionend" } },
                animation: { end: { WebkitAnimation: "webkitAnimationEnd", MozAnimation: "animationend", OAnimation: "oAnimationEnd", animation: "animationend" } },
            },
            j = {
                csstransforms: function () {
                    return !!e("transform");
                },
                csstransforms3d: function () {
                    return !!e("perspective");
                },
                csstransitions: function () {
                    return !!e("transition");
                },
                cssanimations: function () {
                    return !!e("animation");
                },
            };
        j.csstransitions() && ((a.support.transition = new String(f("transition"))), (a.support.transition.end = i.transition.end[a.support.transition])),
            j.cssanimations() && ((a.support.animation = new String(f("animation"))), (a.support.animation.end = i.animation.end[a.support.animation])),
            j.csstransforms() && ((a.support.transform = new String(f("transform"))), (a.support.transform3d = j.csstransforms3d()));
    })(window.Zepto || window.jQuery, window, document);
(function () {
    function e() {}
    function t(e, t) {
        for (var n = e.length; n--; ) if (e[n].listener === t) return n;
        return -1;
    }
    function n(e) {
        return function () {
            return this[e].apply(this, arguments);
        };
    }
    var i = e.prototype,
        r = this,
        o = r.EventEmitter;
    (i.getListeners = function (e) {
        var t,
            n,
            i = this._getEvents();
        if ("object" == typeof e) {
            t = {};
            for (n in i) i.hasOwnProperty(n) && e.test(n) && (t[n] = i[n]);
        } else t = i[e] || (i[e] = []);
        return t;
    }),
        (i.flattenListeners = function (e) {
            var t,
                n = [];
            for (t = 0; e.length > t; t += 1) n.push(e[t].listener);
            return n;
        }),
        (i.getListenersAsObject = function (e) {
            var t,
                n = this.getListeners(e);
            return n instanceof Array && ((t = {}), (t[e] = n)), t || n;
        }),
        (i.addListener = function (e, n) {
            var i,
                r = this.getListenersAsObject(e),
                o = "object" == typeof n;
            for (i in r) r.hasOwnProperty(i) && -1 === t(r[i], n) && r[i].push(o ? n : { listener: n, once: !1 });
            return this;
        }),
        (i.on = n("addListener")),
        (i.addOnceListener = function (e, t) {
            return this.addListener(e, { listener: t, once: !0 });
        }),
        (i.once = n("addOnceListener")),
        (i.defineEvent = function (e) {
            return this.getListeners(e), this;
        }),
        (i.defineEvents = function (e) {
            for (var t = 0; e.length > t; t += 1) this.defineEvent(e[t]);
            return this;
        }),
        (i.removeListener = function (e, n) {
            var i,
                r,
                o = this.getListenersAsObject(e);
            for (r in o) o.hasOwnProperty(r) && ((i = t(o[r], n)), -1 !== i && o[r].splice(i, 1));
            return this;
        }),
        (i.off = n("removeListener")),
        (i.addListeners = function (e, t) {
            return this.manipulateListeners(!1, e, t);
        }),
        (i.removeListeners = function (e, t) {
            return this.manipulateListeners(!0, e, t);
        }),
        (i.manipulateListeners = function (e, t, n) {
            var i,
                r,
                o = e ? this.removeListener : this.addListener,
                s = e ? this.removeListeners : this.addListeners;
            if ("object" != typeof t || t instanceof RegExp) for (i = n.length; i--; ) o.call(this, t, n[i]);
            else for (i in t) t.hasOwnProperty(i) && (r = t[i]) && ("function" == typeof r ? o.call(this, i, r) : s.call(this, i, r));
            return this;
        }),
        (i.removeEvent = function (e) {
            var t,
                n = typeof e,
                i = this._getEvents();
            if ("string" === n) delete i[e];
            else if ("object" === n) for (t in i) i.hasOwnProperty(t) && e.test(t) && delete i[t];
            else delete this._events;
            return this;
        }),
        (i.removeAllListeners = n("removeEvent")),
        (i.emitEvent = function (e, t) {
            var n,
                i,
                r,
                o,
                s = this.getListenersAsObject(e);
            for (r in s)
                if (s.hasOwnProperty(r))
                    for (i = s[r].length; i--; ) (n = s[r][i]), n.once === !0 && this.removeListener(e, n.listener), (o = n.listener.apply(this, t || [])), o === this._getOnceReturnValue() && this.removeListener(e, n.listener);
            return this;
        }),
        (i.trigger = n("emitEvent")),
        (i.emit = function (e) {
            var t = Array.prototype.slice.call(arguments, 1);
            return this.emitEvent(e, t);
        }),
        (i.setOnceReturnValue = function (e) {
            return (this._onceReturnValue = e), this;
        }),
        (i._getOnceReturnValue = function () {
            return this.hasOwnProperty("_onceReturnValue") ? this._onceReturnValue : !0;
        }),
        (i._getEvents = function () {
            return this._events || (this._events = {});
        }),
        (e.noConflict = function () {
            return (r.EventEmitter = o), e;
        }),
        "function" == typeof define && define.amd
            ? define("eventEmitter/EventEmitter", [], function () {
                  return e;
              })
            : "object" == typeof module && module.exports
            ? (module.exports = e)
            : (this.EventEmitter = e);
}.call(this),
    (function (e) {
        function t(t) {
            var n = e.event;
            return (n.target = n.target || n.srcElement || t), n;
        }
        var n = document.documentElement,
            i = function () {};
        n.addEventListener
            ? (i = function (e, t, n) {
                  e.addEventListener(t, n, !1);
              })
            : n.attachEvent &&
              (i = function (e, n, i) {
                  (e[n + i] = i.handleEvent
                      ? function () {
                            var n = t(e);
                            i.handleEvent.call(i, n);
                        }
                      : function () {
                            var n = t(e);
                            i.call(e, n);
                        }),
                      e.attachEvent("on" + n, e[n + i]);
              });
        var r = function () {};
        n.removeEventListener
            ? (r = function (e, t, n) {
                  e.removeEventListener(t, n, !1);
              })
            : n.detachEvent &&
              (r = function (e, t, n) {
                  e.detachEvent("on" + t, e[t + n]);
                  try {
                      delete e[t + n];
                  } catch (i) {
                      e[t + n] = void 0;
                  }
              });
        var o = { bind: i, unbind: r };
        "function" == typeof define && define.amd ? define("eventie/eventie", o) : (e.eventie = o);
    })(this),
    (function (e, t) {
        "function" == typeof define && define.amd
            ? define(["eventEmitter/EventEmitter", "eventie/eventie"], function (n, i) {
                  return t(e, n, i);
              })
            : "object" == typeof exports
            ? (module.exports = t(e, require("wolfy87-eventemitter"), require("eventie")))
            : (e.imagesLoaded = t(e, e.EventEmitter, e.eventie));
    })(window, function (e, t, n) {
        function i(e, t) {
            for (var n in t) e[n] = t[n];
            return e;
        }
        function r(e) {
            return "[object Array]" === d.call(e);
        }
        function o(e) {
            var t = [];
            if (r(e)) t = e;
            else if ("number" == typeof e.length) for (var n = 0, i = e.length; i > n; n++) t.push(e[n]);
            else t.push(e);
            return t;
        }
        function s(e, t, n) {
            if (!(this instanceof s)) return new s(e, t);
            "string" == typeof e && (e = document.querySelectorAll(e)),
                (this.elements = o(e)),
                (this.options = i({}, this.options)),
                "function" == typeof t ? (n = t) : i(this.options, t),
                n && this.on("always", n),
                this.getImages(),
                a && (this.jqDeferred = new a.Deferred());
            var r = this;
            setTimeout(function () {
                r.check();
            });
        }
        function f(e) {
            this.img = e;
        }
        function c(e) {
            (this.src = e), (v[e] = this);
        }
        var a = e.jQuery,
            u = e.console,
            h = u !== void 0,
            d = Object.prototype.toString;
        (s.prototype = new t()),
            (s.prototype.options = {}),
            (s.prototype.getImages = function () {
                this.images = [];
                for (var e = 0, t = this.elements.length; t > e; e++) {
                    var n = this.elements[e];
                    "IMG" === n.nodeName && this.addImage(n);
                    var i = n.nodeType;
                    if (i && (1 === i || 9 === i || 11 === i))
                        for (var r = n.querySelectorAll("img"), o = 0, s = r.length; s > o; o++) {
                            var f = r[o];
                            this.addImage(f);
                        }
                }
            }),
            (s.prototype.addImage = function (e) {
                var t = new f(e);
                this.images.push(t);
            }),
            (s.prototype.check = function () {
                function e(e, r) {
                    return t.options.debug && h && u.log("confirm", e, r), t.progress(e), n++, n === i && t.complete(), !0;
                }
                var t = this,
                    n = 0,
                    i = this.images.length;
                if (((this.hasAnyBroken = !1), !i)) return this.complete(), void 0;
                for (var r = 0; i > r; r++) {
                    var o = this.images[r];
                    o.on("confirm", e), o.check();
                }
            }),
            (s.prototype.progress = function (e) {
                this.hasAnyBroken = this.hasAnyBroken || !e.isLoaded;
                var t = this;
                setTimeout(function () {
                    t.emit("progress", t, e), t.jqDeferred && t.jqDeferred.notify && t.jqDeferred.notify(t, e);
                });
            }),
            (s.prototype.complete = function () {
                var e = this.hasAnyBroken ? "fail" : "done";
                this.isComplete = !0;
                var t = this;
                setTimeout(function () {
                    if ((t.emit(e, t), t.emit("always", t), t.jqDeferred)) {
                        var n = t.hasAnyBroken ? "reject" : "resolve";
                        t.jqDeferred[n](t);
                    }
                });
            }),
            a &&
                (a.fn.imagesLoaded = function (e, t) {
                    var n = new s(this, e, t);
                    return n.jqDeferred.promise(a(this));
                }),
            (f.prototype = new t()),
            (f.prototype.check = function () {
                var e = v[this.img.src] || new c(this.img.src);
                if (e.isConfirmed) return this.confirm(e.isLoaded, "cached was confirmed"), void 0;
                if (this.img.complete && void 0 !== this.img.naturalWidth) return this.confirm(0 !== this.img.naturalWidth, "naturalWidth"), void 0;
                var t = this;
                e.on("confirm", function (e, n) {
                    return t.confirm(e.isLoaded, n), !0;
                }),
                    e.check();
            }),
            (f.prototype.confirm = function (e, t) {
                (this.isLoaded = e), this.emit("confirm", this, t);
            });
        var v = {};
        return (
            (c.prototype = new t()),
            (c.prototype.check = function () {
                if (!this.isChecked) {
                    var e = new Image();
                    n.bind(e, "load", this), n.bind(e, "error", this), (e.src = this.src), (this.isChecked = !0);
                }
            }),
            (c.prototype.handleEvent = function (e) {
                var t = "on" + e.type;
                this[t] && this[t](e);
            }),
            (c.prototype.onload = function (e) {
                this.confirm(!0, "onload"), this.unbindProxyEvents(e);
            }),
            (c.prototype.onerror = function (e) {
                this.confirm(!1, "onerror"), this.unbindProxyEvents(e);
            }),
            (c.prototype.confirm = function (e, t) {
                (this.isConfirmed = !0), (this.isLoaded = e), this.emit("confirm", this, t);
            }),
            (c.prototype.unbindProxyEvents = function (e) {
                n.unbind(e.target, "load", this), n.unbind(e.target, "error", this);
            }),
            s
        );
    }));
!(function (e) {
    e.fn.hoverIntent = function (t, n, o) {
        var r = { interval: 100, sensitivity: 6, timeout: 0 };
        r = "object" == typeof t ? e.extend(r, t) : e.isFunction(n) ? e.extend(r, { over: t, out: n, selector: o }) : e.extend(r, { over: t, out: t, selector: n });
        var v,
            i,
            u,
            s,
            h = function (e) {
                (v = e.pageX), (i = e.pageY);
            },
            I = function (t, n) {
                return (
                    (n.hoverIntent_t = clearTimeout(n.hoverIntent_t)),
                    Math.sqrt((u - v) * (u - v) + (s - i) * (s - i)) < r.sensitivity
                        ? (e(n).off("mousemove.hoverIntent", h), (n.hoverIntent_s = !0), r.over.apply(n, [t]))
                        : ((u = v),
                          (s = i),
                          (n.hoverIntent_t = setTimeout(function () {
                              I(t, n);
                          }, r.interval)),
                          void 0)
                );
            },
            a = function (e, t) {
                return (t.hoverIntent_t = clearTimeout(t.hoverIntent_t)), (t.hoverIntent_s = !1), r.out.apply(t, [e]);
            },
            c = function (t) {
                var n = e.extend({}, t),
                    o = this;
                o.hoverIntent_t && (o.hoverIntent_t = clearTimeout(o.hoverIntent_t)),
                    "mouseenter" === t.type
                        ? ((u = n.pageX),
                          (s = n.pageY),
                          e(o).on("mousemove.hoverIntent", h),
                          o.hoverIntent_s ||
                              (o.hoverIntent_t = setTimeout(function () {
                                  I(n, o);
                              }, r.interval)))
                        : (e(o).off("mousemove.hoverIntent", h),
                          o.hoverIntent_s &&
                              (o.hoverIntent_t = setTimeout(function () {
                                  a(n, o);
                              }, r.timeout)));
            };
        return this.on({ "mouseenter.hoverIntent": c, "mouseleave.hoverIntent": c }, r.selector);
    };
})(jQuery);
!(function (e) {
    var t,
        n,
        i,
        o,
        r,
        a,
        s,
        l = "Close",
        c = "BeforeClose",
        d = "AfterClose",
        u = "BeforeAppend",
        p = "MarkupParse",
        f = "Open",
        m = "Change",
        g = "mfp",
        v = "." + g,
        h = "mfp-ready",
        C = "mfp-removing",
        y = "mfp-prevent-close",
        w = function () {},
        b = !!window.jQuery,
        I = e(window),
        x = function (e, n) {
            t.ev.on(g + e + v, n);
        },
        k = function (t, n, i, o) {
            var r = document.createElement("div");
            return (r.className = "mfp-" + t), i && (r.innerHTML = i), o ? n && n.appendChild(r) : ((r = e(r)), n && r.appendTo(n)), r;
        },
        T = function (n, i) {
            t.ev.triggerHandler(g + n, i), t.st.callbacks && ((n = n.charAt(0).toLowerCase() + n.slice(1)), t.st.callbacks[n] && t.st.callbacks[n].apply(t, e.isArray(i) ? i : [i]));
        },
        E = function (n) {
            return (n === s && t.currTemplate.closeBtn) || ((t.currTemplate.closeBtn = e(t.st.closeMarkup.replace("%title%", t.st.tClose))), (s = n)), t.currTemplate.closeBtn;
        },
        _ = function () {
            e.magnificPopup.instance || ((t = new w()), t.init(), (e.magnificPopup.instance = t));
        },
        S = function () {
            var e = document.createElement("p").style,
                t = ["ms", "O", "Moz", "Webkit"];
            if (void 0 !== e.transition) return !0;
            for (; t.length; ) if (t.pop() + "Transition" in e) return !0;
            return !1;
        };
    (w.prototype = {
        constructor: w,
        init: function () {
            var n = navigator.appVersion;
            (t.isIE7 = -1 !== n.indexOf("MSIE 7.")),
                (t.isIE8 = -1 !== n.indexOf("MSIE 8.")),
                (t.isLowIE = t.isIE7 || t.isIE8),
                (t.isAndroid = /android/gi.test(n)),
                (t.isIOS = /iphone|ipad|ipod/gi.test(n)),
                (t.supportsTransition = S()),
                (t.probablyMobile = t.isAndroid || t.isIOS || /(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent)),
                (i = e(document.body)),
                (o = e(document)),
                (t.popupsCache = {});
        },
        open: function (n) {
            var i;
            if (n.isObj === !1) {
                (t.items = n.items.toArray()), (t.index = 0);
                var r,
                    s = n.items;
                for (i = 0; s.length > i; i++)
                    if (((r = s[i]), r.parsed && (r = r.el[0]), r === n.el[0])) {
                        t.index = i;
                        break;
                    }
            } else (t.items = e.isArray(n.items) ? n.items : [n.items]), (t.index = n.index || 0);
            if (t.isOpen) return void t.updateItemHTML();
            (t.types = []),
                (a = ""),
                (t.ev = n.mainEl && n.mainEl.length ? n.mainEl.eq(0) : o),
                n.key ? (t.popupsCache[n.key] || (t.popupsCache[n.key] = {}), (t.currTemplate = t.popupsCache[n.key])) : (t.currTemplate = {}),
                (t.st = e.extend(!0, {}, e.magnificPopup.defaults, n)),
                (t.fixedContentPos = "auto" === t.st.fixedContentPos ? !t.probablyMobile : t.st.fixedContentPos),
                t.st.modal && ((t.st.closeOnContentClick = !1), (t.st.closeOnBgClick = !1), (t.st.showCloseBtn = !1), (t.st.enableEscapeKey = !1)),
                t.bgOverlay ||
                    ((t.bgOverlay = k("bg").on("click" + v, function () {
                        t.close();
                    })),
                    (t.wrap = k("wrap")
                        .attr("tabindex", -1)
                        .on("click" + v, function (e) {
                            t._checkIfClose(e.target) && t.close();
                        })),
                    (t.container = k("container", t.wrap))),
                (t.contentContainer = k("content")),
                t.st.preloader && (t.preloader = k("preloader", t.container, t.st.tLoading));
            var l = e.magnificPopup.modules;
            for (i = 0; l.length > i; i++) {
                var c = l[i];
                (c = c.charAt(0).toUpperCase() + c.slice(1)), t["init" + c].call(t);
            }
            T("BeforeOpen"),
                t.st.showCloseBtn &&
                    (t.st.closeBtnInside
                        ? (x(p, function (e, t, n, i) {
                              n.close_replaceWith = E(i.type);
                          }),
                          (a += " mfp-close-btn-in"))
                        : t.wrap.append(E())),
                t.st.alignTop && (a += " mfp-align-top"),
                t.fixedContentPos ? t.wrap.css({ overflow: t.st.overflowY, overflowX: "hidden", overflowY: t.st.overflowY }) : t.wrap.css({ top: I.scrollTop(), position: "absolute" }),
                (t.st.fixedBgPos === !1 || ("auto" === t.st.fixedBgPos && !t.fixedContentPos)) && t.bgOverlay.css({ height: o.height(), position: "absolute" }),
                t.st.enableEscapeKey &&
                    o.on("keyup" + v, function (e) {
                        27 === e.keyCode && t.close();
                    }),
                I.on("resize" + v, function () {
                    t.updateSize();
                }),
                t.st.closeOnContentClick || (a += " mfp-auto-cursor"),
                a && t.wrap.addClass(a);
            var d = (t.wH = I.height()),
                u = {};
            if (t.fixedContentPos && t._hasScrollBar(d)) {
                var m = t._getScrollbarSize();
                m && (u.marginRight = m);
            }
            t.fixedContentPos && (t.isIE7 ? e("body, html").css("overflow", "hidden") : (u.overflow = "hidden"));
            var g = t.st.mainClass;
            return (
                t.isIE7 && (g += " mfp-ie7"),
                g && t._addClassToMFP(g),
                t.updateItemHTML(),
                T("BuildControls"),
                e("html").css(u),
                t.bgOverlay.add(t.wrap).prependTo(document.body),
                (t._lastFocusedEl = document.activeElement),
                setTimeout(function () {
                    t.content ? (t._addClassToMFP(h), t._setFocus()) : t.bgOverlay.addClass(h), o.on("focusin" + v, t._onFocusIn);
                }, 16),
                (t.isOpen = !0),
                t.updateSize(d),
                T(f),
                n
            );
        },
        close: function () {
            t.isOpen &&
                (T(c),
                (t.isOpen = !1),
                t.st.removalDelay && !t.isLowIE && t.supportsTransition
                    ? (t._addClassToMFP(C),
                      setTimeout(function () {
                          t._close();
                      }, t.st.removalDelay))
                    : t._close());
        },
        _close: function () {
            T(l);
            var n = C + " " + h + " ";
            if ((t.bgOverlay.detach(), t.wrap.detach(), t.container.empty(), t.st.mainClass && (n += t.st.mainClass + " "), t._removeClassFromMFP(n), t.fixedContentPos)) {
                var i = { marginRight: "" };
                t.isIE7 ? e("body, html").css("overflow", "") : (i.overflow = ""), e("html").css(i);
            }
            o.off("keyup" + v + " focusin" + v),
                t.ev.off(v),
                t.wrap.attr("class", "mfp-wrap").removeAttr("style"),
                t.bgOverlay.attr("class", "mfp-bg"),
                t.container.attr("class", "mfp-container"),
                !t.st.showCloseBtn || (t.st.closeBtnInside && t.currTemplate[t.currItem.type] !== !0) || (t.currTemplate.closeBtn && t.currTemplate.closeBtn.detach()),
                t._lastFocusedEl && e(t._lastFocusedEl).focus(),
                (t.currItem = null),
                (t.content = null),
                (t.currTemplate = null),
                (t.prevHeight = 0),
                T(d);
        },
        updateSize: function (e) {
            if (t.isIOS) {
                var n = document.documentElement.clientWidth / window.innerWidth,
                    i = window.innerHeight * n;
                t.wrap.css("height", i), (t.wH = i);
            } else t.wH = e || I.height();
            t.fixedContentPos || t.wrap.css("height", t.wH), T("Resize");
        },
        updateItemHTML: function () {
            var n = t.items[t.index];
            t.contentContainer.detach(), t.content && t.content.detach(), n.parsed || (n = t.parseEl(t.index));
            var i = n.type;
            if ((T("BeforeChange", [t.currItem ? t.currItem.type : "", i]), (t.currItem = n), !t.currTemplate[i])) {
                var o = t.st[i] ? t.st[i].markup : !1;
                T("FirstMarkupParse", o), (t.currTemplate[i] = o ? e(o) : !0);
            }
            r && r !== n.type && t.container.removeClass("mfp-" + r + "-holder");
            var a = t["get" + i.charAt(0).toUpperCase() + i.slice(1)](n, t.currTemplate[i]);
            t.appendContent(a, i), (n.preloaded = !0), T(m, n), (r = n.type), t.container.prepend(t.contentContainer), T("AfterChange");
        },
        appendContent: function (e, n) {
            (t.content = e),
                e ? (t.st.showCloseBtn && t.st.closeBtnInside && t.currTemplate[n] === !0 ? t.content.find(".mfp-close").length || t.content.append(E()) : (t.content = e)) : (t.content = ""),
                T(u),
                t.container.addClass("mfp-" + n + "-holder"),
                t.contentContainer.append(t.content);
        },
        parseEl: function (n) {
            var i = t.items[n],
                o = i.type;
            if (((i = i.tagName ? { el: e(i) } : { data: i, src: i.src }), i.el)) {
                for (var r = t.types, a = 0; r.length > a; a++)
                    if (i.el.hasClass("mfp-" + r[a])) {
                        o = r[a];
                        break;
                    }
                (i.src = i.el.attr("data-mfp-src")), i.src || (i.src = i.el.attr("href"));
            }
            return (i.type = o || t.st.type || "inline"), (i.index = n), (i.parsed = !0), (t.items[n] = i), T("ElementParse", i), t.items[n];
        },
        addGroup: function (e, n) {
            var i = function (i) {
                (i.mfpEl = this), t._openClick(i, e, n);
            };
            n || (n = {});
            var o = "click.magnificPopup";
            (n.mainEl = e), n.items ? ((n.isObj = !0), e.off(o).on(o, i)) : ((n.isObj = !1), n.delegate ? e.off(o).on(o, n.delegate, i) : ((n.items = e), e.off(o).on(o, i)));
        },
        _openClick: function (n, i, o) {
            var r = void 0 !== o.midClick ? o.midClick : e.magnificPopup.defaults.midClick;
            if (r || (2 !== n.which && !n.ctrlKey && !n.metaKey)) {
                var a = void 0 !== o.disableOn ? o.disableOn : e.magnificPopup.defaults.disableOn;
                if (a)
                    if (e.isFunction(a)) {
                        if (!a.call(t)) return !0;
                    } else if (a > I.width()) return !0;
                n.type && (n.preventDefault(), t.isOpen && n.stopPropagation()), (o.el = e(n.mfpEl)), o.delegate && (o.items = i.find(o.delegate)), t.open(o);
            }
        },
        updateStatus: function (e, i) {
            if (t.preloader) {
                n !== e && t.container.removeClass("mfp-s-" + n), i || "loading" !== e || (i = t.st.tLoading);
                var o = { status: e, text: i };
                T("UpdateStatus", o),
                    (e = o.status),
                    (i = o.text),
                    t.preloader.html(i),
                    t.preloader.find("a").on("click", function (e) {
                        e.stopImmediatePropagation();
                    }),
                    t.container.addClass("mfp-s-" + e),
                    (n = e);
            }
        },
        _checkIfClose: function (n) {
            if (!e(n).hasClass(y)) {
                var i = t.st.closeOnContentClick,
                    o = t.st.closeOnBgClick;
                if (i && o) return !0;
                if (!t.content || e(n).hasClass("mfp-close") || (t.preloader && n === t.preloader[0])) return !0;
                if (n === t.content[0] || e.contains(t.content[0], n)) {
                    if (i) return !0;
                } else if (o && e.contains(document, n)) return !0;
                return !1;
            }
        },
        _addClassToMFP: function (e) {
            t.bgOverlay.addClass(e), t.wrap.addClass(e);
        },
        _removeClassFromMFP: function (e) {
            this.bgOverlay.removeClass(e), t.wrap.removeClass(e);
        },
        _hasScrollBar: function (e) {
            return (t.isIE7 ? o.height() : document.body.scrollHeight) > (e || I.height());
        },
        _setFocus: function () {
            (t.st.focus ? t.content.find(t.st.focus).eq(0) : t.wrap).focus();
        },
        _onFocusIn: function (n) {
            return n.target === t.wrap[0] || e.contains(t.wrap[0], n.target) ? void 0 : (t._setFocus(), !1);
        },
        _parseMarkup: function (t, n, i) {
            var o;
            i.data && (n = e.extend(i.data, n)),
                T(p, [t, n, i]),
                e.each(n, function (e, n) {
                    if (void 0 === n || n === !1) return !0;
                    if (((o = e.split("_")), o.length > 1)) {
                        var i = t.find(v + "-" + o[0]);
                        if (i.length > 0) {
                            var r = o[1];
                            "replaceWith" === r ? i[0] !== n[0] && i.replaceWith(n) : "img" === r ? (i.is("img") ? i.attr("src", n) : i.replaceWith('<img src="' + n + '" class="' + i.attr("class") + '" />')) : i.attr(o[1], n);
                        }
                    } else t.find(v + "-" + e).html(n);
                });
        },
        _getScrollbarSize: function () {
            if (void 0 === t.scrollbarSize) {
                var e = document.createElement("div");
                (e.id = "mfp-sbm"),
                    (e.style.cssText = "width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;"),
                    document.body.appendChild(e),
                    (t.scrollbarSize = e.offsetWidth - e.clientWidth),
                    document.body.removeChild(e);
            }
            return t.scrollbarSize;
        },
    }),
        (e.magnificPopup = {
            instance: null,
            proto: w.prototype,
            modules: [],
            open: function (t, n) {
                return _(), (t = t ? e.extend(!0, {}, t) : {}), (t.isObj = !0), (t.index = n || 0), this.instance.open(t);
            },
            close: function () {
                return e.magnificPopup.instance && e.magnificPopup.instance.close();
            },
            registerModule: function (t, n) {
                n.options && (e.magnificPopup.defaults[t] = n.options), e.extend(this.proto, n.proto), this.modules.push(t);
            },
            defaults: {
                disableOn: 0,
                key: null,
                midClick: !1,
                mainClass: "",
                preloader: !0,
                focus: "",
                closeOnContentClick: !1,
                closeOnBgClick: !0,
                closeBtnInside: !0,
                showCloseBtn: !0,
                enableEscapeKey: !0,
                modal: !1,
                alignTop: !1,
                removalDelay: 0,
                fixedContentPos: "auto",
                fixedBgPos: "auto",
                overflowY: "auto",
                closeMarkup: '<button title="%title%" type="button" class="mfp-close">&times;</button>',
                tClose: "Close (Esc)",
                tLoading: "Loading...",
            },
        }),
        (e.fn.magnificPopup = function (n) {
            _();
            var i = e(this);
            if ("string" == typeof n)
                if ("open" === n) {
                    var o,
                        r = b ? i.data("magnificPopup") : i[0].magnificPopup,
                        a = parseInt(arguments[1], 10) || 0;
                    r.items ? (o = r.items[a]) : ((o = i), r.delegate && (o = o.find(r.delegate)), (o = o.eq(a))), t._openClick({ mfpEl: o }, i, r);
                } else t.isOpen && t[n].apply(t, Array.prototype.slice.call(arguments, 1));
            else (n = e.extend(!0, {}, n)), b ? i.data("magnificPopup", n) : (i[0].magnificPopup = n), t.addGroup(i, n);
            return i;
        });
    var P,
        O,
        z,
        M = "inline",
        B = function () {
            z && (O.after(z.addClass(P)).detach(), (z = null));
        };
    e.magnificPopup.registerModule(M, {
        options: { hiddenClass: "hide", markup: "", tNotFound: "Content not found" },
        proto: {
            initInline: function () {
                t.types.push(M),
                    x(l + "." + M, function () {
                        B();
                    });
            },
            getInline: function (n, i) {
                if ((B(), n.src)) {
                    var o = t.st.inline,
                        r = e(n.src);
                    if (r.length) {
                        var a = r[0].parentNode;
                        a && a.tagName && (O || ((P = o.hiddenClass), (O = k(P)), (P = "mfp-" + P)), (z = r.after(O).detach().removeClass(P))), t.updateStatus("ready");
                    } else t.updateStatus("error", o.tNotFound), (r = e("<div>"));
                    return (n.inlineElement = r), r;
                }
                return t.updateStatus("ready"), t._parseMarkup(i, {}, n), i;
            },
        },
    });
    var F,
        H = "ajax",
        L = function () {
            F && i.removeClass(F);
        },
        A = function () {
            L(), t.req && t.req.abort();
        };
    e.magnificPopup.registerModule(H, {
        options: { settings: null, cursor: "mfp-ajax-cur", tError: '<a href="%url%">The content</a> could not be loaded.' },
        proto: {
            initAjax: function () {
                t.types.push(H), (F = t.st.ajax.cursor), x(l + "." + H, A), x("BeforeChange." + H, A);
            },
            getAjax: function (n) {
                F && i.addClass(F), t.updateStatus("loading");
                var o = e.extend(
                    {
                        url: n.src,
                        success: function (i, o, r) {
                            var a = { data: i, xhr: r };
                            T("ParseAjax", a),
                                t.appendContent(e(a.data), H),
                                (n.finished = !0),
                                L(),
                                t._setFocus(),
                                setTimeout(function () {
                                    t.wrap.addClass(h);
                                }, 16),
                                t.updateStatus("ready"),
                                T("AjaxContentAdded");
                        },
                        error: function () {
                            L(), (n.finished = n.loadError = !0), t.updateStatus("error", t.st.ajax.tError.replace("%url%", n.src));
                        },
                    },
                    t.st.ajax.settings
                );
                return (t.req = e.ajax(o)), "";
            },
        },
    });
    var j,
        N = function (n) {
            if (n.data && void 0 !== n.data.title) return n.data.title;
            var i = t.st.image.titleSrc;
            if (i) {
                if (e.isFunction(i)) return i.call(t, n);
                if (n.el) return n.el.attr(i) || "";
            }
            return "";
        };
    e.magnificPopup.registerModule("image", {
        options: {
            markup:
                '<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',
            cursor: "mfp-zoom-out-cur",
            titleSrc: "title",
            verticalFit: !0,
            tError: '<a href="%url%">The image</a> could not be loaded.',
        },
        proto: {
            initImage: function () {
                var e = t.st.image,
                    n = ".image";
                t.types.push("image"),
                    x(f + n, function () {
                        "image" === t.currItem.type && e.cursor && i.addClass(e.cursor);
                    }),
                    x(l + n, function () {
                        e.cursor && i.removeClass(e.cursor), I.off("resize" + v);
                    }),
                    x("Resize" + n, t.resizeImage),
                    t.isLowIE && x("AfterChange", t.resizeImage);
            },
            resizeImage: function () {
                var e = t.currItem;
                if (e && e.img && t.st.image.verticalFit) {
                    var n = 0;
                    t.isLowIE && (n = parseInt(e.img.css("padding-top"), 10) + parseInt(e.img.css("padding-bottom"), 10)), e.img.css("max-height", t.wH - n);
                }
            },
            _onImageHasSize: function (e) {
                e.img && ((e.hasSize = !0), j && clearInterval(j), (e.isCheckingImgSize = !1), T("ImageHasSize", e), e.imgHidden && (t.content && t.content.removeClass("mfp-loading"), (e.imgHidden = !1)));
            },
            findImageSize: function (e) {
                var n = 0,
                    i = e.img[0],
                    o = function (r) {
                        j && clearInterval(j),
                            (j = setInterval(function () {
                                return i.naturalWidth > 0 ? void t._onImageHasSize(e) : (n > 200 && clearInterval(j), n++, void (3 === n ? o(10) : 40 === n ? o(50) : 100 === n && o(500)));
                            }, r));
                    };
                o(1);
            },
            getImage: function (n, i) {
                var o = 0,
                    r = function () {
                        n &&
                            (n.img[0].complete
                                ? (n.img.off(".mfploader"), n === t.currItem && (t._onImageHasSize(n), t.updateStatus("ready")), (n.hasSize = !0), (n.loaded = !0), T("ImageLoadComplete"))
                                : (o++, 200 > o ? setTimeout(r, 100) : a()));
                    },
                    a = function () {
                        n && (n.img.off(".mfploader"), n === t.currItem && (t._onImageHasSize(n), t.updateStatus("error", s.tError.replace("%url%", n.src))), (n.hasSize = !0), (n.loaded = !0), (n.loadError = !0));
                    },
                    s = t.st.image,
                    l = i.find(".mfp-img");
                if (l.length) {
                    var c = document.createElement("img");
                    (c.className = "mfp-img"), (n.img = e(c).on("load.mfploader", r).on("error.mfploader", a)), (c.src = n.src), l.is("img") && (n.img = n.img.clone()), n.img[0].naturalWidth > 0 && (n.hasSize = !0);
                }
                return (
                    t._parseMarkup(i, { title: N(n), img_replaceWith: n.img }, n),
                    t.resizeImage(),
                    n.hasSize
                        ? (j && clearInterval(j), n.loadError ? (i.addClass("mfp-loading"), t.updateStatus("error", s.tError.replace("%url%", n.src))) : (i.removeClass("mfp-loading"), t.updateStatus("ready")), i)
                        : (t.updateStatus("loading"), (n.loading = !0), n.hasSize || ((n.imgHidden = !0), i.addClass("mfp-loading"), t.findImageSize(n)), i)
                );
            },
        },
    });
    var W,
        R = function () {
            return void 0 === W && (W = void 0 !== document.createElement("p").style.MozTransform), W;
        };
    e.magnificPopup.registerModule("zoom", {
        options: {
            enabled: !1,
            easing: "ease-in-out",
            duration: 300,
            opener: function (e) {
                return e.is("img") ? e : e.find("img");
            },
        },
        proto: {
            initZoom: function () {
                var e,
                    n = t.st.zoom,
                    i = ".zoom";
                if (n.enabled && t.supportsTransition) {
                    var o,
                        r,
                        a = n.duration,
                        s = function (e) {
                            var t = e.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),
                                i = "all " + n.duration / 1e3 + "s " + n.easing,
                                o = { position: "fixed", zIndex: 9999, left: 0, top: 0, "-webkit-backface-visibility": "hidden" },
                                r = "transition";
                            return (o["-webkit-" + r] = o["-moz-" + r] = o["-o-" + r] = o[r] = i), t.css(o), t;
                        },
                        d = function () {
                            t.content.css("visibility", "visible");
                        };
                    x("BuildControls" + i, function () {
                        if (t._allowZoom()) {
                            if ((clearTimeout(o), t.content.css("visibility", "hidden"), (e = t._getItemToZoom()), !e)) return void d();
                            (r = s(e)),
                                r.css(t._getOffset()),
                                t.wrap.append(r),
                                (o = setTimeout(function () {
                                    r.css(t._getOffset(!0)),
                                        (o = setTimeout(function () {
                                            d(),
                                                setTimeout(function () {
                                                    r.remove(), (e = r = null), T("ZoomAnimationEnded");
                                                }, 16);
                                        }, a));
                                }, 16));
                        }
                    }),
                        x(c + i, function () {
                            if (t._allowZoom()) {
                                if ((clearTimeout(o), (t.st.removalDelay = a), !e)) {
                                    if (((e = t._getItemToZoom()), !e)) return;
                                    r = s(e);
                                }
                                r.css(t._getOffset(!0)),
                                    t.wrap.append(r),
                                    t.content.css("visibility", "hidden"),
                                    setTimeout(function () {
                                        r.css(t._getOffset());
                                    }, 16);
                            }
                        }),
                        x(l + i, function () {
                            t._allowZoom() && (d(), r && r.remove(), (e = null));
                        });
                }
            },
            _allowZoom: function () {
                return "image" === t.currItem.type;
            },
            _getItemToZoom: function () {
                return t.currItem.hasSize ? t.currItem.img : !1;
            },
            _getOffset: function (n) {
                var i;
                i = n ? t.currItem.img : t.st.zoom.opener(t.currItem.el || t.currItem);
                var o = i.offset(),
                    r = parseInt(i.css("padding-top"), 10),
                    a = parseInt(i.css("padding-bottom"), 10);
                o.top -= e(window).scrollTop() - r;
                var s = { width: i.width(), height: (b ? i.innerHeight() : i[0].offsetHeight) - a - r };
                return R() ? (s["-moz-transform"] = s.transform = "translate(" + o.left + "px," + o.top + "px)") : ((s.left = o.left), (s.top = o.top)), s;
            },
        },
    });
    var Z = "iframe",
        q = "//about:blank",
        D = function (e) {
            if (t.currTemplate[Z]) {
                var n = t.currTemplate[Z].find("iframe");
                n.length && (e || (n[0].src = q), t.isIE8 && n.css("display", e ? "block" : "none"));
            }
        };
    e.magnificPopup.registerModule(Z, {
        options: {
            markup: '<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',
            srcAction: "iframe_src",
            patterns: {
                youtube: { index: "youtube.com", id: "v=", src: "//www.youtube.com/embed/%id%?autoplay=1" },
                vimeo: { index: "vimeo.com/", id: "/", src: "//player.vimeo.com/video/%id%?autoplay=1" },
                gmaps: { index: "//maps.google.", src: "%id%&output=embed" },
            },
        },
        proto: {
            initIframe: function () {
                t.types.push(Z),
                    x("BeforeChange", function (e, t, n) {
                        t !== n && (t === Z ? D() : n === Z && D(!0));
                    }),
                    x(l + "." + Z, function () {
                        D();
                    });
            },
            getIframe: function (n, i) {
                var o = n.src,
                    r = t.st.iframe;
                e.each(r.patterns, function () {
                    return o.indexOf(this.index) > -1 ? (this.id && (o = "string" == typeof this.id ? o.substr(o.lastIndexOf(this.id) + this.id.length, o.length) : this.id.call(this, o)), (o = this.src.replace("%id%", o)), !1) : void 0;
                });
                var a = {};
                return r.srcAction && (a[r.srcAction] = o), t._parseMarkup(i, a, n), t.updateStatus("ready"), i;
            },
        },
    });
    var K = function (e) {
            var n = t.items.length;
            return e > n - 1 ? e - n : 0 > e ? n + e : e;
        },
        Y = function (e, t, n) {
            return e.replace(/%curr%/gi, t + 1).replace(/%total%/gi, n);
        };
    e.magnificPopup.registerModule("gallery", {
        options: {
            enabled: !1,
            arrowMarkup: '<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',
            preload: [0, 2],
            navigateByImgClick: !0,
            arrows: !0,
            tPrev: "Previous (Left arrow key)",
            tNext: "Next (Right arrow key)",
            tCounter: "%curr% of %total%",
        },
        proto: {
            initGallery: function () {
                var n = t.st.gallery,
                    i = ".mfp-gallery",
                    r = Boolean(e.fn.mfpFastClick);
                return (
                    (t.direction = !0),
                    n && n.enabled
                        ? ((a += " mfp-gallery"),
                          x(f + i, function () {
                              n.navigateByImgClick &&
                                  t.wrap.on("click" + i, ".mfp-img", function () {
                                      return t.items.length > 1 ? (t.next(), !1) : void 0;
                                  }),
                                  o.on("keydown" + i, function (e) {
                                      37 === e.keyCode ? t.prev() : 39 === e.keyCode && t.next();
                                  });
                          }),
                          x("UpdateStatus" + i, function (e, n) {
                              n.text && (n.text = Y(n.text, t.currItem.index, t.items.length));
                          }),
                          x(p + i, function (e, i, o, r) {
                              var a = t.items.length;
                              o.counter = a > 1 ? Y(n.tCounter, r.index, a) : "";
                          }),
                          x("BuildControls" + i, function () {
                              if (t.items.length > 1 && n.arrows && !t.arrowLeft) {
                                  var i = n.arrowMarkup,
                                      o = (t.arrowLeft = e(i.replace(/%title%/gi, n.tPrev).replace(/%dir%/gi, "left")).addClass(y)),
                                      a = (t.arrowRight = e(i.replace(/%title%/gi, n.tNext).replace(/%dir%/gi, "right")).addClass(y)),
                                      s = r ? "mfpFastClick" : "click";
                                  o[s](function () {
                                      t.prev();
                                  }),
                                      a[s](function () {
                                          t.next();
                                      }),
                                      t.isIE7 && (k("b", o[0], !1, !0), k("a", o[0], !1, !0), k("b", a[0], !1, !0), k("a", a[0], !1, !0)),
                                      t.container.append(o.add(a));
                              }
                          }),
                          x(m + i, function () {
                              t._preloadTimeout && clearTimeout(t._preloadTimeout),
                                  (t._preloadTimeout = setTimeout(function () {
                                      t.preloadNearbyImages(), (t._preloadTimeout = null);
                                  }, 16));
                          }),
                          void x(l + i, function () {
                              o.off(i), t.wrap.off("click" + i), t.arrowLeft && r && t.arrowLeft.add(t.arrowRight).destroyMfpFastClick(), (t.arrowRight = t.arrowLeft = null);
                          }))
                        : !1
                );
            },
            next: function () {
                (t.direction = !0), (t.index = K(t.index + 1)), t.updateItemHTML();
            },
            prev: function () {
                (t.direction = !1), (t.index = K(t.index - 1)), t.updateItemHTML();
            },
            goTo: function (e) {
                (t.direction = e >= t.index), (t.index = e), t.updateItemHTML();
            },
            preloadNearbyImages: function () {
                var e,
                    n = t.st.gallery.preload,
                    i = Math.min(n[0], t.items.length),
                    o = Math.min(n[1], t.items.length);
                for (e = 1; (t.direction ? o : i) >= e; e++) t._preloadItem(t.index + e);
                for (e = 1; (t.direction ? i : o) >= e; e++) t._preloadItem(t.index - e);
            },
            _preloadItem: function (n) {
                if (((n = K(n)), !t.items[n].preloaded)) {
                    var i = t.items[n];
                    i.parsed || (i = t.parseEl(n)),
                        T("LazyLoad", i),
                        "image" === i.type &&
                            (i.img = e('<img class="mfp-img" />')
                                .on("load.mfploader", function () {
                                    i.hasSize = !0;
                                })
                                .on("error.mfploader", function () {
                                    (i.hasSize = !0), (i.loadError = !0), T("LazyLoadError", i);
                                })
                                .attr("src", i.src)),
                        (i.preloaded = !0);
                }
            },
        },
    });
    var U = "retina";
    e.magnificPopup.registerModule(U, {
        options: {
            replaceSrc: function (e) {
                return e.src.replace(/\.\w+$/, function (e) {
                    return "@2x" + e;
                });
            },
            ratio: 1,
        },
        proto: {
            initRetina: function () {
                if (window.devicePixelRatio > 1) {
                    var e = t.st.retina,
                        n = e.ratio;
                    (n = isNaN(n) ? n() : n),
                        n > 1 &&
                            (x("ImageHasSize." + U, function (e, t) {
                                t.img.css({ "max-width": t.img[0].naturalWidth / n, width: "100%" });
                            }),
                            x("ElementParse." + U, function (t, i) {
                                i.src = e.replaceSrc(i, n);
                            }));
                }
            },
        },
    }),
        (function () {
            var t = 1e3,
                n = "ontouchstart" in window,
                i = function () {
                    I.off("touchmove" + r + " touchend" + r);
                },
                o = "mfpFastClick",
                r = "." + o;
            (e.fn.mfpFastClick = function (o) {
                return e(this).each(function () {
                    var a,
                        s = e(this);
                    if (n) {
                        var l, c, d, u, p, f;
                        s.on("touchstart" + r, function (e) {
                            (u = !1),
                                (f = 1),
                                (p = e.originalEvent ? e.originalEvent.touches[0] : e.touches[0]),
                                (c = p.clientX),
                                (d = p.clientY),
                                I.on("touchmove" + r, function (e) {
                                    (p = e.originalEvent ? e.originalEvent.touches : e.touches), (f = p.length), (p = p[0]), (Math.abs(p.clientX - c) > 10 || Math.abs(p.clientY - d) > 10) && ((u = !0), i());
                                }).on("touchend" + r, function (e) {
                                    i(),
                                        u ||
                                            f > 1 ||
                                            ((a = !0),
                                            e.preventDefault(),
                                            clearTimeout(l),
                                            (l = setTimeout(function () {
                                                a = !1;
                                            }, t)),
                                            o());
                                });
                        });
                    }
                    s.on("click" + r, function () {
                        a || o();
                    });
                });
            }),
                (e.fn.destroyMfpFastClick = function () {
                    e(this).off("touchstart" + r + " click" + r), n && I.off("touchmove" + r + " touchend" + r);
                });
        })(),
        _();
})(window.jQuery || window.Zepto);
+(function (a) {
    "use strict";
    function c(c) {
        return this.each(function () {
            var d = a(this),
                e = d.data("bs.tab");
            e || d.data("bs.tab", (e = new b(this))), "string" == typeof c && e[c]();
        });
    }
    var b = function (b) {
        this.element = a(b);
    };
    (b.VERSION = "3.3.7"),
        (b.TRANSITION_DURATION = 150),
        (b.prototype.show = function () {
            var b = this.element,
                c = b.closest("ul:not(.dropdown-menu)"),
                d = b.data("target");
            if ((d || ((d = b.attr("href")), (d = d && d.replace(/.*(?=#[^\s]*$)/, ""))), !b.parent("li").hasClass("active"))) {
                var e = c.find(".active:last a"),
                    f = a.Event("hide.bs.tab", { relatedTarget: b[0] }),
                    g = a.Event("show.bs.tab", { relatedTarget: e[0] });
                if ((e.trigger(f), b.trigger(g), !g.isDefaultPrevented() && !f.isDefaultPrevented())) {
                    var h = a(d);
                    this.activate(b.closest("li"), c),
                        this.activate(h, h.parent(), function () {
                            e.trigger({ type: "hidden.bs.tab", relatedTarget: b[0] }), b.trigger({ type: "shown.bs.tab", relatedTarget: e[0] });
                        });
                }
            }
        }),
        (b.prototype.activate = function (c, d, e) {
            function h() {
                f.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1),
                    c.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0),
                    g ? (c[0].offsetWidth, c.addClass("in")) : c.removeClass("fade"),
                    c.parent(".dropdown-menu").length && c.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0),
                    e && e();
            }
            var f = d.find("> .active"),
                g = e && a.support.transition && ((f.length && f.hasClass("fade")) || !!d.find("> .fade").length);
            f.length && g ? f.one("bsTransitionEnd", h).emulateTransitionEnd(b.TRANSITION_DURATION) : h(), f.removeClass("in");
        });
    var d = a.fn.tab;
    (a.fn.tab = c),
        (a.fn.tab.Constructor = b),
        (a.fn.tab.noConflict = function () {
            return (a.fn.tab = d), this;
        });
    var e = function (b) {
        b.preventDefault(), c.call(a(this), "show");
    };
    a(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', e).on("click.bs.tab.data-api", '[data-toggle="pill"]', e);
})(jQuery);
+(function (a) {
    "use strict";
    function c(b) {
        var c,
            d = b.attr("data-target") || ((c = b.attr("href")) && c.replace(/.*(?=#[^\s]+$)/, ""));
        return a(d);
    }
    function d(c) {
        return this.each(function () {
            var d = a(this),
                e = d.data("bs.collapse"),
                f = a.extend({}, b.DEFAULTS, d.data(), "object" == typeof c && c);
            !e && f.toggle && /show|hide/.test(c) && (f.toggle = !1), e || d.data("bs.collapse", (e = new b(this, f))), "string" == typeof c && e[c]();
        });
    }
    var b = function (c, d) {
        (this.$element = a(c)),
            (this.options = a.extend({}, b.DEFAULTS, d)),
            (this.$trigger = a('[data-toggle="collapse"][href="#' + c.id + '"],[data-toggle="collapse"][data-target="#' + c.id + '"]')),
            (this.transitioning = null),
            this.options.parent ? (this.$parent = this.getParent()) : this.addAriaAndCollapsedClass(this.$element, this.$trigger),
            this.options.toggle && this.toggle();
    };
    (b.VERSION = "3.3.7"),
        (b.TRANSITION_DURATION = 350),
        (b.DEFAULTS = { toggle: !0 }),
        (b.prototype.dimension = function () {
            var a = this.$element.hasClass("width");
            return a ? "width" : "height";
        }),
        (b.prototype.show = function () {
            if (!this.transitioning && !this.$element.hasClass("in")) {
                var c,
                    e = this.$parent && this.$parent.children(".panel").children(".in, .collapsing");
                if (!(e && e.length && ((c = e.data("bs.collapse")), c && c.transitioning))) {
                    var f = a.Event("show.bs.collapse");
                    if ((this.$element.trigger(f), !f.isDefaultPrevented())) {
                        e && e.length && (d.call(e, "hide"), c || e.data("bs.collapse", null));
                        var g = this.dimension();
                        this.$element.removeClass("collapse").addClass("collapsing")[g](0).attr("aria-expanded", !0), this.$trigger.removeClass("collapsed").attr("aria-expanded", !0), (this.transitioning = 1);
                        var h = function () {
                            this.$element.removeClass("collapsing").addClass("collapse in")[g](""), (this.transitioning = 0), this.$element.trigger("shown.bs.collapse");
                        };
                        if (!a.support.transition) return h.call(this);
                        var i = a.camelCase(["scroll", g].join("-"));
                        this.$element.one("bsTransitionEnd", a.proxy(h, this)).emulateTransitionEnd(b.TRANSITION_DURATION)[g](this.$element[0][i]);
                    }
                }
            }
        }),
        (b.prototype.hide = function () {
            if (!this.transitioning && this.$element.hasClass("in")) {
                var c = a.Event("hide.bs.collapse");
                if ((this.$element.trigger(c), !c.isDefaultPrevented())) {
                    var d = this.dimension();
                    this.$element[d](this.$element[d]())[0].offsetHeight,
                        this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1),
                        this.$trigger.addClass("collapsed").attr("aria-expanded", !1),
                        (this.transitioning = 1);
                    var e = function () {
                        (this.transitioning = 0), this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse");
                    };
                    return a.support.transition ? void this.$element[d](0).one("bsTransitionEnd", a.proxy(e, this)).emulateTransitionEnd(b.TRANSITION_DURATION) : e.call(this);
                }
            }
        }),
        (b.prototype.toggle = function () {
            this[this.$element.hasClass("in") ? "hide" : "show"]();
        }),
        (b.prototype.getParent = function () {
            return a(this.options.parent)
                .find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]')
                .each(
                    a.proxy(function (b, d) {
                        var e = a(d);
                        this.addAriaAndCollapsedClass(c(e), e);
                    }, this)
                )
                .end();
        }),
        (b.prototype.addAriaAndCollapsedClass = function (a, b) {
            var c = a.hasClass("in");
            a.attr("aria-expanded", c), b.toggleClass("collapsed", !c).attr("aria-expanded", c);
        });
    var e = a.fn.collapse;
    (a.fn.collapse = d),
        (a.fn.collapse.Constructor = b),
        (a.fn.collapse.noConflict = function () {
            return (a.fn.collapse = e), this;
        }),
        a(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', function (b) {
            var e = a(this);
            e.attr("data-target") || b.preventDefault();
            var f = c(e),
                g = f.data("bs.collapse"),
                h = g ? "toggle" : e.data();
            d.call(f, h);
        });
})(jQuery);
+(function (a) {
    "use strict";
    function c(c) {
        return this.each(function () {
            var d = a(this),
                e = d.data("bs.button"),
                f = "object" == typeof c && c;
            e || d.data("bs.button", (e = new b(this, f))), "toggle" == c ? e.toggle() : c && e.setState(c);
        });
    }
    var b = function (c, d) {
        (this.$element = a(c)), (this.options = a.extend({}, b.DEFAULTS, d)), (this.isLoading = !1);
    };
    (b.VERSION = "3.3.7"),
        (b.DEFAULTS = { loadingText: "loading..." }),
        (b.prototype.setState = function (b) {
            var c = "disabled",
                d = this.$element,
                e = d.is("input") ? "val" : "html",
                f = d.data();
            (b += "Text"),
                null == f.resetText && d.data("resetText", d[e]()),
                setTimeout(
                    a.proxy(function () {
                        d[e](null == f[b] ? this.options[b] : f[b]), "loadingText" == b ? ((this.isLoading = !0), d.addClass(c).attr(c, c).prop(c, !0)) : this.isLoading && ((this.isLoading = !1), d.removeClass(c).removeAttr(c).prop(c, !1));
                    }, this),
                    0
                );
        }),
        (b.prototype.toggle = function () {
            var a = !0,
                b = this.$element.closest('[data-toggle="buttons"]');
            if (b.length) {
                var c = this.$element.find("input");
                "radio" == c.prop("type")
                    ? (c.prop("checked") && (a = !1), b.find(".active").removeClass("active"), this.$element.addClass("active"))
                    : "checkbox" == c.prop("type") && (c.prop("checked") !== this.$element.hasClass("active") && (a = !1), this.$element.toggleClass("active")),
                    c.prop("checked", this.$element.hasClass("active")),
                    a && c.trigger("change");
            } else this.$element.attr("aria-pressed", !this.$element.hasClass("active")), this.$element.toggleClass("active");
        });
    var d = a.fn.button;
    (a.fn.button = c),
        (a.fn.button.Constructor = b),
        (a.fn.button.noConflict = function () {
            return (a.fn.button = d), this;
        }),
        a(document)
            .on("click.bs.button.data-api", '[data-toggle^="button"]', function (b) {
                var d = a(b.target).closest(".btn");
                c.call(d, "toggle"), a(b.target).is('input[type="radio"], input[type="checkbox"]') || (b.preventDefault(), d.is("input,button") ? d.trigger("focus") : d.find("input:visible,button:visible").first().trigger("focus"));
            })
            .on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', function (b) {
                a(b.target)
                    .closest(".btn")
                    .toggleClass("focus", /^focus(in)?$/.test(b.type));
            });
})(jQuery);
(function (h) {
    var k = {
            host: "https://www.instagram.com/",
            username: "",
            tag: "",
            container: "",
            display_profile: !0,
            display_biography: !0,
            display_gallery: !0,
            display_igtv: !1,
            get_data: !1,
            callback: null,
            styling: !0,
            items: 8,
            items_per_row: 4,
            margin: 0.5,
            image_size: 640,
        },
        l = { 150: 0, 240: 1, 320: 2, 480: 3, 640: 4 };
    h.instagramFeed = function (r) {
        var a = h.fn.extend({}, k, r);
        if ("" == a.username && "" == a.tag) return console.error("Instagram Feed: Error, no username or tag found."), !1;
        "undefined" !== typeof a.get_raw_json && (console.warn("Instagram Feed: get_raw_json is deprecated. See use get_data instead"), (a.get_data = a.get_raw_json));
        if (!a.get_data && "" == a.container) return console.error("Instagram Feed: Error, no container found."), !1;
        if (a.get_data && null == a.callback) return console.error("Instagram Feed: Error, no callback defined to get the raw json"), !1;
        var m = "" == a.username;
        h.get(m ? a.host + "explore/tags/" + a.tag : a.host + a.username, function (b) {
            b = b.split("window._sharedData = ")[1].split("\x3c/script>")[0];
            b = JSON.parse(b.substr(0, b.length - 1));
            b = b.entry_data.ProfilePage || b.entry_data.TagPage;
            b = b[0].graphql.user || b[0].graphql.hashtag;
            if (a.get_data) a.callback(b);
            else {
                var d = "",
                    f = "",
                    g = "",
                    e = "",
                    n = "";
                a.styling &&
                    ((d = " style='text-align:center;'"),
                    (f = " style='border-radius:10em;width:15%;max-width:125px;min-width:50px;'"),
                    (g = " style='font-size:1.2em;'"),
                    (e = " style='font-size:1em;'"),
                    (n = " style='margin:" + a.margin + "% " + a.margin + "%;width:" + (100 - 2 * a.margin * a.items_per_row) / a.items_per_row + "%;float:left;'"));
                var c = "";
                a.display_profile &&
                    ((c = c + ("<div class='instagram_profile'" + d + ">") + ("\t<img class='instagram_profile_image' src='" + b.profile_pic_url + "' alt='" + b.name + " profile pic'" + f + " />")),
                    (c = m
                        ? c + ("\t<p class='instagram_tag'" + g + "><a href='https://www.instagram.com/explore/tags/" + a.tag + "' rel='noopener' target='_blank'>#" + a.tag + "</a></p>")
                        : c + ("\t<p class='instagram_username'" + g + ">@" + b.full_name + " (<a href='https://www.instagram.com/" + a.username + "' rel='noopener' target='_blank'>@" + a.username + "</a>)</p>")),
                    !m && a.display_biography && (c += "\t<p class='instagram_biography'" + e + ">" + b.biography + "</p>"),
                    (c += "</div>"));
                g = "undefined" !== typeof l[a.image_size] ? l[a.image_size] : l[640];
                if (a.display_gallery)
                    if ("undefined" !== typeof b.is_private && !0 === b.is_private) c += "<p class='instagram_private'><strong>This profile is private</strong></p>";
                    else {
                        e = (b.edge_owner_to_timeline_media || b.edge_hashtag_to_media).edges;
                        f = e.length > a.items ? a.items : e.length;
                        c += "<div class='instagram_gallery'>";
                        for (d = 0; d < f; d++) {
                            var k = "https://www.instagram.com/p/" + e[d].node.shortcode;
                            switch (e[d].node.__typename) {
                                case "GraphSidecar":
                                    var p = "sidecar";
                                    var q = e[d].node.thumbnail_resources[g].src;
                                    break;
                                case "GraphVideo":
                                    p = "video";
                                    q = e[d].node.thumbnail_src;
                                    break;
                                default:
                                    (p = "image"), (q = e[d].node.thumbnail_resources[g].src);
                            }
                            c += "\t<a href='" + k + "' class='instagram-" + p + "' rel='noopener' target='_blank'>";
                            c += "   \t<img src='" + q + "' alt='" + b.name + " instagram image " + d + "'" + n + " />";
                            c += "\t</a>";
                        }
                        c += "</div>";
                    }
                if (a.display_igtv && "undefined" !== typeof b.edge_felix_video_timeline && ((b = b.edge_felix_video_timeline.edges), (f = b.length > a.items ? a.items : b.length), 0 < b.length)) {
                    c += "<div class='instagram_igtv'>";
                    for (d = 0; d < f; d++)
                        (c += "\t<a href='https://www.instagram.com/p/" + b[d].node.shortcode + "' rel='noopener' target='_blank'>"),
                            (c += "\t\t<img src='" + b[d].node.thumbnail_src + "' alt='" + a.username + " instagram image " + d + "'" + n + " />"),
                            (c += "\t</a>");
                    c += "</div>";
                }
                h(a.container).html(c);
            }
        }).fail(function (a) {
            console.error("Instagram Feed: Unable to fetch the given user/tag. Instagram responded with the status code: ", a.status);
        });
        return !0;
    };
})(jQuery);
!(function (t, e) {
    function n(e, n, l, a) {
        var r = { data: a || (n ? n.data : {}), _wrap: n ? n._wrap : null, tmpl: null, parent: n || null, nodes: [], calls: c, nest: m, wrap: f, html: s, update: d };
        return e && t.extend(r, e, { nodes: [], parent: n }), l && ((r.tmpl = l), (r._ctnt = r._ctnt || r.tmpl(t, r)), (r.key = ++T), ((j.length ? v : g)[T] = r)), r;
    }
    function l(e, n, r) {
        var p,
            i = r
                ? t.map(r, function (t) {
                      return "string" == typeof t ? (e.key ? t.replace(/(<\w+)(?=[\s>])(?![^>]*_tmplitem)([^>]*)/g, "$1 " + y + '="' + e.key + '" $2') : t) : l(t, e, t._ctnt);
                  })
                : e;
        return n
            ? i
            : ((i = i.join("")),
              i.replace(/^\s*([^<\s][^<]*)?(<[\w\W]+>)([^>]*[^>\s])?\s*$/, function (e, n, l, r) {
                  (p = t(l).get()), u(p), n && (p = a(n).concat(p)), r && (p = p.concat(a(r)));
              }),
              p ? p : a(i));
    }
    function a(e) {
        var n = document.createElement("div");
        return (n.innerHTML = e), t.makeArray(n.childNodes);
    }
    function r(e) {
        return new Function(
            "jQuery",
            "$item",
            "var $=jQuery,call,_=[],$data=$item.data;with($data){_.push('" +
                t
                    .trim(e)
                    .replace(/([\\'])/g, "\\$1")
                    .replace(/[\r\t\n]/g, " ")
                    .replace(/\$\{([^\}]*)\}/g, "{{= $1}}")
                    .replace(/\{\{(\/?)(\w+|.)(?:\(((?:[^\}]|\}(?!\}))*?)?\))?(?:\s+(.*?)?)?(\(((?:[^\}]|\}(?!\}))*?)\))?\s*\}\}/g, function (e, n, l, a, r, p, o) {
                        var u,
                            c,
                            m,
                            f = t.tmpl.tag[l];
                        if (!f) throw "Template command not found: " + l;
                        return (
                            (u = f._default || []),
                            p && !/\w$/.test(r) && ((r += p), (p = "")),
                            r
                                ? ((r = i(r)),
                                  (o = o ? "," + i(o) + ")" : p ? ")" : ""),
                                  (c = p ? (r.indexOf(".") > -1 ? r + p : "(" + r + ").call($item" + o) : r),
                                  (m = p ? c : "(typeof(" + r + ")==='function'?(" + r + ").call($item):(" + r + "))"))
                                : (m = c = u.$1 || "null"),
                            (a = i(a)),
                            "');" +
                                f[n ? "close" : "open"]
                                    .split("$notnull_1")
                                    .join(r ? "typeof(" + r + ")!=='undefined' && (" + r + ")!=null" : "true")
                                    .split("$1a")
                                    .join(m)
                                    .split("$1")
                                    .join(c)
                                    .split("$2")
                                    .join(
                                        a
                                            ? a.replace(/\s*([^\(]+)\s*(\((.*?)\))?/g, function (t, e, n, l) {
                                                  return (l = l ? "," + l + ")" : n ? ")" : ""), l ? "(" + e + ").call($item" + l : t;
                                              })
                                            : u.$2 || ""
                                    ) +
                                "_.push('"
                        );
                    }) +
                "');}return _;"
        );
    }
    function p(e, n) {
        e._wrap = l(e, !0, t.isArray(n) ? n : [_.test(n) ? n : t(n).html()]).join("");
    }
    function i(t) {
        return t ? t.replace(/\\'/g, "'").replace(/\\\\/g, "\\") : null;
    }
    function o(t) {
        var e = document.createElement("div");
        return e.appendChild(t.cloneNode(!0)), e.innerHTML;
    }
    function u(e) {
        function l(e) {
            function l(t) {
                (t += u), (p = c[t] = c[t] || n(p, g[p.parent.key + u] || p.parent, null, !0));
            }
            var a,
                r,
                p,
                i,
                o = e;
            if ((i = e.getAttribute(y))) {
                for (; o.parentNode && 1 === (o = o.parentNode).nodeType && !(a = o.getAttribute(y)); );
                a !== i && ((o = o.parentNode ? (11 === o.nodeType ? 0 : o.getAttribute(y) || 0) : 0), (p = g[i]) || ((p = v[i]), (p = n(p, g[o] || v[o], null, !0)), (p.key = ++T), (g[T] = p)), k && l(i)), e.removeAttribute(y);
            } else k && (p = t.data(e, "tmplItem")) && (l(p.key), (g[p.key] = p), (o = t.data(e.parentNode, "tmplItem")), (o = o ? o.key : 0));
            if (p) {
                for (r = p; r && r.key != o; ) r.nodes.push(e), (r = r.parent);
                delete p._ctnt, delete p._wrap, t.data(e, "tmplItem", p);
            }
        }
        var a,
            r,
            p,
            i,
            o,
            u = "_" + k,
            c = {};
        for (p = 0, i = e.length; i > p; p++)
            if (1 === (a = e[p]).nodeType) {
                for (r = a.getElementsByTagName("*"), o = r.length - 1; o >= 0; o--) l(r[o]);
                l(a);
            }
    }
    function c(t, e, n, l) {
        return t ? void j.push({ _: t, tmpl: e, item: this, data: n, options: l }) : j.pop();
    }
    function m(e, n, l) {
        return t.tmpl(t.template(e), n, l, this);
    }
    function f(e, n) {
        var l = e.options || {};
        return (l.wrapped = n), t.tmpl(t.template(e.tmpl), e.data, l, e.item);
    }
    function s(e, n) {
        var l = this._wrap;
        return t.map(t(t.isArray(l) ? l.join("") : l).filter(e || "*"), function (t) {
            return n ? t.innerText || t.textContent : t.outerHTML || o(t);
        });
    }
    function d() {
        var e = this.nodes;
        t.tmpl(null, null, null, this).insertBefore(e[0]), t(e).remove();
    }
    var $,
        h = t.fn.domManip,
        y = "_tmplitem",
        _ = /^[^<]*(<[\w\W]+>)[^>]*$|\{\{\! /,
        g = {},
        v = {},
        w = { key: 0, data: {} },
        T = 0,
        k = 0,
        j = [];
    t.each({ appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith" }, function (e, n) {
        t.fn[e] = function (l) {
            var a,
                r,
                p,
                i,
                o = [],
                u = t(l),
                c = 1 === this.length && this[0].parentNode;
            if ((($ = g || {}), c && 11 === c.nodeType && 1 === c.childNodes.length && 1 === u.length)) u[n](this[0]), (o = this);
            else {
                for (r = 0, p = u.length; p > r; r++) (k = r), (a = (r > 0 ? this.clone(!0) : this).get()), t.fn[n].apply(t(u[r]), a), (o = o.concat(a));
                (k = 0), (o = this.pushStack(o, e, u.selector));
            }
            return (i = $), ($ = null), t.tmpl.complete(i), o;
        };
    }),
        t.fn.extend({
            tmpl: function (e, n, l) {
                return t.tmpl(this[0], e, n, l);
            },
            tmplItem: function () {
                return t.tmplItem(this[0]);
            },
            template: function (e) {
                return t.template(e, this[0]);
            },
            domManip: function (e, n, l, a) {
                if (e[0] && e[0].nodeType) {
                    for (var r, p = t.makeArray(arguments), i = e.length, o = 0; i > o && !(r = t.data(e[o++], "tmplItem")); );
                    i > 1 && (p[0] = [t.makeArray(e)]),
                        r &&
                            k &&
                            (p[2] = function (e) {
                                t.tmpl.afterManip(this, e, l);
                            }),
                        h.apply(this, p);
                } else h.apply(this, arguments);
                return (k = 0), $ || t.tmpl.complete(g), this;
            },
        }),
        t.extend({
            tmpl: function (e, a, r, i) {
                var o,
                    u = !i;
                if (u) (i = w), (e = t.template[e] || t.template(null, e)), (v = {});
                else if (!e) return (e = i.tmpl), (g[i.key] = i), (i.nodes = []), i.wrapped && p(i, i.wrapped), t(l(i, null, i.tmpl(t, i)));
                return e
                    ? ("function" == typeof a && (a = a.call(i || {})),
                      r && r.wrapped && p(r, r.wrapped),
                      (o = t.isArray(a)
                          ? t.map(a, function (t) {
                                return t ? n(r, i, e, t) : null;
                            })
                          : [n(r, i, e, a)]),
                      u ? t(l(i, null, o)) : o)
                    : [];
            },
            tmplItem: function (e) {
                var n;
                for (e instanceof t && (e = e[0]); e && 1 === e.nodeType && !(n = t.data(e, "tmplItem")) && (e = e.parentNode); );
                return n || w;
            },
            template: function (e, n) {
                return n
                    ? ("string" == typeof n ? (n = r(n)) : n instanceof t && (n = n[0] || {}), n.nodeType && (n = t.data(n, "tmpl") || t.data(n, "tmpl", r(n.innerHTML))), "string" == typeof e ? (t.template[e] = n) : n)
                    : e
                    ? "string" != typeof e
                        ? t.template(null, e)
                        : t.template[e] || t.template(null, _.test(e) ? e : t(e))
                    : null;
            },
            encode: function (t) {
                return ("" + t).split("<").join("&lt;").split(">").join("&gt;").split('"').join("&#34;").split("'").join("&#39;");
            },
        }),
        t.extend(t.tmpl, {
            tag: {
                tmpl: { _default: { $2: "null" }, open: "if($notnull_1){_=_.concat($item.nest($1,$2));}" },
                wrap: { _default: { $2: "null" }, open: "$item.calls(_,$1,$2);_=[];", close: "call=$item.calls();_=call._.concat($item.wrap(call,_));" },
                each: { _default: { $2: "$index, $value" }, open: "if($notnull_1){$.each($1a,function($2){with(this){", close: "}});}" },
                if: { open: "if(($notnull_1) && $1a){", close: "}" },
                else: { _default: { $1: "true" }, open: "}else if(($notnull_1) && $1a){" },
                html: { open: "if($notnull_1){_.push($1a);}" },
                "=": { _default: { $1: "$data" }, open: "if($notnull_1){_.push($.encode($1a));}" },
                "!": { open: "" },
            },
            complete: function (t) {
                g = {};
            },
            afterManip: function (e, n, l) {
                var a = 11 === n.nodeType ? t.makeArray(n.childNodes) : 1 === n.nodeType ? [n] : [];
                l.call(e, n), u(a), k++;
            },
        });
})(jQuery);
Array.prototype.indexOf ||
    (Array.prototype.indexOf = function (a) {
        return $.inArray(a, this);
    }),
    ($.fn.tabs = function () {
        var a = this;
        this.each(function () {
            var b = $(this);
            $(b.attr("href")).hide(),
                $(b).click(function () {
                    return (
                        $(a).removeClass("selected"),
                        $(a).each(function (a, b) {
                            $($(b).attr("href")).hide();
                        }),
                        $(this).addClass("selected"),
                        $($(this).attr("href")).show(),
                        !1
                    );
                });
        }),
            $(this).show(),
            $(this).first().click();
    });
!(function (a) {
    (a.flexslider = function (b, c) {
        var d = a(b);
        d.vars = a.extend({}, a.flexslider.defaults, c);
        var j,
            e = d.vars.namespace,
            f = window.navigator && window.navigator.msPointerEnabled && window.MSGesture,
            g = ("ontouchstart" in window || f || (window.DocumentTouch && document instanceof DocumentTouch)) && d.vars.touch,
            h = "click touchend MSPointerUp",
            i = "",
            k = "vertical" === d.vars.direction,
            l = d.vars.reverse,
            m = d.vars.itemWidth > 0,
            n = "fade" === d.vars.animation,
            o = "" !== d.vars.asNavFor,
            p = {},
            q = !0;
        a.data(b, "flexslider", d),
            (p = {
                init: function () {
                    (d.animating = !1),
                        (d.currentSlide = parseInt(d.vars.startAt ? d.vars.startAt : 0, 10)),
                        isNaN(d.currentSlide) && (d.currentSlide = 0),
                        (d.animatingTo = d.currentSlide),
                        (d.atEnd = 0 === d.currentSlide || d.currentSlide === d.last),
                        (d.containerSelector = d.vars.selector.substr(0, d.vars.selector.search(" "))),
                        (d.slides = a(d.vars.selector, d)),
                        (d.container = a(d.containerSelector, d)),
                        (d.count = d.slides.length),
                        (d.syncExists = a(d.vars.sync).length > 0),
                        "slide" === d.vars.animation && (d.vars.animation = "swing"),
                        (d.prop = k ? "top" : "marginLeft"),
                        (d.args = {}),
                        (d.manualPause = !1),
                        (d.stopped = !1),
                        (d.started = !1),
                        (d.startTimeout = null),
                        (d.transitions =
                            !d.vars.video &&
                            !n &&
                            d.vars.useCSS &&
                            (function () {
                                var a = document.createElement("div"),
                                    b = ["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"];
                                for (var c in b) if (void 0 !== a.style[b[c]]) return (d.pfx = b[c].replace("Perspective", "").toLowerCase()), (d.prop = "-" + d.pfx + "-transform"), !0;
                                return !1;
                            })()),
                        (d.ensureAnimationEnd = ""),
                        "" !== d.vars.controlsContainer && (d.controlsContainer = a(d.vars.controlsContainer).length > 0 && a(d.vars.controlsContainer)),
                        "" !== d.vars.manualControls && (d.manualControls = a(d.vars.manualControls).length > 0 && a(d.vars.manualControls)),
                        d.vars.randomize &&
                            (d.slides.sort(function () {
                                return Math.round(Math.random()) - 0.5;
                            }),
                            d.container.empty().append(d.slides)),
                        d.doMath(),
                        d.setup("init"),
                        d.vars.controlNav && p.controlNav.setup(),
                        d.vars.directionNav && p.directionNav.setup(),
                        d.vars.keyboard &&
                            (1 === a(d.containerSelector).length || d.vars.multipleKeyboard) &&
                            a(document).bind("keyup", function (a) {
                                var b = a.keyCode;
                                if (!d.animating && (39 === b || 37 === b)) {
                                    var c = 39 === b ? d.getTarget("next") : 37 === b ? d.getTarget("prev") : !1;
                                    d.flexAnimate(c, d.vars.pauseOnAction);
                                }
                            }),
                        d.vars.mousewheel &&
                            d.bind("mousewheel", function (a, b) {
                                a.preventDefault();
                                var f = 0 > b ? d.getTarget("next") : d.getTarget("prev");
                                d.flexAnimate(f, d.vars.pauseOnAction);
                            }),
                        d.vars.pausePlay && p.pausePlay.setup(),
                        d.vars.slideshow && d.vars.pauseInvisible && p.pauseInvisible.init(),
                        d.vars.slideshow &&
                            (d.vars.pauseOnHover &&
                                d.hover(
                                    function () {
                                        d.manualPlay || d.manualPause || d.pause();
                                    },
                                    function () {
                                        d.manualPause || d.manualPlay || d.stopped || d.play();
                                    }
                                ),
                            (d.vars.pauseInvisible && p.pauseInvisible.isHidden()) || (d.vars.initDelay > 0 ? (d.startTimeout = setTimeout(d.play, d.vars.initDelay)) : d.play())),
                        o && p.asNav.setup(),
                        g && d.vars.touch && p.touch(),
                        (!n || (n && d.vars.smoothHeight)) && a(window).bind("resize orientationchange focus", p.resize),
                        d.find("img").attr("draggable", "false"),
                        setTimeout(function () {
                            d.vars.start(d);
                        }, 200);
                },
                asNav: {
                    setup: function () {
                        (d.asNav = !0),
                            (d.animatingTo = Math.floor(d.currentSlide / d.move)),
                            (d.currentItem = d.currentSlide),
                            d.slides
                                .removeClass(e + "active-slide")
                                .eq(d.currentItem)
                                .addClass(e + "active-slide"),
                            f
                                ? ((b._slider = d),
                                  d.slides.each(function () {
                                      var b = this;
                                      (b._gesture = new MSGesture()),
                                          (b._gesture.target = b),
                                          b.addEventListener(
                                              "MSPointerDown",
                                              function (a) {
                                                  a.preventDefault(), a.currentTarget._gesture && a.currentTarget._gesture.addPointer(a.pointerId);
                                              },
                                              !1
                                          ),
                                          b.addEventListener("MSGestureTap", function (b) {
                                              b.preventDefault();
                                              var c = a(this),
                                                  e = c.index();
                                              a(d.vars.asNavFor).data("flexslider").animating || c.hasClass("active") || ((d.direction = d.currentItem < e ? "next" : "prev"), d.flexAnimate(e, d.vars.pauseOnAction, !1, !0, !0));
                                          });
                                  }))
                                : d.slides.on(h, function (b) {
                                      b.preventDefault();
                                      var c = a(this),
                                          f = c.index(),
                                          g = c.offset().left - a(d).scrollLeft();
                                      0 >= g && c.hasClass(e + "active-slide")
                                          ? d.flexAnimate(d.getTarget("prev"), !0)
                                          : a(d.vars.asNavFor).data("flexslider").animating || c.hasClass(e + "active-slide") || ((d.direction = d.currentItem < f ? "next" : "prev"), d.flexAnimate(f, d.vars.pauseOnAction, !1, !0, !0));
                                  });
                    },
                },
                controlNav: {
                    setup: function () {
                        d.manualControls ? p.controlNav.setupManual() : p.controlNav.setupPaging();
                    },
                    setupPaging: function () {
                        var f,
                            g,
                            b = "thumbnails" === d.vars.controlNav ? "control-thumbs" : "control-paging",
                            c = 1;
                        if (((d.controlNavScaffold = a('<ol class="' + e + "control-nav " + e + b + '"></ol>')), d.pagingCount > 1))
                            for (var j = 0; j < d.pagingCount; j++) {
                                if (((g = d.slides.eq(j)), (f = "thumbnails" === d.vars.controlNav ? '<img src="' + g.attr("data-thumb") + '"/>' : "<a>" + c + "</a>"), "thumbnails" === d.vars.controlNav && !0 === d.vars.thumbCaptions)) {
                                    var k = g.attr("data-thumbcaption");
                                    "" != k && void 0 != k && (f += '<span class="' + e + 'caption">' + k + "</span>");
                                }
                                d.controlNavScaffold.append("<li>" + f + "</li>"), c++;
                            }
                        d.controlsContainer ? a(d.controlsContainer).append(d.controlNavScaffold) : d.append(d.controlNavScaffold),
                            p.controlNav.set(),
                            p.controlNav.active(),
                            d.controlNavScaffold.delegate("a, img", h, function (b) {
                                if ((b.preventDefault(), "" === i || i === b.type)) {
                                    var c = a(this),
                                        f = d.controlNav.index(c);
                                    c.hasClass(e + "active") || ((d.direction = f > d.currentSlide ? "next" : "prev"), d.flexAnimate(f, d.vars.pauseOnAction));
                                }
                                "" === i && (i = b.type), p.setToClearWatchedEvent();
                            });
                    },
                    setupManual: function () {
                        (d.controlNav = d.manualControls),
                            p.controlNav.active(),
                            d.controlNav.bind(h, function (b) {
                                if ((b.preventDefault(), "" === i || i === b.type)) {
                                    var c = a(this),
                                        f = d.controlNav.index(c);
                                    c.hasClass(e + "active") || ((d.direction = f > d.currentSlide ? "next" : "prev"), d.flexAnimate(f, d.vars.pauseOnAction));
                                }
                                "" === i && (i = b.type), p.setToClearWatchedEvent();
                            });
                    },
                    set: function () {
                        var b = "thumbnails" === d.vars.controlNav ? "img" : "a";
                        d.controlNav = a("." + e + "control-nav li " + b, d.controlsContainer ? d.controlsContainer : d);
                    },
                    active: function () {
                        d.controlNav
                            .removeClass(e + "active")
                            .eq(d.animatingTo)
                            .addClass(e + "active");
                    },
                    update: function (b, c) {
                        d.pagingCount > 1 && "add" === b ? d.controlNavScaffold.append(a("<li><a>" + d.count + "</a></li>")) : 1 === d.pagingCount ? d.controlNavScaffold.find("li").remove() : d.controlNav.eq(c).closest("li").remove(),
                            p.controlNav.set(),
                            d.pagingCount > 1 && d.pagingCount !== d.controlNav.length ? d.update(c, b) : p.controlNav.active();
                    },
                },
                directionNav: {
                    setup: function () {
                        var b = a('<ul class="' + e + 'direction-nav"><li><a class="' + e + 'prev" href="#">' + d.vars.prevText + '</a></li><li><a class="' + e + 'next" href="#">' + d.vars.nextText + "</a></li></ul>");
                        d.controlsContainer ? (a(d.controlsContainer).append(b), (d.directionNav = a("." + e + "direction-nav li a", d.controlsContainer))) : (d.append(b), (d.directionNav = a("." + e + "direction-nav li a", d))),
                            p.directionNav.update(),
                            d.directionNav.bind(h, function (b) {
                                b.preventDefault();
                                var c;
                                ("" === i || i === b.type) && ((c = a(this).hasClass(e + "next") ? d.getTarget("next") : d.getTarget("prev")), d.flexAnimate(c, d.vars.pauseOnAction)), "" === i && (i = b.type), p.setToClearWatchedEvent();
                            });
                    },
                    update: function () {
                        var a = e + "disabled";
                        1 === d.pagingCount
                            ? d.directionNav.addClass(a).attr("tabindex", "-1")
                            : d.vars.animationLoop
                            ? d.directionNav.removeClass(a).removeAttr("tabindex")
                            : 0 === d.animatingTo
                            ? d.directionNav
                                  .removeClass(a)
                                  .filter("." + e + "prev")
                                  .addClass(a)
                                  .attr("tabindex", "-1")
                            : d.animatingTo === d.last
                            ? d.directionNav
                                  .removeClass(a)
                                  .filter("." + e + "next")
                                  .addClass(a)
                                  .attr("tabindex", "-1")
                            : d.directionNav.removeClass(a).removeAttr("tabindex");
                    },
                },
                pausePlay: {
                    setup: function () {
                        var b = a('<div class="' + e + 'pauseplay"><a></a></div>');
                        d.controlsContainer ? (d.controlsContainer.append(b), (d.pausePlay = a("." + e + "pauseplay a", d.controlsContainer))) : (d.append(b), (d.pausePlay = a("." + e + "pauseplay a", d))),
                            p.pausePlay.update(d.vars.slideshow ? e + "pause" : e + "play"),
                            d.pausePlay.bind(h, function (b) {
                                b.preventDefault(),
                                    ("" === i || i === b.type) && (a(this).hasClass(e + "pause") ? ((d.manualPause = !0), (d.manualPlay = !1), d.pause()) : ((d.manualPause = !1), (d.manualPlay = !0), d.play())),
                                    "" === i && (i = b.type),
                                    p.setToClearWatchedEvent();
                            });
                    },
                    update: function (a) {
                        "play" === a
                            ? d.pausePlay
                                  .removeClass(e + "pause")
                                  .addClass(e + "play")
                                  .html(d.vars.playText)
                            : d.pausePlay
                                  .removeClass(e + "play")
                                  .addClass(e + "pause")
                                  .html(d.vars.pauseText);
                    },
                },
                touch: function () {
                    function r(f) {
                        d.animating
                            ? f.preventDefault()
                            : (window.navigator.msPointerEnabled || 1 === f.touches.length) &&
                              (d.pause(),
                              (g = k ? d.h : d.w),
                              (i = Number(new Date())),
                              (o = f.touches[0].pageX),
                              (p = f.touches[0].pageY),
                              (e =
                                  m && l && d.animatingTo === d.last
                                      ? 0
                                      : m && l
                                      ? d.limit - (d.itemW + d.vars.itemMargin) * d.move * d.animatingTo
                                      : m && d.currentSlide === d.last
                                      ? d.limit
                                      : m
                                      ? (d.itemW + d.vars.itemMargin) * d.move * d.currentSlide
                                      : l
                                      ? (d.last - d.currentSlide + d.cloneOffset) * g
                                      : (d.currentSlide + d.cloneOffset) * g),
                              (a = k ? p : o),
                              (c = k ? o : p),
                              b.addEventListener("touchmove", s, !1),
                              b.addEventListener("touchend", t, !1));
                    }
                    function s(b) {
                        (o = b.touches[0].pageX), (p = b.touches[0].pageY), (h = k ? a - p : a - o), (j = k ? Math.abs(h) < Math.abs(o - c) : Math.abs(h) < Math.abs(p - c));
                        var f = 500;
                        (!j || Number(new Date()) - i > f) &&
                            (b.preventDefault(), !n && d.transitions && (d.vars.animationLoop || (h /= (0 === d.currentSlide && 0 > h) || (d.currentSlide === d.last && h > 0) ? Math.abs(h) / g + 2 : 1), d.setProps(e + h, "setTouch")));
                    }
                    function t() {
                        if ((b.removeEventListener("touchmove", s, !1), d.animatingTo === d.currentSlide && !j && null !== h)) {
                            var k = l ? -h : h,
                                m = k > 0 ? d.getTarget("next") : d.getTarget("prev");
                            d.canAdvance(m) && ((Number(new Date()) - i < 550 && Math.abs(k) > 50) || Math.abs(k) > g / 2) ? d.flexAnimate(m, d.vars.pauseOnAction) : n || d.flexAnimate(d.currentSlide, d.vars.pauseOnAction, !0);
                        }
                        b.removeEventListener("touchend", t, !1), (a = null), (c = null), (h = null), (e = null);
                    }
                    function u(a) {
                        a.stopPropagation(),
                            d.animating
                                ? a.preventDefault()
                                : (d.pause(),
                                  b._gesture.addPointer(a.pointerId),
                                  (q = 0),
                                  (g = k ? d.h : d.w),
                                  (i = Number(new Date())),
                                  (e =
                                      m && l && d.animatingTo === d.last
                                          ? 0
                                          : m && l
                                          ? d.limit - (d.itemW + d.vars.itemMargin) * d.move * d.animatingTo
                                          : m && d.currentSlide === d.last
                                          ? d.limit
                                          : m
                                          ? (d.itemW + d.vars.itemMargin) * d.move * d.currentSlide
                                          : l
                                          ? (d.last - d.currentSlide + d.cloneOffset) * g
                                          : (d.currentSlide + d.cloneOffset) * g));
                    }
                    function v(a) {
                        a.stopPropagation();
                        var c = a.target._slider;
                        if (c) {
                            var d = -a.translationX,
                                f = -a.translationY;
                            return (
                                (q += k ? f : d),
                                (h = q),
                                (j = k ? Math.abs(q) < Math.abs(-d) : Math.abs(q) < Math.abs(-f)),
                                a.detail === a.MSGESTURE_FLAG_INERTIA
                                    ? (setImmediate(function () {
                                          b._gesture.stop();
                                      }),
                                      void 0)
                                    : ((!j || Number(new Date()) - i > 500) &&
                                          (a.preventDefault(),
                                          !n && c.transitions && (c.vars.animationLoop || (h = q / ((0 === c.currentSlide && 0 > q) || (c.currentSlide === c.last && q > 0) ? Math.abs(q) / g + 2 : 1)), c.setProps(e + h, "setTouch"))),
                                      void 0)
                            );
                        }
                    }
                    function w(b) {
                        b.stopPropagation();
                        var d = b.target._slider;
                        if (d) {
                            if (d.animatingTo === d.currentSlide && !j && null !== h) {
                                var f = l ? -h : h,
                                    k = f > 0 ? d.getTarget("next") : d.getTarget("prev");
                                d.canAdvance(k) && ((Number(new Date()) - i < 550 && Math.abs(f) > 50) || Math.abs(f) > g / 2) ? d.flexAnimate(k, d.vars.pauseOnAction) : n || d.flexAnimate(d.currentSlide, d.vars.pauseOnAction, !0);
                            }
                            (a = null), (c = null), (h = null), (e = null), (q = 0);
                        }
                    }
                    var a,
                        c,
                        e,
                        g,
                        h,
                        i,
                        j = !1,
                        o = 0,
                        p = 0,
                        q = 0;
                    f
                        ? ((b.style.msTouchAction = "none"),
                          (b._gesture = new MSGesture()),
                          (b._gesture.target = b),
                          b.addEventListener("MSPointerDown", u, !1),
                          (b._slider = d),
                          b.addEventListener("MSGestureChange", v, !1),
                          b.addEventListener("MSGestureEnd", w, !1))
                        : b.addEventListener("touchstart", r, !1);
                },
                resize: function () {
                    !d.animating &&
                        d.is(":visible") &&
                        (m || d.doMath(),
                        n
                            ? p.smoothHeight()
                            : m
                            ? (d.slides.width(d.computedW), d.update(d.pagingCount), d.setProps())
                            : k
                            ? (d.viewport.height(d.h), d.setProps(d.h, "setTotal"))
                            : (d.vars.smoothHeight && p.smoothHeight(), d.newSlides.width(d.computedW), d.setProps(d.computedW, "setTotal")));
                },
                smoothHeight: function (a) {
                    if (!k || n) {
                        var b = n ? d : d.viewport;
                        a ? b.animate({ height: d.slides.eq(d.animatingTo).height() }, a) : b.height(d.slides.eq(d.animatingTo).height());
                    }
                },
                sync: function (b) {
                    var c = a(d.vars.sync).data("flexslider"),
                        e = d.animatingTo;
                    switch (b) {
                        case "animate":
                            c.flexAnimate(e, d.vars.pauseOnAction, !1, !0);
                            break;
                        case "play":
                            c.playing || c.asNav || c.play();
                            break;
                        case "pause":
                            c.pause();
                    }
                },
                uniqueID: function (b) {
                    return (
                        b.find("[id]").each(function () {
                            var b = a(this);
                            b.attr("id", b.attr("id") + "_clone");
                        }),
                        b
                    );
                },
                pauseInvisible: {
                    visProp: null,
                    init: function () {
                        var a = ["webkit", "moz", "ms", "o"];
                        if ("hidden" in document) return "hidden";
                        for (var b = 0; b < a.length; b++) a[b] + "Hidden" in document && (p.pauseInvisible.visProp = a[b] + "Hidden");
                        if (p.pauseInvisible.visProp) {
                            var c = p.pauseInvisible.visProp.replace(/[H|h]idden/, "") + "visibilitychange";
                            document.addEventListener(c, function () {
                                p.pauseInvisible.isHidden() ? (d.startTimeout ? clearTimeout(d.startTimeout) : d.pause()) : d.started ? d.play() : d.vars.initDelay > 0 ? setTimeout(d.play, d.vars.initDelay) : d.play();
                            });
                        }
                    },
                    isHidden: function () {
                        return document[p.pauseInvisible.visProp] || !1;
                    },
                },
                setToClearWatchedEvent: function () {
                    clearTimeout(j),
                        (j = setTimeout(function () {
                            i = "";
                        }, 3e3));
                },
            }),
            (d.flexAnimate = function (b, c, f, h, i) {
                if (
                    (d.vars.animationLoop || b === d.currentSlide || (d.direction = b > d.currentSlide ? "next" : "prev"),
                    o && 1 === d.pagingCount && (d.direction = d.currentItem < b ? "next" : "prev"),
                    !d.animating && (d.canAdvance(b, i) || f) && d.is(":visible"))
                ) {
                    if (o && h) {
                        var j = a(d.vars.asNavFor).data("flexslider");
                        if (
                            ((d.atEnd = 0 === b || b === d.count - 1),
                            j.flexAnimate(b, !0, !1, !0, i),
                            (d.direction = d.currentItem < b ? "next" : "prev"),
                            (j.direction = d.direction),
                            Math.ceil((b + 1) / d.visible) - 1 === d.currentSlide || 0 === b)
                        )
                            return (
                                (d.currentItem = b),
                                d.slides
                                    .removeClass(e + "active-slide")
                                    .eq(b)
                                    .addClass(e + "active-slide"),
                                !1
                            );
                        (d.currentItem = b),
                            d.slides
                                .removeClass(e + "active-slide")
                                .eq(b)
                                .addClass(e + "active-slide"),
                            (b = Math.floor(b / d.visible));
                    }
                    if (
                        ((d.animating = !0),
                        (d.animatingTo = b),
                        c && d.pause(),
                        d.vars.before(d),
                        d.syncExists && !i && p.sync("animate"),
                        d.vars.controlNav && p.controlNav.active(),
                        m ||
                            d.slides
                                .removeClass(e + "active-slide")
                                .eq(b)
                                .addClass(e + "active-slide"),
                        (d.atEnd = 0 === b || b === d.last),
                        d.vars.directionNav && p.directionNav.update(),
                        b === d.last && (d.vars.end(d), d.vars.animationLoop || d.pause()),
                        n)
                    )
                        g
                            ? (d.slides.eq(d.currentSlide).css({ opacity: 0, zIndex: 1 }), d.slides.eq(b).css({ opacity: 1, zIndex: 2 }), d.wrapup(q))
                            : (d.slides.eq(d.currentSlide).css({ zIndex: 1 }).animate({ opacity: 0 }, d.vars.animationSpeed, d.vars.easing),
                              d.slides.eq(b).css({ zIndex: 2 }).animate({ opacity: 1 }, d.vars.animationSpeed, d.vars.easing, d.wrapup));
                    else {
                        var r,
                            s,
                            t,
                            q = k ? d.slides.filter(":first").height() : d.computedW;
                        m
                            ? ((r = d.vars.itemMargin), (t = (d.itemW + r) * d.move * d.animatingTo), (s = t > d.limit && 1 !== d.visible ? d.limit : t))
                            : (s =
                                  0 === d.currentSlide && b === d.count - 1 && d.vars.animationLoop && "next" !== d.direction
                                      ? l
                                          ? (d.count + d.cloneOffset) * q
                                          : 0
                                      : d.currentSlide === d.last && 0 === b && d.vars.animationLoop && "prev" !== d.direction
                                      ? l
                                          ? 0
                                          : (d.count + 1) * q
                                      : l
                                      ? (d.count - 1 - b + d.cloneOffset) * q
                                      : (b + d.cloneOffset) * q),
                            d.setProps(s, "", d.vars.animationSpeed),
                            d.transitions
                                ? ((d.vars.animationLoop && d.atEnd) || ((d.animating = !1), (d.currentSlide = d.animatingTo)),
                                  d.container.unbind("webkitTransitionEnd transitionend"),
                                  d.container.bind("webkitTransitionEnd transitionend", function () {
                                      clearTimeout(d.ensureAnimationEnd), d.wrapup(q);
                                  }),
                                  clearTimeout(d.ensureAnimationEnd),
                                  (d.ensureAnimationEnd = setTimeout(function () {
                                      d.wrapup(q);
                                  }, d.vars.animationSpeed + 100)))
                                : d.container.animate(d.args, d.vars.animationSpeed, d.vars.easing, function () {
                                      d.wrapup(q);
                                  });
                    }
                    d.vars.smoothHeight && p.smoothHeight(d.vars.animationSpeed);
                }
            }),
            (d.wrapup = function (a) {
                n || m || (0 === d.currentSlide && d.animatingTo === d.last && d.vars.animationLoop ? d.setProps(a, "jumpEnd") : d.currentSlide === d.last && 0 === d.animatingTo && d.vars.animationLoop && d.setProps(a, "jumpStart")),
                    (d.animating = !1),
                    (d.currentSlide = d.animatingTo),
                    d.vars.after(d);
            }),
            (d.animateSlides = function () {
                !d.animating && q && d.flexAnimate(d.getTarget("next"));
            }),
            (d.pause = function () {
                clearInterval(d.animatedSlides), (d.animatedSlides = null), (d.playing = !1), d.vars.pausePlay && p.pausePlay.update("play"), d.syncExists && p.sync("pause");
            }),
            (d.play = function () {
                d.playing && clearInterval(d.animatedSlides),
                    (d.animatedSlides = d.animatedSlides || setInterval(d.animateSlides, d.vars.slideshowSpeed)),
                    (d.started = d.playing = !0),
                    d.vars.pausePlay && p.pausePlay.update("pause"),
                    d.syncExists && p.sync("play");
            }),
            (d.stop = function () {
                d.pause(), (d.stopped = !0);
            }),
            (d.canAdvance = function (a, b) {
                var c = o ? d.pagingCount - 1 : d.last;
                return b
                    ? !0
                    : o && d.currentItem === d.count - 1 && 0 === a && "prev" === d.direction
                    ? !0
                    : o && 0 === d.currentItem && a === d.pagingCount - 1 && "next" !== d.direction
                    ? !1
                    : a !== d.currentSlide || o
                    ? d.vars.animationLoop
                        ? !0
                        : d.atEnd && 0 === d.currentSlide && a === c && "next" !== d.direction
                        ? !1
                        : d.atEnd && d.currentSlide === c && 0 === a && "next" === d.direction
                        ? !1
                        : !0
                    : !1;
            }),
            (d.getTarget = function (a) {
                return (d.direction = a), "next" === a ? (d.currentSlide === d.last ? 0 : d.currentSlide + 1) : 0 === d.currentSlide ? d.last : d.currentSlide - 1;
            }),
            (d.setProps = function (a, b, c) {
                var e = (function () {
                    var c = a ? a : (d.itemW + d.vars.itemMargin) * d.move * d.animatingTo,
                        e = (function () {
                            if (m) return "setTouch" === b ? a : l && d.animatingTo === d.last ? 0 : l ? d.limit - (d.itemW + d.vars.itemMargin) * d.move * d.animatingTo : d.animatingTo === d.last ? d.limit : c;
                            switch (b) {
                                case "setTotal":
                                    return l ? (d.count - 1 - d.currentSlide + d.cloneOffset) * a : (d.currentSlide + d.cloneOffset) * a;
                                case "setTouch":
                                    return l ? a : a;
                                case "jumpEnd":
                                    return l ? a : d.count * a;
                                case "jumpStart":
                                    return l ? d.count * a : a;
                                default:
                                    return a;
                            }
                        })();
                    return -1 * e + "px";
                })();
                d.transitions &&
                    ((e = k ? "translate3d(0," + e + ",0)" : "translate3d(" + e + ",0,0)"), (c = void 0 !== c ? c / 1e3 + "s" : "0s"), d.container.css("-" + d.pfx + "-transition-duration", c), d.container.css("transition-duration", c)),
                    (d.args[d.prop] = e),
                    (d.transitions || void 0 === c) && d.container.css(d.args),
                    d.container.css("transform", e);
            }),
            (d.setup = function (b) {
                if (n)
                    d.slides.css({ width: "100%", float: "left", marginRight: "-100%", position: "relative" }),
                        "init" === b &&
                            (g
                                ? d.slides
                                      .css({ opacity: 0, display: "block", webkitTransition: "opacity " + d.vars.animationSpeed / 1e3 + "s ease", zIndex: 1 })
                                      .eq(d.currentSlide)
                                      .css({ opacity: 1, zIndex: 2 })
                                : d.slides.css({ opacity: 0, display: "block", zIndex: 1 }).eq(d.currentSlide).css({ zIndex: 2 }).animate({ opacity: 1 }, d.vars.animationSpeed, d.vars.easing)),
                        d.vars.smoothHeight && p.smoothHeight();
                else {
                    var c, f;
                    "init" === b &&
                        ((d.viewport = a('<div class="' + e + 'viewport"></div>')
                            .css({ overflow: "hidden", position: "relative" })
                            .appendTo(d)
                            .append(d.container)),
                        (d.cloneCount = 0),
                        (d.cloneOffset = 0),
                        l && ((f = a.makeArray(d.slides).reverse()), (d.slides = a(f)), d.container.empty().append(d.slides))),
                        d.vars.animationLoop &&
                            !m &&
                            ((d.cloneCount = 2),
                            (d.cloneOffset = 1),
                            "init" !== b && d.container.find(".clone").remove(),
                            p.uniqueID(d.slides.first().clone().addClass("clone").attr("aria-hidden", "true")).appendTo(d.container),
                            p.uniqueID(d.slides.last().clone().addClass("clone").attr("aria-hidden", "true")).prependTo(d.container)),
                        (d.newSlides = a(d.vars.selector, d)),
                        (c = l ? d.count - 1 - d.currentSlide + d.cloneOffset : d.currentSlide + d.cloneOffset),
                        k && !m
                            ? (d.container
                                  .height(200 * (d.count + d.cloneCount) + "%")
                                  .css("position", "absolute")
                                  .width("100%"),
                              setTimeout(
                                  function () {
                                      d.newSlides.css({ display: "block" }), d.doMath(), d.viewport.height(d.h), d.setProps(c * d.h, "init");
                                  },
                                  "init" === b ? 100 : 0
                              ))
                            : (d.container.width(200 * (d.count + d.cloneCount) + "%"),
                              d.setProps(c * d.computedW, "init"),
                              setTimeout(
                                  function () {
                                      d.doMath(), d.newSlides.css({ width: d.computedW, float: "left", display: "block" }), d.vars.smoothHeight && p.smoothHeight();
                                  },
                                  "init" === b ? 100 : 0
                              ));
                }
                m ||
                    d.slides
                        .removeClass(e + "active-slide")
                        .eq(d.currentSlide)
                        .addClass(e + "active-slide"),
                    d.vars.init(d);
            }),
            (d.doMath = function () {
                var a = d.slides.first(),
                    b = d.vars.itemMargin,
                    c = d.vars.minItems,
                    e = d.vars.maxItems;
                (d.w = void 0 === d.viewport ? d.width() : d.viewport.width()),
                    (d.h = a.height()),
                    (d.boxPadding = a.outerWidth() - a.width()),
                    m
                        ? ((d.itemT = d.vars.itemWidth + b),
                          (d.minW = c ? c * d.itemT : d.w),
                          (d.maxW = e ? e * d.itemT - b : d.w),
                          (d.itemW = d.minW > d.w ? (d.w - b * (c - 1)) / c : d.maxW < d.w ? (d.w - b * (e - 1)) / e : d.vars.itemWidth > d.w ? d.w : d.vars.itemWidth),
                          (d.visible = Math.floor(d.w / d.itemW)),
                          (d.move = d.vars.move > 0 && d.vars.move < d.visible ? d.vars.move : d.visible),
                          (d.pagingCount = Math.ceil((d.count - d.visible) / d.move + 1)),
                          (d.last = d.pagingCount - 1),
                          (d.limit = 1 === d.pagingCount ? 0 : d.vars.itemWidth > d.w ? d.itemW * (d.count - 1) + b * (d.count - 1) : (d.itemW + b) * d.count - d.w - b))
                        : ((d.itemW = d.w), (d.pagingCount = d.count), (d.last = d.count - 1)),
                    (d.computedW = d.itemW - d.boxPadding);
            }),
            (d.update = function (a, b) {
                d.doMath(),
                    m || (a < d.currentSlide ? (d.currentSlide += 1) : a <= d.currentSlide && 0 !== a && (d.currentSlide -= 1), (d.animatingTo = d.currentSlide)),
                    d.vars.controlNav &&
                        !d.manualControls &&
                        (("add" === b && !m) || d.pagingCount > d.controlNav.length
                            ? p.controlNav.update("add")
                            : (("remove" === b && !m) || d.pagingCount < d.controlNav.length) && (m && d.currentSlide > d.last && ((d.currentSlide -= 1), (d.animatingTo -= 1)), p.controlNav.update("remove", d.last))),
                    d.vars.directionNav && p.directionNav.update();
            }),
            (d.addSlide = function (b, c) {
                var e = a(b);
                (d.count += 1),
                    (d.last = d.count - 1),
                    k && l ? (void 0 !== c ? d.slides.eq(d.count - c).after(e) : d.container.prepend(e)) : void 0 !== c ? d.slides.eq(c).before(e) : d.container.append(e),
                    d.update(c, "add"),
                    (d.slides = a(d.vars.selector + ":not(.clone)", d)),
                    d.setup(),
                    d.vars.added(d);
            }),
            (d.removeSlide = function (b) {
                var c = isNaN(b) ? d.slides.index(a(b)) : b;
                (d.count -= 1),
                    (d.last = d.count - 1),
                    isNaN(b) ? a(b, d.slides).remove() : k && l ? d.slides.eq(d.last).remove() : d.slides.eq(b).remove(),
                    d.doMath(),
                    d.update(c, "remove"),
                    (d.slides = a(d.vars.selector + ":not(.clone)", d)),
                    d.setup(),
                    d.vars.removed(d);
            }),
            p.init();
    }),
        a(window)
            .blur(function () {
                focused = !1;
            })
            .focus(function () {
                focused = !0;
            }),
        (a.flexslider.defaults = {
            namespace: "flex-",
            selector: ".slides > li",
            animation: "fade",
            easing: "swing",
            direction: "horizontal",
            reverse: !1,
            animationLoop: !0,
            smoothHeight: !1,
            startAt: 0,
            slideshow: !0,
            slideshowSpeed: 7e3,
            animationSpeed: 600,
            initDelay: 0,
            randomize: !1,
            thumbCaptions: !1,
            pauseOnAction: !0,
            pauseOnHover: !1,
            pauseInvisible: !0,
            useCSS: !0,
            touch: !0,
            video: !1,
            controlNav: !0,
            directionNav: !0,
            prevText: "Previous",
            nextText: "Next",
            keyboard: !0,
            multipleKeyboard: !1,
            mousewheel: !1,
            pausePlay: !1,
            pauseText: "Pause",
            playText: "Play",
            controlsContainer: "",
            manualControls: "",
            sync: "",
            asNavFor: "",
            itemWidth: 0,
            itemMargin: 0,
            minItems: 1,
            maxItems: 0,
            move: 0,
            allowOneSlide: !0,
            start: function () {},
            before: function () {},
            after: function () {},
            end: function () {},
            added: function () {},
            removed: function () {},
            init: function () {},
        }),
        (a.fn.flexslider = function (b) {
            if ((void 0 === b && (b = {}), "object" == typeof b))
                return this.each(function () {
                    var c = a(this),
                        d = b.selector ? b.selector : ".slides > li",
                        e = c.find(d);
                    (1 === e.length && b.allowOneSlide === !0) || 0 === e.length ? (e.fadeIn(400), b.start && b.start(c)) : void 0 === c.data("flexslider") && new a.flexslider(this, b);
                });
            var c = a(this).data("flexslider");
            switch (b) {
                case "play":
                    c.play();
                    break;
                case "pause":
                    c.pause();
                    break;
                case "stop":
                    c.stop();
                    break;
                case "next":
                    c.flexAnimate(c.getTarget("next"), !0);
                    break;
                case "prev":
                case "previous":
                    c.flexAnimate(c.getTarget("prev"), !0);
                    break;
                default:
                    "number" == typeof b && c.flexAnimate(b, !0);
            }
        });
})(jQuery);
!(function () {
    var a = !1;
    (window.JQClass = function () {}),
        (JQClass.classes = {}),
        (JQClass.extend = function b(c) {
            function g() {
                !a && this._init && this._init.apply(this, arguments);
            }
            var d = this.prototype;
            a = !0;
            var e = new this();
            a = !1;
            for (var f in c)
                e[f] =
                    "function" == typeof c[f] && "function" == typeof d[f]
                        ? (function (a, b) {
                              return function () {
                                  var c = this._super;
                                  this._super = function (b) {
                                      return d[a].apply(this, b || []);
                                  };
                                  var e = b.apply(this, arguments);
                                  return (this._super = c), e;
                              };
                          })(f, c[f])
                        : c[f];
            return (g.prototype = e), (g.prototype.constructor = g), (g.extend = b), g;
        });
})(),
    (function ($) {
        function camelCase(a) {
            return a.replace(/-([a-z])/g, function (a, b) {
                return b.toUpperCase();
            });
        }
        (JQClass.classes.JQPlugin = JQClass.extend({
            name: "plugin",
            defaultOptions: {},
            regionalOptions: {},
            _getters: [],
            _getMarker: function () {
                return "is-" + this.name;
            },
            _init: function () {
                $.extend(this.defaultOptions, (this.regionalOptions && this.regionalOptions[""]) || {});
                var a = camelCase(this.name);
                ($[a] = this),
                    ($.fn[a] = function (b) {
                        var c = Array.prototype.slice.call(arguments, 1);
                        return $[a]._isNotChained(b, c)
                            ? $[a][b].apply($[a], [this[0]].concat(c))
                            : this.each(function () {
                                  if ("string" == typeof b) {
                                      if ("_" === b[0] || !$[a][b]) throw "Unknown method: " + b;
                                      $[a][b].apply($[a], [this].concat(c));
                                  } else $[a]._attach(this, b);
                              });
                    });
            },
            setDefaults: function (a) {
                $.extend(this.defaultOptions, a || {});
            },
            _isNotChained: function (a, b) {
                return ("option" === a && (0 === b.length || (1 === b.length && "string" == typeof b[0]))) || $.inArray(a, this._getters) > -1;
            },
            _attach: function (a, b) {
                if (((a = $(a)), !a.hasClass(this._getMarker()))) {
                    a.addClass(this._getMarker()), (b = $.extend({}, this.defaultOptions, this._getMetadata(a), b || {}));
                    var c = $.extend({ name: this.name, elem: a, options: b }, this._instSettings(a, b));
                    a.data(this.name, c), this._postAttach(a, c), this.option(a, b);
                }
            },
            _instSettings: function (a, b) {
                return {};
            },
            _postAttach: function (a, b) {},
            _getMetadata: function (d) {
                try {
                    var f = d.data(this.name.toLowerCase()) || "";
                    (f = f.replace(/'/g, '"')),
                        (f = f.replace(/([a-zA-Z0-9]+):/g, function (a, b, c) {
                            var d = f.substring(0, c).match(/"/g);
                            return d && d.length % 2 !== 0 ? b + ":" : '"' + b + '":';
                        })),
                        (f = $.parseJSON("{" + f + "}"));
                    for (var g in f) {
                        var h = f[g];
                        "string" == typeof h && h.match(/^new Date\((.*)\)$/) && (f[g] = eval(h));
                    }
                    return f;
                } catch (a) {
                    return {};
                }
            },
            _getInst: function (a) {
                return $(a).data(this.name) || {};
            },
            option: function (a, b, c) {
                a = $(a);
                var d = a.data(this.name);
                if (!b || ("string" == typeof b && null == c)) {
                    var e = (d || {}).options;
                    return e && b ? e[b] : e;
                }
                if (a.hasClass(this._getMarker())) {
                    var e = b || {};
                    "string" == typeof b && ((e = {}), (e[b] = c)), this._optionsChanged(a, d, e), $.extend(d.options, e);
                }
            },
            _optionsChanged: function (a, b, c) {},
            destroy: function (a) {
                (a = $(a)), a.hasClass(this._getMarker()) && (this._preDestroy(a, this._getInst(a)), a.removeData(this.name).removeClass(this._getMarker()));
            },
            _preDestroy: function (a, b) {},
        })),
            ($.JQPlugin = {
                createPlugin: function (a, b) {
                    "object" == typeof a && ((b = a), (a = "JQPlugin")), (a = camelCase(a));
                    var c = camelCase(b.name);
                    (JQClass.classes[c] = JQClass.classes[a].extend(b)), new JQClass.classes[c]();
                },
            });
    })(jQuery);
!(function (a) {
    var b = "countdown",
        c = 0,
        d = 1,
        e = 2,
        f = 3,
        g = 4,
        h = 5,
        i = 6;
    a.JQPlugin.createPlugin({
        name: b,
        defaultOptions: {
            until: null,
            since: null,
            timezone: null,
            serverSync: null,
            format: "dHMS",
            layout: "",
            compact: !1,
            padZeroes: !1,
            significant: 0,
            description: "",
            expiryUrl: "",
            expiryText: "",
            alwaysExpire: !1,
            onExpiry: null,
            onTick: null,
            tickInterval: 1,
        },
        regionalOptions: {
            "": {
                labels: ["Years", "Months", "Weeks", "Days", "Hours", "Min", "Sec"],
                labels1: ["Year", "Month", "Week", "Day", "Hour", "Min", "Sec"],
                compactLabels: ["y", "m", "w", "d"],
                whichLabels: null,
                digits: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
                timeSeparator: ":",
                isRTL: !1,
            },
        },
        _getters: ["getTimes"],
        _rtlClass: b + "-rtl",
        _sectionClass: b + "-section",
        _amountClass: b + "-amount",
        _periodClass: b + "-period",
        _rowClass: b + "-row",
        _holdingClass: b + "-holding",
        _showClass: b + "-show",
        _descrClass: b + "-descr",
        _timerElems: [],
        _init: function () {
            function e(a) {
                var h = a < 1e12 ? (d ? performance.now() + performance.timing.navigationStart : c()) : a || c();
                h - g >= 1e3 && (b._updateElems(), (g = h)), f(e);
            }
            var b = this;
            this._super(), (this._serverSyncs = []);
            var c =
                    "function" == typeof Date.now
                        ? Date.now
                        : function () {
                              return new Date().getTime();
                          },
                d = window.performance && "function" == typeof window.performance.now,
                f = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || null,
                g = 0;
            !f || a.noRequestAnimationFrame
                ? ((a.noRequestAnimationFrame = null),
                  setInterval(function () {
                      b._updateElems();
                  }, 980))
                : ((g = window.animationStartTime || window.webkitAnimationStartTime || window.mozAnimationStartTime || window.oAnimationStartTime || window.msAnimationStartTime || c()), f(e));
        },
        UTCDate: function (a, b, c, d, e, f, g, h) {
            "object" == typeof b && b.constructor == Date && ((h = b.getMilliseconds()), (g = b.getSeconds()), (f = b.getMinutes()), (e = b.getHours()), (d = b.getDate()), (c = b.getMonth()), (b = b.getFullYear()));
            var i = new Date();
            return (
                i.setUTCFullYear(b), i.setUTCDate(1), i.setUTCMonth(c || 0), i.setUTCDate(d || 1), i.setUTCHours(e || 0), i.setUTCMinutes((f || 0) - (Math.abs(a) < 30 ? 60 * a : a)), i.setUTCSeconds(g || 0), i.setUTCMilliseconds(h || 0), i
            );
        },
        periodsToSeconds: function (a) {
            return 31557600 * a[0] + 2629800 * a[1] + 604800 * a[2] + 86400 * a[3] + 3600 * a[4] + 60 * a[5] + a[6];
        },
        resync: function () {
            var b = this;
            a("." + this._getMarker()).each(function () {
                var c = a.data(this, b.name);
                if (c.options.serverSync) {
                    for (var d = null, e = 0; e < b._serverSyncs.length; e++)
                        if (b._serverSyncs[e][0] == c.options.serverSync) {
                            d = b._serverSyncs[e];
                            break;
                        }
                    if (null == d[2]) {
                        var f = a.isFunction(c.options.serverSync) ? c.options.serverSync.apply(this, []) : null;
                        d[2] = (f ? new Date().getTime() - f.getTime() : 0) - d[1];
                    }
                    c._since && c._since.setMilliseconds(c._since.getMilliseconds() + d[2]), c._until.setMilliseconds(c._until.getMilliseconds() + d[2]);
                }
            });
            for (var c = 0; c < b._serverSyncs.length; c++) null != b._serverSyncs[c][2] && ((b._serverSyncs[c][1] += b._serverSyncs[c][2]), delete b._serverSyncs[c][2]);
        },
        _instSettings: function (a, b) {
            return { _periods: [0, 0, 0, 0, 0, 0, 0] };
        },
        _addElem: function (a) {
            this._hasElem(a) || this._timerElems.push(a);
        },
        _hasElem: function (b) {
            return a.inArray(b, this._timerElems) > -1;
        },
        _removeElem: function (b) {
            this._timerElems = a.map(this._timerElems, function (a) {
                return a == b ? null : a;
            });
        },
        _updateElems: function () {
            for (var a = this._timerElems.length - 1; a >= 0; a--) this._updateCountdown(this._timerElems[a]);
        },
        _optionsChanged: function (b, c, d) {
            d.layout && (d.layout = d.layout.replace(/&lt;/g, "<").replace(/&gt;/g, ">")), this._resetExtraLabels(c.options, d);
            var e = c.options.timezone != d.timezone;
            a.extend(c.options, d), this._adjustSettings(b, c, null != d.until || null != d.since || e);
            var f = new Date();
            ((c._since && c._since < f) || (c._until && c._until > f)) && this._addElem(b[0]), this._updateCountdown(b, c);
        },
        _updateCountdown: function (b, c) {
            if (((b = b.jquery ? b : a(b)), (c = c || this._getInst(b)))) {
                if ((b.html(this._generateHTML(c)).toggleClass(this._rtlClass, c.options.isRTL), a.isFunction(c.options.onTick))) {
                    var d = "lap" != c._hold ? c._periods : this._calculatePeriods(c, c._show, c.options.significant, new Date());
                    (1 != c.options.tickInterval && this.periodsToSeconds(d) % c.options.tickInterval != 0) || c.options.onTick.apply(b[0], [d]);
                }
                var e = "pause" != c._hold && (c._since ? c._now.getTime() < c._since.getTime() : c._now.getTime() >= c._until.getTime());
                if (e && !c._expiring) {
                    if (((c._expiring = !0), this._hasElem(b[0]) || c.options.alwaysExpire)) {
                        if ((this._removeElem(b[0]), a.isFunction(c.options.onExpiry) && c.options.onExpiry.apply(b[0], []), c.options.expiryText)) {
                            var f = c.options.layout;
                            (c.options.layout = c.options.expiryText), this._updateCountdown(b[0], c), (c.options.layout = f);
                        }
                        c.options.expiryUrl && (window.location = c.options.expiryUrl);
                    }
                    c._expiring = !1;
                } else "pause" == c._hold && this._removeElem(b[0]);
            }
        },
        _resetExtraLabels: function (a, b) {
            for (var c in b) c.match(/[Ll]abels[02-9]|compactLabels1/) && (a[c] = b[c]);
            for (var c in a) c.match(/[Ll]abels[02-9]|compactLabels1/) && "undefined" == typeof b[c] && (a[c] = null);
        },
        _adjustSettings: function (b, c, d) {
            for (var e = null, f = 0; f < this._serverSyncs.length; f++)
                if (this._serverSyncs[f][0] == c.options.serverSync) {
                    e = this._serverSyncs[f][1];
                    break;
                }
            if (null != e)
                var g = c.options.serverSync ? e : 0,
                    h = new Date();
            else {
                var i = a.isFunction(c.options.serverSync) ? c.options.serverSync.apply(b[0], []) : null,
                    h = new Date(),
                    g = i ? h.getTime() - i.getTime() : 0;
                this._serverSyncs.push([c.options.serverSync, g]);
            }
            var j = c.options.timezone;
            (j = null == j ? -h.getTimezoneOffset() : j),
                (d || (!d && null == c._until && null == c._since)) &&
                    ((c._since = c.options.since),
                    null != c._since && ((c._since = this.UTCDate(j, this._determineTime(c._since, null))), c._since && g && c._since.setMilliseconds(c._since.getMilliseconds() + g)),
                    (c._until = this.UTCDate(j, this._determineTime(c.options.until, h))),
                    g && c._until.setMilliseconds(c._until.getMilliseconds() + g)),
                (c._show = this._determineShow(c));
        },
        _preDestroy: function (a, b) {
            this._removeElem(a[0]), a.empty();
        },
        pause: function (a) {
            this._hold(a, "pause");
        },
        lap: function (a) {
            this._hold(a, "lap");
        },
        resume: function (a) {
            this._hold(a, null);
        },
        toggle: function (b) {
            var c = a.data(b, this.name) || {};
            this[c._hold ? "resume" : "pause"](b);
        },
        toggleLap: function (b) {
            var c = a.data(b, this.name) || {};
            this[c._hold ? "resume" : "lap"](b);
        },
        _hold: function (b, c) {
            var d = a.data(b, this.name);
            if (d) {
                if ("pause" == d._hold && !c) {
                    d._periods = d._savePeriods;
                    var e = d._since ? "-" : "+";
                    (d[d._since ? "_since" : "_until"] = this._determineTime(
                        e + d._periods[0] + "y" + e + d._periods[1] + "o" + e + d._periods[2] + "w" + e + d._periods[3] + "d" + e + d._periods[4] + "h" + e + d._periods[5] + "m" + e + d._periods[6] + "s"
                    )),
                        this._addElem(b);
                }
                (d._hold = c), (d._savePeriods = "pause" == c ? d._periods : null), a.data(b, this.name, d), this._updateCountdown(b, d);
            }
        },
        getTimes: function (b) {
            var c = a.data(b, this.name);
            return c ? ("pause" == c._hold ? c._savePeriods : c._hold ? this._calculatePeriods(c, c._show, c.options.significant, new Date()) : c._periods) : null;
        },
        _determineTime: function (a, b) {
            var c = this,
                d = function (a) {
                    var b = new Date();
                    return b.setTime(b.getTime() + 1e3 * a), b;
                },
                e = function (a) {
                    a = a.toLowerCase();
                    for (var b = new Date(), d = b.getFullYear(), e = b.getMonth(), f = b.getDate(), g = b.getHours(), h = b.getMinutes(), i = b.getSeconds(), j = /([+-]?[0-9]+)\s*(s|m|h|d|w|o|y)?/g, k = j.exec(a); k; ) {
                        switch (k[2] || "s") {
                            case "s":
                                i += parseInt(k[1], 10);
                                break;
                            case "m":
                                h += parseInt(k[1], 10);
                                break;
                            case "h":
                                g += parseInt(k[1], 10);
                                break;
                            case "d":
                                f += parseInt(k[1], 10);
                                break;
                            case "w":
                                f += 7 * parseInt(k[1], 10);
                                break;
                            case "o":
                                (e += parseInt(k[1], 10)), (f = Math.min(f, c._getDaysInMonth(d, e)));
                                break;
                            case "y":
                                (d += parseInt(k[1], 10)), (f = Math.min(f, c._getDaysInMonth(d, e)));
                        }
                        k = j.exec(a);
                    }
                    return new Date(d, e, f, g, h, i, 0);
                },
                f = null == a ? b : "string" == typeof a ? e(a) : "number" == typeof a ? d(a) : a;
            return f && f.setMilliseconds(0), f;
        },
        _getDaysInMonth: function (a, b) {
            return 32 - new Date(a, b, 32).getDate();
        },
        _normalLabels: function (a) {
            return a;
        },
        _generateHTML: function (b) {
            var j = this;
            b._periods = b._hold ? b._periods : this._calculatePeriods(b, b._show, b.options.significant, new Date());
            for (var k = !1, l = 0, m = b.options.significant, n = a.extend({}, b._show), o = c; o <= i; o++)
                (k |= "?" == b._show[o] && b._periods[o] > 0), (n[o] = "?" != b._show[o] || k ? b._show[o] : null), (l += n[o] ? 1 : 0), (m -= b._periods[o] > 0 ? 1 : 0);
            for (var p = [!1, !1, !1, !1, !1, !1, !1], o = i; o >= c; o--) b._show[o] && (b._periods[o] ? (p[o] = !0) : ((p[o] = m > 0), m--));
            var q = b.options.compact ? b.options.compactLabels : b.options.labels,
                r = b.options.whichLabels || this._normalLabels,
                s = function (a) {
                    var c = b.options["compactLabels" + r(b._periods[a])];
                    return n[a] ? j._translateDigits(b, b._periods[a]) + (c ? c[a] : q[a]) + " " : "";
                },
                t = b.options.padZeroes ? 2 : 1,
                u = function (a) {
                    var c = b.options["labels" + r(b._periods[a])];
                    return (!b.options.significant && n[a]) || (b.options.significant && p[a])
                        ? '<span class="' + j._sectionClass + '"><span class="' + j._amountClass + '">' + j._minDigits(b, b._periods[a], t) + '</span><span class="' + j._periodClass + '">' + (c ? c[a] : q[a]) + "</span></span>"
                        : "";
                };
            return b.options.layout
                ? this._buildLayout(b, n, b.options.layout, b.options.compact, b.options.significant, p)
                : (b.options.compact
                      ? '<span class="' +
                        this._rowClass +
                        " " +
                        this._amountClass +
                        (b._hold ? " " + this._holdingClass : "") +
                        '">' +
                        s(c) +
                        s(d) +
                        s(e) +
                        s(f) +
                        (n[g] ? this._minDigits(b, b._periods[g], 2) : "") +
                        (n[h] ? (n[g] ? b.options.timeSeparator : "") + this._minDigits(b, b._periods[h], 2) : "") +
                        (n[i] ? (n[g] || n[h] ? b.options.timeSeparator : "") + this._minDigits(b, b._periods[i], 2) : "")
                      : '<span class="' + this._rowClass + " " + this._showClass + (b.options.significant || l) + (b._hold ? " " + this._holdingClass : "") + '">' + u(c) + u(d) + u(e) + u(f) + u(g) + u(h) + u(i)) +
                      "</span>" +
                      (b.options.description ? '<span class="' + this._rowClass + " " + this._descrClass + '">' + b.options.description + "</span>" : "");
        },
        _buildLayout: function (b, j, k, l, m, n) {
            for (
                var o = b.options[l ? "compactLabels" : "labels"],
                    p = b.options.whichLabels || this._normalLabels,
                    q = function (a) {
                        return (b.options[(l ? "compactLabels" : "labels") + p(b._periods[a])] || o)[a];
                    },
                    r = function (a, c) {
                        return b.options.digits[Math.floor(a / c) % 10];
                    },
                    s = {
                        desc: b.options.description,
                        sep: b.options.timeSeparator,
                        yl: q(c),
                        yn: this._minDigits(b, b._periods[c], 1),
                        ynn: this._minDigits(b, b._periods[c], 2),
                        ynnn: this._minDigits(b, b._periods[c], 3),
                        y1: r(b._periods[c], 1),
                        y10: r(b._periods[c], 10),
                        y100: r(b._periods[c], 100),
                        y1000: r(b._periods[c], 1e3),
                        ol: q(d),
                        on: this._minDigits(b, b._periods[d], 1),
                        onn: this._minDigits(b, b._periods[d], 2),
                        onnn: this._minDigits(b, b._periods[d], 3),
                        o1: r(b._periods[d], 1),
                        o10: r(b._periods[d], 10),
                        o100: r(b._periods[d], 100),
                        o1000: r(b._periods[d], 1e3),
                        wl: q(e),
                        wn: this._minDigits(b, b._periods[e], 1),
                        wnn: this._minDigits(b, b._periods[e], 2),
                        wnnn: this._minDigits(b, b._periods[e], 3),
                        w1: r(b._periods[e], 1),
                        w10: r(b._periods[e], 10),
                        w100: r(b._periods[e], 100),
                        w1000: r(b._periods[e], 1e3),
                        dl: q(f),
                        dn: this._minDigits(b, b._periods[f], 1),
                        dnn: this._minDigits(b, b._periods[f], 2),
                        dnnn: this._minDigits(b, b._periods[f], 3),
                        d1: r(b._periods[f], 1),
                        d10: r(b._periods[f], 10),
                        d100: r(b._periods[f], 100),
                        d1000: r(b._periods[f], 1e3),
                        hl: q(g),
                        hn: this._minDigits(b, b._periods[g], 1),
                        hnn: this._minDigits(b, b._periods[g], 2),
                        hnnn: this._minDigits(b, b._periods[g], 3),
                        h1: r(b._periods[g], 1),
                        h10: r(b._periods[g], 10),
                        h100: r(b._periods[g], 100),
                        h1000: r(b._periods[g], 1e3),
                        ml: q(h),
                        mn: this._minDigits(b, b._periods[h], 1),
                        mnn: this._minDigits(b, b._periods[h], 2),
                        mnnn: this._minDigits(b, b._periods[h], 3),
                        m1: r(b._periods[h], 1),
                        m10: r(b._periods[h], 10),
                        m100: r(b._periods[h], 100),
                        m1000: r(b._periods[h], 1e3),
                        sl: q(i),
                        sn: this._minDigits(b, b._periods[i], 1),
                        snn: this._minDigits(b, b._periods[i], 2),
                        snnn: this._minDigits(b, b._periods[i], 3),
                        s1: r(b._periods[i], 1),
                        s10: r(b._periods[i], 10),
                        s100: r(b._periods[i], 100),
                        s1000: r(b._periods[i], 1e3),
                    },
                    t = k,
                    u = c;
                u <= i;
                u++
            ) {
                var v = "yowdhms".charAt(u),
                    w = new RegExp("\\{" + v + "<\\}([\\s\\S]*)\\{" + v + ">\\}", "g");
                t = t.replace(w, (!m && j[u]) || (m && n[u]) ? "$1" : "");
            }
            return (
                a.each(s, function (a, b) {
                    var c = new RegExp("\\{" + a + "\\}", "g");
                    t = t.replace(c, b);
                }),
                t
            );
        },
        _minDigits: function (a, b, c) {
            return (b = "" + b), b.length >= c ? this._translateDigits(a, b) : ((b = "0000000000" + b), this._translateDigits(a, b.substr(b.length - c)));
        },
        _translateDigits: function (a, b) {
            return ("" + b).replace(/[0-9]/g, function (b) {
                return a.options.digits[b];
            });
        },
        _determineShow: function (a) {
            var b = a.options.format,
                j = [];
            return (
                (j[c] = b.match("y") ? "?" : b.match("Y") ? "!" : null),
                (j[d] = b.match("o") ? "?" : b.match("O") ? "!" : null),
                (j[e] = b.match("w") ? "?" : b.match("W") ? "!" : null),
                (j[f] = b.match("d") ? "?" : b.match("D") ? "!" : null),
                (j[g] = b.match("h") ? "?" : b.match("H") ? "!" : null),
                (j[h] = b.match("m") ? "?" : b.match("M") ? "!" : null),
                (j[i] = b.match("s") ? "?" : b.match("S") ? "!" : null),
                j
            );
        },
        _calculatePeriods: function (a, b, j, k) {
            (a._now = k), a._now.setMilliseconds(0);
            var l = new Date(a._now.getTime());
            a._since ? (k.getTime() < a._since.getTime() ? (a._now = k = l) : (k = a._since)) : (l.setTime(a._until.getTime()), k.getTime() > a._until.getTime() && (a._now = k = l));
            var m = [0, 0, 0, 0, 0, 0, 0];
            if (b[c] || b[d]) {
                var n = this._getDaysInMonth(k.getFullYear(), k.getMonth()),
                    o = this._getDaysInMonth(l.getFullYear(), l.getMonth()),
                    p = l.getDate() == k.getDate() || (l.getDate() >= Math.min(n, o) && k.getDate() >= Math.min(n, o)),
                    q = function (a) {
                        return 60 * (60 * a.getHours() + a.getMinutes()) + a.getSeconds();
                    },
                    r = Math.max(0, 12 * (l.getFullYear() - k.getFullYear()) + l.getMonth() - k.getMonth() + ((l.getDate() < k.getDate() && !p) || (p && q(l) < q(k)) ? -1 : 0));
                (m[c] = b[c] ? Math.floor(r / 12) : 0), (m[d] = b[d] ? r - 12 * m[c] : 0), (k = new Date(k.getTime()));
                var s = k.getDate() == n,
                    t = this._getDaysInMonth(k.getFullYear() + m[c], k.getMonth() + m[d]);
                k.getDate() > t && k.setDate(t), k.setFullYear(k.getFullYear() + m[c]), k.setMonth(k.getMonth() + m[d]), s && k.setDate(t);
            }
            var u = Math.floor((l.getTime() - k.getTime()) / 1e3),
                v = function (a, c) {
                    (m[a] = b[a] ? Math.floor(u / c) : 0), (u -= m[a] * c);
                };
            if ((v(e, 604800), v(f, 86400), v(g, 3600), v(h, 60), v(i, 1), u > 0 && !a._since))
                for (var w = [1, 12, 4.3482, 7, 24, 60, 60], x = i, y = 1, z = i; z >= c; z--) b[z] && (m[x] >= y && ((m[x] = 0), (u = 1)), u > 0 && (m[z]++, (u = 0), (x = z), (y = 1))), (y *= w[z]);
            if (j) for (var z = c; z <= i; z++) j && m[z] ? j-- : j || (m[z] = 0);
            return m;
        },
    });
})(jQuery);
if (void 0 === Currency) var Currency = {};
(Currency.cookie = {
    name: "roarStorage_currency",
    write: function (d) {
        try {
            localStorage.setItem(this.name, d);
        } catch (e) {}
    },
    read: function () {
        try {
            return localStorage.getItem(this.name);
        } catch (d) {
            return null;
        }
    },
    destroy: function () {
        try {
            localStorage.setItem(this.name, null);
        } catch (d) {}
    },
}),
    (Currency.moneyFormats = {
        USD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} USD" },
        EUR: { money_format: "&euro;{{amount}}", money_with_currency_format: "&euro;{{amount}} EUR" },
        GBP: { money_format: "&pound;{{amount}}", money_with_currency_format: "&pound;{{amount}} GBP" },
        CAD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} CAD" },
        ALL: { money_format: "Lek {{amount}}", money_with_currency_format: "Lek {{amount}} ALL" },
        DZD: { money_format: "DA {{amount}}", money_with_currency_format: "DA {{amount}} DZD" },
        AOA: { money_format: "Kz{{amount}}", money_with_currency_format: "Kz{{amount}} AOA" },
        ARS: { money_format: "${{amount_with_comma_separator}}", money_with_currency_format: "${{amount_with_comma_separator}} ARS" },
        AMD: { money_format: "{{amount}} AMD", money_with_currency_format: "{{amount}} AMD" },
        AWG: { money_format: "Afl{{amount}}", money_with_currency_format: "Afl{{amount}} AWG" },
        AUD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} AUD" },
        BBD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} Bds" },
        AZN: { money_format: "m.{{amount}}", money_with_currency_format: "m.{{amount}} AZN" },
        BDT: { money_format: "Tk {{amount}}", money_with_currency_format: "Tk {{amount}} BDT" },
        BSD: { money_format: "BS${{amount}}", money_with_currency_format: "BS${{amount}} BSD" },
        BHD: { money_format: "{{amount}}0 BD", money_with_currency_format: "{{amount}}0 BHD" },
        BYR: { money_format: "Br {{amount}}", money_with_currency_format: "Br {{amount}} BYR" },
        BZD: { money_format: "BZ${{amount}}", money_with_currency_format: "BZ${{amount}} BZD" },
        BTN: { money_format: "Nu {{amount}}", money_with_currency_format: "Nu {{amount}} BTN" },
        BAM: { money_format: "KM {{amount_with_comma_separator}}", money_with_currency_format: "KM {{amount_with_comma_separator}} BAM" },
        BRL: { money_format: "R$ {{amount_with_comma_separator}}", money_with_currency_format: "R$ {{amount_with_comma_separator}} BRL" },
        BOB: { money_format: "Bs{{amount_with_comma_separator}}", money_with_currency_format: "Bs{{amount_with_comma_separator}} BOB" },
        BWP: { money_format: "P{{amount}}", money_with_currency_format: "P{{amount}} BWP" },
        BND: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} BND" },
        BGN: { money_format: "{{amount}} \u043B\u0432", money_with_currency_format: "{{amount}} \u043B\u0432 BGN" },
        MMK: { money_format: "K{{amount}}", money_with_currency_format: "K{{amount}} MMK" },
        KHR: { money_format: "KHR{{amount}}", money_with_currency_format: "KHR{{amount}}" },
        KYD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} KYD" },
        XAF: { money_format: "FCFA{{amount}}", money_with_currency_format: "FCFA{{amount}} XAF" },
        CLP: { money_format: "${{amount_no_decimals}}", money_with_currency_format: "${{amount_no_decimals}} CLP" },
        CNY: { money_format: "&#165;{{amount}}", money_with_currency_format: "&#165;{{amount}} CNY" },
        COP: { money_format: "${{amount_with_comma_separator}}", money_with_currency_format: "${{amount_with_comma_separator}} COP" },
        CRC: { money_format: "&#8353; {{amount_with_comma_separator}}", money_with_currency_format: "&#8353; {{amount_with_comma_separator}} CRC" },
        HRK: { money_format: "{{amount_with_comma_separator}} kn", money_with_currency_format: "{{amount_with_comma_separator}} kn HRK" },
        CZK: { money_format: "{{amount_with_comma_separator}} K&#269;", money_with_currency_format: "{{amount_with_comma_separator}} K&#269;" },
        DKK: { money_format: "{{amount_with_comma_separator}}", money_with_currency_format: "kr.{{amount_with_comma_separator}}" },
        DOP: { money_format: "RD$ {{amount}}", money_with_currency_format: "RD$ {{amount}}" },
        XCD: { money_format: "${{amount}}", money_with_currency_format: "EC${{amount}}" },
        EGP: { money_format: "LE {{amount}}", money_with_currency_format: "LE {{amount}} EGP" },
        ETB: { money_format: "Br{{amount}}", money_with_currency_format: "Br{{amount}} ETB" },
        XPF: { money_format: "{{amount_no_decimals_with_comma_separator}} XPF", money_with_currency_format: "{{amount_no_decimals_with_comma_separator}} XPF" },
        FJD: { money_format: "${{amount}}", money_with_currency_format: "FJ${{amount}}" },
        GMD: { money_format: "D {{amount}}", money_with_currency_format: "D {{amount}} GMD" },
        GHS: { money_format: "GH&#8373;{{amount}}", money_with_currency_format: "GH&#8373;{{amount}}" },
        GTQ: { money_format: "Q{{amount}}", money_with_currency_format: "{{amount}} GTQ" },
        GYD: { money_format: "G${{amount}}", money_with_currency_format: "${{amount}} GYD" },
        GEL: { money_format: "{{amount}} GEL", money_with_currency_format: "{{amount}} GEL" },
        HNL: { money_format: "L {{amount}}", money_with_currency_format: "L {{amount}} HNL" },
        HKD: { money_format: "${{amount}}", money_with_currency_format: "HK${{amount}}" },
        HUF: { money_format: "{{amount_no_decimals_with_comma_separator}}", money_with_currency_format: "{{amount_no_decimals_with_comma_separator}} Ft" },
        ISK: { money_format: "{{amount_no_decimals}} kr", money_with_currency_format: "{{amount_no_decimals}} kr ISK" },
        INR: { money_format: "Rs. {{amount}}", money_with_currency_format: "Rs. {{amount}}" },
        IDR: { money_format: "{{amount_with_comma_separator}}", money_with_currency_format: "Rp {{amount_with_comma_separator}}" },
        ILS: { money_format: "{{amount}} NIS", money_with_currency_format: "{{amount}} NIS" },
        JMD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} JMD" },
        JPY: { money_format: "&#165;{{amount_no_decimals}}", money_with_currency_format: "&#165;{{amount_no_decimals}} JPY" },
        JEP: { money_format: "&pound;{{amount}}", money_with_currency_format: "&pound;{{amount}} JEP" },
        JOD: { money_format: "{{amount}}0 JD", money_with_currency_format: "{{amount}}0 JOD" },
        KZT: { money_format: "{{amount}} KZT", money_with_currency_format: "{{amount}} KZT" },
        KES: { money_format: "KSh{{amount}}", money_with_currency_format: "KSh{{amount}}" },
        KWD: { money_format: "{{amount}}0 KD", money_with_currency_format: "{{amount}}0 KWD" },
        KGS: { money_format: "\u043B\u0432{{amount}}", money_with_currency_format: "\u043B\u0432{{amount}}" },
        LVL: { money_format: "Ls {{amount}}", money_with_currency_format: "Ls {{amount}} LVL" },
        LBP: { money_format: "L&pound;{{amount}}", money_with_currency_format: "L&pound;{{amount}} LBP" },
        LTL: { money_format: "{{amount}} Lt", money_with_currency_format: "{{amount}} Lt" },
        MGA: { money_format: "Ar {{amount}}", money_with_currency_format: "Ar {{amount}} MGA" },
        MKD: { money_format: "\u0434\u0435\u043D {{amount}}", money_with_currency_format: "\u0434\u0435\u043D {{amount}} MKD" },
        MOP: { money_format: "MOP${{amount}}", money_with_currency_format: "MOP${{amount}}" },
        MVR: { money_format: "Rf{{amount}}", money_with_currency_format: "Rf{{amount}} MRf" },
        MXN: { money_format: "$ {{amount}}", money_with_currency_format: "$ {{amount}} MXN" },
        MYR: { money_format: "RM{{amount}} MYR", money_with_currency_format: "RM{{amount}} MYR" },
        MUR: { money_format: "Rs {{amount}}", money_with_currency_format: "Rs {{amount}} MUR" },
        MDL: { money_format: "{{amount}} MDL", money_with_currency_format: "{{amount}} MDL" },
        MAD: { money_format: "{{amount}} dh", money_with_currency_format: "Dh {{amount}} MAD" },
        MNT: { money_format: "{{amount_no_decimals}} &#8366", money_with_currency_format: "{{amount_no_decimals}} MNT" },
        MZN: { money_format: "{{amount}} Mt", money_with_currency_format: "Mt {{amount}} MZN" },
        NAD: { money_format: "N${{amount}}", money_with_currency_format: "N${{amount}} NAD" },
        NPR: { money_format: "Rs{{amount}}", money_with_currency_format: "Rs{{amount}} NPR" },
        ANG: { money_format: "&fnof;{{amount}}", money_with_currency_format: "{{amount}} NA&fnof;" },
        NZD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} NZD" },
        NIO: { money_format: "C${{amount}}", money_with_currency_format: "C${{amount}} NIO" },
        NGN: { money_format: "&#8358;{{amount}}", money_with_currency_format: "&#8358;{{amount}} NGN" },
        NOK: { money_format: "kr {{amount_with_comma_separator}}", money_with_currency_format: "kr {{amount_with_comma_separator}} NOK" },
        OMR: { money_format: "{{amount_with_comma_separator}} OMR", money_with_currency_format: "{{amount_with_comma_separator}} OMR" },
        PKR: { money_format: "Rs.{{amount}}", money_with_currency_format: "Rs.{{amount}} PKR" },
        PGK: { money_format: "K {{amount}}", money_with_currency_format: "K {{amount}} PGK" },
        PYG: { money_format: "Gs. {{amount_no_decimals_with_comma_separator}}", money_with_currency_format: "Gs. {{amount_no_decimals_with_comma_separator}} PYG" },
        PEN: { money_format: "S/. {{amount}}", money_with_currency_format: "S/. {{amount}} PEN" },
        PHP: { money_format: "&#8369;{{amount}}", money_with_currency_format: "&#8369;{{amount}} PHP" },
        PLN: { money_format: "{{amount_with_comma_separator}} zl", money_with_currency_format: "{{amount_with_comma_separator}} zl PLN" },
        QAR: { money_format: "QAR {{amount_with_comma_separator}}", money_with_currency_format: "QAR {{amount_with_comma_separator}}" },
        RON: { money_format: "{{amount_with_comma_separator}} lei", money_with_currency_format: "{{amount_with_comma_separator}} lei RON" },
        RUB: { money_format: "&#1088;&#1091;&#1073;{{amount_with_comma_separator}}", money_with_currency_format: "&#1088;&#1091;&#1073;{{amount_with_comma_separator}} RUB" },
        RWF: { money_format: "{{amount_no_decimals}} RF", money_with_currency_format: "{{amount_no_decimals}} RWF" },
        WST: { money_format: "WS$ {{amount}}", money_with_currency_format: "WS$ {{amount}} WST" },
        SAR: { money_format: "{{amount}} SR", money_with_currency_format: "{{amount}} SAR" },
        STD: { money_format: "Db {{amount}}", money_with_currency_format: "Db {{amount}} STD" },
        RSD: { money_format: "{{amount}} RSD", money_with_currency_format: "{{amount}} RSD" },
        SCR: { money_format: "Rs {{amount}}", money_with_currency_format: "Rs {{amount}} SCR" },
        SGD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} SGD" },
        SYP: { money_format: "S&pound;{{amount}}", money_with_currency_format: "S&pound;{{amount}} SYP" },
        ZAR: { money_format: "R {{amount}}", money_with_currency_format: "R {{amount}} ZAR" },
        KRW: { money_format: "&#8361;{{amount_no_decimals}}", money_with_currency_format: "&#8361;{{amount_no_decimals}} KRW" },
        LKR: { money_format: "Rs {{amount}}", money_with_currency_format: "Rs {{amount}} LKR" },
        SEK: { money_format: "{{amount_no_decimals}} kr", money_with_currency_format: "{{amount_no_decimals}} kr SEK" },
        CHF: { money_format: "SFr. {{amount}}", money_with_currency_format: "SFr. {{amount}} CHF" },
        TWD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} TWD" },
        THB: { money_format: "{{amount}} &#xe3f;", money_with_currency_format: "{{amount}} &#xe3f; THB" },
        TZS: { money_format: "{{amount}} TZS", money_with_currency_format: "{{amount}} TZS" },
        TTD: { money_format: "${{amount}}", money_with_currency_format: "${{amount}} TTD" },
        TND: { money_format: "{{amount}}", money_with_currency_format: "{{amount}} DT" },
        TRY: { money_format: "{{amount}}TL", money_with_currency_format: "{{amount}}TL" },
        UGX: { money_format: "Ush {{amount_no_decimals}}", money_with_currency_format: "Ush {{amount_no_decimals}} UGX" },
        UAH: { money_format: "\u20B4{{amount}}", money_with_currency_format: "\u20B4{{amount}} UAH" },
        AED: { money_format: "Dhs. {{amount}}", money_with_currency_format: "Dhs. {{amount}} AED" },
        UYU: { money_format: "${{amount_with_comma_separator}}", money_with_currency_format: "${{amount_with_comma_separator}} UYU" },
        VUV: { money_format: "${{amount}}", money_with_currency_format: "${{amount}}VT" },
        VEF: { money_format: "Bs. {{amount_with_comma_separator}}", money_with_currency_format: "Bs. {{amount_with_comma_separator}} VEF" },
        VND: { money_format: "{{amount_no_decimals_with_comma_separator}}&#8363;", money_with_currency_format: "{{amount_no_decimals_with_comma_separator}} VND" },
        XBT: { money_format: "{{amount_no_decimals}} BTC", money_with_currency_format: "{{amount_no_decimals}} BTC" },
        XOF: { money_format: "CFA{{amount}}", money_with_currency_format: "CFA{{amount}} XOF" },
        ZMW: { money_format: "K{{amount_no_decimals_with_comma_separator}}", money_with_currency_format: "ZMW{{amount_no_decimals_with_comma_separator}}" },
        AFN: { money_format: "&#65;&#102; {{amount}}", money_with_currency_format: "&#65;&#102; {{amount}} AFN" },
        CVE: { money_format: "&#36; {{amount}}", money_with_currency_format: "&#36; {{amount}} CVE" },
        KMF: { money_format: "&#67;&#70; {{amount}}", money_with_currency_format: "&#67;&#70; {{amount}} KMF" },
        CDF: { money_format: "&#70;&#67; {{amount}}", money_with_currency_format: "&#70;&#67; {{amount}} CDF" },
        HTG: { money_format: "&#71; {{amount}}", money_with_currency_format: "&#71; {{amount}} HTG" },
        LAK: { money_format: "&#8365; {{amount}}", money_with_currency_format: "&#8365; {{amount}} LAK" },
        LSL: { money_format: "&#76; {{amount}}", money_with_currency_format: "&#76; {{amount}} LSL" },
        LRD: { money_format: "&#36; {{amount}}", money_with_currency_format: "&#36; {{amount}} LRD" },
        MWK: { money_format: "&#77;&#75; {{amount}}", money_with_currency_format: "&#77;&#75; {{amount}} MWK" },
        SDG: { money_format: "&#163; {{amount}}", money_with_currency_format: "&#163; {{amount}} SDG" },
        SBD: { money_format: "&#36; {{amount}}", money_with_currency_format: "&#36; {{amount}} SBD" },
        SRD: { money_format: "&#36; {{amount}}", money_with_currency_format: "&#36; {{amount}} SRD" },
        SZL: { money_format: "&#76; {{amount}}", money_with_currency_format: "&#76; {{amount}} SZL" },
        TMT: { money_format: "&#109; {{amount}}", money_with_currency_format: "&#109; {{amount}} TMT" },
        UZS: { money_format: "&#1083;&#1074; {{amount}}", money_with_currency_format: "&#1083;&#1074; {{amount}} UZS" },
        YER: { money_format: "&#65020; {{amount}}", money_with_currency_format: "&#65020; {{amount}} YER" },
    }),
    (Currency.formatMoney = function (d, e) {
        function f(k, l) {
            return void 0 === k ? l : k;
        }
        function g(k, l, p, q) {
            if (((l = f(l, 2)), (p = f(p, ",")), (q = f(q, ".")), isNaN(k) || null == k)) return 0;
            var s = (k = (k / 100).toFixed(l)).split(".");
            return s[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + p) + (s[1] ? q + s[1] : "");
        }
        if ("function" == typeof Shopify.formatMoney) return Shopify.formatMoney(d, e);
        "string" == typeof d && (d = d.replace(".", ""));
        var h = "",
            i = /\{\{\s*(\w+)\s*\}\}/,
            j = e || "${{amount}}";
        switch (j.match(i)[1]) {
            case "amount":
                h = g(d, 2);
                break;
            case "amount_no_decimals":
                h = g(d, 0);
                break;
            case "amount_with_comma_separator":
                h = g(d, 2, ".", ",");
                break;
            case "amount_no_decimals_with_comma_separator":
                h = g(d, 0, ".", ",");
        }
        return j.replace(i, h);
    }),
    (Currency.currentCurrency = ""),
    (Currency.format = "money_with_currency_format"),
    (Currency.convertAll = function (d, e, f, g) {
        jQuery(f || "span.money").each(function () {
            if (jQuery(this).attr("data-currency") !== e) {
                if (jQuery(this).attr("data-currency-" + e)) jQuery(this).html(jQuery(this).attr("data-currency-" + e));
                else {
                    var h = 0,
                        i = Currency.moneyFormats[d][g || Currency.format] || "{{amount}}",
                        j = Currency.moneyFormats[e][g || Currency.format] || "{{amount}}";
                    h =
                        -1 === i.indexOf("amount_no_decimals")
                            ? "JOD" === d || "KWD" == d || "BHD" == d
                                ? Currency.convert(
                                      parseInt(
                                          jQuery(this)
                                              .html()
                                              .replace(/[^0-9]/g, ""),
                                          10
                                      ) / 10,
                                      d,
                                      e
                                  )
                                : Currency.convert(
                                      parseInt(
                                          jQuery(this)
                                              .html()
                                              .replace(/[^0-9]/g, ""),
                                          10
                                      ),
                                      d,
                                      e
                                  )
                            : Currency.convert(
                                  100 *
                                      parseInt(
                                          jQuery(this)
                                              .html()
                                              .replace(/[^0-9]/g, ""),
                                          10
                                      ),
                                  d,
                                  e
                              );
                    var k = Currency.formatMoney(h, j);
                    jQuery(this).html(k), jQuery(this).attr("data-currency-" + e, k);
                }
                jQuery(this).attr("data-currency", e);
            }
        }),
            (this.currentCurrency = e),
            this.cookie.write(e);
    });
var RoarCookie = {
    cookie: {
        rtread: function (d) {
            try {
                return localStorage.getItem(d);
            } catch (e) {
                return null;
            }
        },
        rtwrite: function (d, e) {
            try {
                localStorage.setItem(d, e);
            } catch (f) {}
        },
        destroy: function (d) {
            try {
                localStorage.setItem(d, null);
            } catch (e) {}
        },
    },
};
jQuery.cookie = function (b, j, m) {
    if (typeof j != "undefined") {
        m = m || {};
        if (j === null) {
            j = "";
            m.expires = -1;
        }
        var e = "";
        if (m.expires && (typeof m.expires == "number" || m.expires.toUTCString)) {
            var f;
            if (typeof m.expires == "number") {
                f = new Date();
                f.setTime(f.getTime() + m.expires * 24 * 60 * 60 * 1000);
            } else {
                f = m.expires;
            }
            e = "; expires=" + f.toUTCString();
        }
        var l = m.path ? "; path=" + m.path : "";
        var g = m.domain ? "; domain=" + m.domain : "";
        var a = m.secure ? "; secure" : "";
        document.cookie = [b, "=", encodeURIComponent(j), e, l, g, a].join("");
    } else {
        var d = null;
        if (document.cookie && document.cookie != "") {
            var k = document.cookie.split(";");
            for (var h = 0; h < k.length; h++) {
                var c = jQuery.trim(k[h]);
                if (c.substring(0, b.length + 1) == b + "=") {
                    d = decodeURIComponent(c.substring(b.length + 1));
                    break;
                }
            }
        }
        return d;
    }
};
var _0x2098 = [
    "\x68\x69\x64\x64\x65\x6e",
    "\x63\x73\x73",
    "\x65\x72\x72\x6f\x72\x20\x6f\x6e\x20\x6d\x61\x69\x6e\x43\x68\x65\x63\x6b",
    "\x59\x6f\x75\x20\x6e\x65\x65\x64\x20\x75\x73\x65\x20\x45\x6e\x76\x61\x74\x6f\x20\x70\x75\x72\x63\x68\x61\x73\x65\x20\x63\x6f\x64\x65\x20\x74\x6f\x20\x61\x63\x74\x69\x76\x61\x74\x65\x20\x46\x61\x73\x74\x6f\x72\x20\x53\x68\x6f\x70\x69\x66\x79\x20\x54\x68\x65\x6d\x65",
    "\x73\x75\x70\x70\x6f\x72\x74\x40\x72\x6f\x61\x72\x74\x68\x65\x6d\x65\x2e\x63\x6f\x6d",
    "\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x62\x6f\x78\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x2d\x77\x65\x62\x6b\x69\x74\x2d\x66\x6c\x65\x78\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x66\x6c\x65\x78\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x66\x6c\x65\x78\x2d\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6c\x75\x6d\x6e\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6c\x75\x6d\x6e\x3b\x66\x6c\x65\x78\x2d\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6c\x75\x6d\x6e\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x66\x6c\x65\x78\x2d\x77\x72\x61\x70\x3a\x6e\x6f\x77\x72\x61\x70\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x77\x72\x61\x70\x3a\x6e\x6f\x77\x72\x61\x70\x3b\x66\x6c\x65\x78\x2d\x77\x72\x61\x70\x3a\x6e\x6f\x77\x72\x61\x70\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x6a\x75\x73\x74\x69\x66\x79\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x70\x61\x63\x6b\x3a\x63\x65\x6e\x74\x65\x72\x3b\x6a\x75\x73\x74\x69\x66\x79\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x61\x6c\x69\x67\x6e\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x6c\x69\x6e\x65\x2d\x70\x61\x63\x6b\x3a\x63\x65\x6e\x74\x65\x72\x3b\x61\x6c\x69\x67\x6e\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x61\x6c\x69\x67\x6e\x2d\x69\x74\x65\x6d\x73\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x3b\x61\x6c\x69\x67\x6e\x2d\x69\x74\x65\x6d\x73\x3a\x63\x65\x6e\x74\x65\x72\x3b\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2d\x63\x6f\x6c\x6f\x72\x3a\x72\x67\x62\x28\x32\x35\x2c\x20\x32\x35\x2c\x20\x32\x35\x29\x3b\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2d\x63\x6f\x6c\x6f\x72\x3a\x72\x67\x62\x28\x32\x35\x2c\x20\x32\x35\x2c\x20\x32\x35\x2c\x20\x30\x2e\x39\x35\x29\x3b\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x66\x69\x78\x65\x64\x3b\x74\x6f\x70\x3a\x30\x3b\x6c\x65\x66\x74\x3a\x30\x3b\x77\x69\x64\x74\x68\x3a\x31\x30\x30\x25\x3b\x68\x65\x69\x67\x68\x74\x3a\x31\x30\x30\x25\x3b\x7a\x2d\x69\x6e\x64\x65\x78\x3a\x31\x36\x37\x37\x37\x32\x3b\x22\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x70\x61\x64\x64\x69\x6e\x67\x3a\x32\x30\x70\x78\x3b\x74\x65\x78\x74\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x22\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x6f\x6e\x74\x2d\x77\x65\x69\x67\x68\x74\x3a\x36\x30\x30\x3b\x66\x6f\x6e\x74\x2d\x73\x69\x7a\x65\x3a\x33\x38\x70\x78\x3b\x6c\x69\x6e\x65\x2d\x68\x65\x69\x67\x68\x74\x3a\x34\x39\x70\x78\x3b\x74\x65\x78\x74\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x3b\x63\x6f\x6c\x6f\x72\x3a\x23\x46\x46\x46\x46\x46\x46\x3b\x22\x3e",
    "\x22\x73\x74\x79\x6c\x65\x3d\x22\x63\x6f\x6c\x6f\x72\x3a\x23\x34\x31\x37\x64\x66\x62\x3b\x74\x65\x78\x74\x2d\x64\x65\x63\x6f\x72\x61\x74\x69\x6f\x6e\x3a\x6e\x6f\x6e\x65\x3b\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x72\x65\x6c\x61\x74\x69\x76\x65\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x69\x6e\x6c\x69\x6e\x65\x3a\x62\x6c\x6f\x63\x6b\x3b\x22\x3e\x3c\x73\x70\x61\x6e\x20\x73\x74\x79\x6c\x65\x3d\x22\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x61\x62\x73\x6f\x6c\x75\x74\x65\x3b\x7a\x2d\x69\x6e\x64\x65\x78\x3a\x32\x3b\x62\x6f\x74\x74\x6f\x6d\x3a\x36\x70\x78\x3b\x6c\x65\x66\x74\x3a\x30\x3b\x72\x69\x67\x68\x74\x3a\x30\x3b\x6d\x61\x72\x67\x69\x6e\x3a\x61\x75\x74\x6f\x3b\x77\x69\x64\x74\x68\x3a\x31\x30\x30\x25\x3b\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x22\x22\x3b\x63\x6f\x6c\x6f\x72\x3a\x74\x72\x61\x6e\x73\x70\x61\x72\x65\x6e\x74\x3b\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2d\x63\x6f\x6c\x6f\x72\x3a\x23\x34\x31\x37\x64\x66\x62\x3b\x68\x65\x69\x67\x68\x74\x3a\x31\x70\x78\x3b\x70\x6f\x69\x6e\x74\x65\x72\x2d\x65\x76\x65\x6e\x74\x73\x3a\x6e\x6f\x6e\x65\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x74\x72\x61\x6e\x73\x69\x74\x69\x6f\x6e\x3a\x77\x69\x64\x74\x68\x20\x2e\x32\x73\x3b\x74\x72\x61\x6e\x73\x69\x74\x69\x6f\x6e\x3a\x77\x69\x64\x74\x68\x20\x2e\x32\x73\x3b\x22\x3e\x3c\x2f\x73\x70\x61\x6e\x3e",
    "\x3c\x2f\x61\x3e\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e",
    "\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x62\x6f\x78\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x2d\x77\x65\x62\x6b\x69\x74\x2d\x66\x6c\x65\x78\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x66\x6c\x65\x78\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x66\x6c\x65\x78\x2d\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6c\x75\x6d\x6e\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6c\x75\x6d\x6e\x3b\x66\x6c\x65\x78\x2d\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6c\x75\x6d\x6e\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x66\x6c\x65\x78\x2d\x77\x72\x61\x70\x3a\x6e\x6f\x77\x72\x61\x70\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x77\x72\x61\x70\x3a\x6e\x6f\x77\x72\x61\x70\x3b\x66\x6c\x65\x78\x2d\x77\x72\x61\x70\x3a\x6e\x6f\x77\x72\x61\x70\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x6a\x75\x73\x74\x69\x66\x79\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x70\x61\x63\x6b\x3a\x63\x65\x6e\x74\x65\x72\x3b\x6a\x75\x73\x74\x69\x66\x79\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x61\x6c\x69\x67\x6e\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x6c\x69\x6e\x65\x2d\x70\x61\x63\x6b\x3a\x63\x65\x6e\x74\x65\x72\x3b\x61\x6c\x69\x67\x6e\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x61\x6c\x69\x67\x6e\x2d\x69\x74\x65\x6d\x73\x3a\x63\x65\x6e\x74\x65\x72\x3b\x2d\x6d\x73\x2d\x66\x6c\x65\x78\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x3b\x61\x6c\x69\x67\x6e\x2d\x69\x74\x65\x6d\x73\x3a\x63\x65\x6e\x74\x65\x72\x3b\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2d\x63\x6f\x6c\x6f\x72\x3a\x72\x67\x62\x28\x32\x35\x2c\x20\x32\x35\x2c\x20\x32\x35\x29\x3b\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2d\x63\x6f\x6c\x6f\x72\x3a\x72\x67\x62\x28\x32\x35\x2c\x20\x32\x35\x2c\x20\x32\x35\x2c\x20\x30\x2e\x39\x35\x29\x3b\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x66\x69\x78\x65\x64\x3b\x74\x6f\x70\x3a\x30\x3b\x6c\x65\x66\x74\x3a\x30\x3b\x77\x69\x64\x74\x68\x3a\x31\x30\x30\x25\x3b\x68\x65\x69\x67\x68\x74\x3a\x31\x30\x30\x25\x3b\x7a\x2d\x69\x6e\x64\x65\x78\x3a\x31\x36\x37\x37\x37\x32\x3b\x22\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x70\x61\x64\x64\x69\x6e\x67\x3a\x32\x30\x70\x78\x3b\x74\x65\x78\x74\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x22\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x6f\x6e\x74\x2d\x77\x65\x69\x67\x68\x74\x3a\x36\x30\x30\x3b\x66\x6f\x6e\x74\x2d\x73\x69\x7a\x65\x3a\x33\x38\x70\x78\x3b\x6c\x69\x6e\x65\x2d\x68\x65\x69\x67\x68\x74\x3a\x34\x39\x70\x78\x3b\x74\x65\x78\x74\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x3b\x63\x6f\x6c\x6f\x72\x3a\x23\x46\x46\x46\x46\x46\x46\x3b\x22\x3e\x59\x6f\x75\x72\x20\x73\x65\x74\x20\x75\x70\x20\x69\x73\x20\x77\x72\x6f\x6e\x67\x20\x61\x6e\x64\x20\x69\x74\x20\x69\x73\x20\x65\x72\x72\x6f\x72\x20\x6f\x6e\x20\x6c\x6f\x61\x64\x69\x6e\x67\x3c\x62\x72\x3e\x43\x6f\x6e\x74\x61\x63\x74\x20\x75\x73\x20\x76\x69\x61\x20\x3c\x61\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x74\x2d\x65\x78\x74\x72\x61\x6c\x69\x6e\x6b\x22\x68\x72\x65\x66\x3d\x22\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x6f\x61\x72\x74\x68\x65\x6d\x65\x2e\x74\x69\x63\x6b\x73\x79\x2e\x63\x6f\x6d\x22\x73\x74\x79\x6c\x65\x3d\x22\x63\x6f\x6c\x6f\x72\x3a\x23\x34\x31\x37\x64\x66\x62\x3b\x74\x65\x78\x74\x2d\x64\x65\x63\x6f\x72\x61\x74\x69\x6f\x6e\x3a\x6e\x6f\x6e\x65\x3b\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x72\x65\x6c\x61\x74\x69\x76\x65\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x69\x6e\x6c\x69\x6e\x65\x3a\x62\x6c\x6f\x63\x6b\x3b\x22\x3e\x3c\x73\x70\x61\x6e\x20\x73\x74\x79\x6c\x65\x3d\x22\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x61\x62\x73\x6f\x6c\x75\x74\x65\x3b\x7a\x2d\x69\x6e\x64\x65\x78\x3a\x32\x3b\x62\x6f\x74\x74\x6f\x6d\x3a\x36\x70\x78\x3b\x6c\x65\x66\x74\x3a\x30\x3b\x72\x69\x67\x68\x74\x3a\x30\x3b\x6d\x61\x72\x67\x69\x6e\x3a\x61\x75\x74\x6f\x3b\x77\x69\x64\x74\x68\x3a\x31\x30\x30\x25\x3b\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x22\x22\x3b\x63\x6f\x6c\x6f\x72\x3a\x74\x72\x61\x6e\x73\x70\x61\x72\x65\x6e\x74\x3b\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2d\x63\x6f\x6c\x6f\x72\x3a\x23\x34\x31\x37\x64\x66\x62\x3b\x68\x65\x69\x67\x68\x74\x3a\x31\x70\x78\x3b\x70\x6f\x69\x6e\x74\x65\x72\x2d\x65\x76\x65\x6e\x74\x73\x3a\x6e\x6f\x6e\x65\x3b\x2d\x77\x65\x62\x6b\x69\x74\x2d\x74\x72\x61\x6e\x73\x69\x74\x69\x6f\x6e\x3a\x77\x69\x64\x74\x68\x20\x2e\x32\x73\x3b\x74\x72\x61\x6e\x73\x69\x74\x69\x6f\x6e\x3a\x77\x69\x64\x74\x68\x20\x2e\x32\x73\x3b\x22\x3e\x3c\x2f\x73\x70\x61\x6e\x3e\x74\x69\x63\x6b\x65\x74\x20\x73\x79\x73\x74\x65\x6d\x3c\x2f\x61\x3e\x20\x61\x6e\x64\x20\x6f\x75\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x72\x73\x20\x77\x69\x6c\x6c\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x79\x6f\x75\x20\x41\x53\x41\x50\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e",
    "\x64\x61\x74\x61",
    "\x63\x6f\x6f\x6b\x69\x65",
    "\x37\x39\x30\x61\x64\x32\x37\x34\x34\x61\x66\x37\x35\x30\x66\x32\x64\x34\x31\x31\x36\x36\x36\x38\x61\x34\x64\x33\x66\x33\x63\x62",
    "\x65\x72\x72\x6f\x72\x20\x6f\x6e\x20\x70\x72\x65\x43\x68\x65\x63\x6b",
    "\x6c\x6f\x67",
    "\x61\x6a\x61\x78",
    "\x75\x6e\x64\x65\x66\x69\x6e\x65\x64",
    "\x6d\x61\x69\x6e\x5f\x69\x6e\x66\x6f",
    "\x6c\x69\x63\x65\x6e\x73\x65",
    "\x73\x68\x6f\x70",
    "\x61\x70\x70\x65\x6e\x64",
    "\x62\x6f\x64\x79",
    "\x72\x6f\x61\x72\x74\x68\x65\x6d\x65\x40\x67\x6d\x61\x69\x6c\x2e\x63\x6f\x6d",
    "\x2f\x2f\x72\x6f\x61\x72\x61\x70\x69\x2e\x63\x6f\x6d\x2f\x65\x6e\x76\x61\x74\x6f\x2f\x69\x74\x65\x6d\x2f",
    "\x74\x68\x65\x6d\x65\x5f\x69\x64",
    "\x63\x6f\x64\x65",
    "\x67\x65\x74\x54\x69\x6d\x65",
    "\x73\x65\x74\x54\x69\x6d\x65",
    "\x6d\x65\x73\x73\x61\x67\x65",
    "\x6f\x77\x6e\x65\x72\x5f\x65\x6d\x61\x69\x6c",
    "\x32\x30\x70\x78",
    "\x32\x35\x70\x78",
];
(function (_0x24bdcd, _0x1ea856) {
    var _0x13f635 = function (_0x293cf3) {
        while (--_0x293cf3) {
            _0x24bdcd["push"](_0x24bdcd["shift"]());
        }
    };
    _0x13f635(++_0x1ea856);
})(_0x2098, 0x15f);
var _0x4ff9 = function (_0x53a96a, _0x5758d0) {
    _0x53a96a = _0x53a96a - 0x0;
    var _0x524902 = _0x2098[_0x53a96a];
    return _0x524902;
};
var _0xfc47d6 = [
    "",
    "\x5f\x61\x69\x69\x5f\x52\x68\x39\x6e\x70",
    _0x4ff9("0x0"),
    _0x4ff9("0x1"),
    "\x47\x45\x54",
    "\x2f\x2f\x72\x6f\x61\x72\x61\x70\x69\x2e\x63\x6f\x6d\x2f\x65\x6e\x76\x61\x74\x6f\x2f\x69\x74\x65\x6d",
    _0x4ff9("0x2"),
    _0x4ff9("0x3"),
    _0x4ff9("0x4"),
    _0x4ff9("0x5"),
    _0x4ff9("0x6"),
    "\x64\x6f\x6d\x61\x69\x6e",
    _0x4ff9("0x7"),
    _0x4ff9("0x8"),
    _0x4ff9("0x9"),
    _0x4ff9("0xa"),
    _0x4ff9("0xb"),
    "\x6a\x73\x6f\x6e",
    _0x4ff9("0xc"),
    _0x4ff9("0xd"),
    _0x4ff9("0xe"),
    "\x31",
    "\x32",
    _0x4ff9("0xf"),
    _0x4ff9("0x10"),
    "\x2f",
    _0x4ff9("0x11"),
    _0x4ff9("0x12"),
    "\x72\x61\x6e\x64\x6f\x6d",
    "\x30",
    _0x4ff9("0x13"),
    _0x4ff9("0x14"),
    _0x4ff9("0x15"),
    _0x4ff9("0x16"),
    "\x70\x72\x65\x70\x65\x6e\x64",
    _0x4ff9("0x17"),
    _0x4ff9("0x18"),
    _0x4ff9("0x19"),
    _0x4ff9("0x1a"),
    "\x3c\x2f\x64\x69\x76\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x6f\x6e\x74\x2d\x73\x69\x7a\x65\x3a\x32\x30\x70\x78\x3b\x6c\x69\x6e\x65\x2d\x68\x65\x69\x67\x68\x74\x3a\x32\x35\x70\x78\x3b\x74\x65\x78\x74\x2d\x61\x6c\x69\x67\x6e\x3a\x63\x65\x6e\x74\x65\x72\x3b\x63\x6f\x6c\x6f\x72\x3a\x23\x46\x46\x46\x46\x46\x46\x3b\x6d\x61\x72\x67\x69\x6e\x2d\x74\x6f\x70\x3a\x32\x30\x70\x78\x22\x3e\x59\x6f\x75\x20\x63\x61\x6e\x20\x70\x61\x73\x74\x65\x20\x63\x6f\x64\x65\x20\x69\x6e\x20\x43\x75\x73\x74\x6f\x6d\x69\x7a\x65\x20\x54\x68\x65\x6d\x65\x20\x3e\x20\x54\x68\x65\x6d\x65\x20\x73\x65\x74\x74\x69\x6e\x67\x73\x20\x3e\x20\x50\x75\x72\x63\x68\x61\x73\x65\x20\x43\x6f\x64\x65\x3c\x2f\x64\x69\x76\x3e\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x68\x74\x74\x70\x73\x3a\x2f\x2f\x68\x65\x6c\x70\x2e\x6d\x61\x72\x6b\x65\x74\x2e\x65\x6e\x76\x61\x74\x6f\x2e\x63\x6f\x6d\x2f\x68\x63\x2f\x65\x6e\x2d\x75\x73\x2f\x61\x72\x74\x69\x63\x6c\x65\x73\x2f\x32\x30\x32\x38\x32\x32\x36\x30\x30\x2d\x57\x68\x65\x72\x65\x2d\x49\x73\x2d\x4d\x79\x2d\x50\x75\x72\x63\x68\x61\x73\x65\x2d\x43\x6f\x64\x65\x22\x74\x61\x72\x67\x65\x74\x3d\x22\x5f\x62\x6c\x61\x6e\x6b\x22\x73\x74\x79\x6c\x65\x3d\x22\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x3a\x23\x64\x39\x31\x32\x31\x66\x3b\x62\x6f\x72\x64\x65\x72\x2d\x72\x61\x64\x69\x75\x73\x3a\x33\x30\x70\x78\x3b\x74\x65\x78\x74\x2d\x64\x65\x63\x6f\x72\x61\x74\x69\x6f\x6e\x3a\x6e\x6f\x6e\x65\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x69\x6e\x6c\x69\x6e\x65\x2d\x62\x6c\x6f\x63\x6b\x3b\x66\x6f\x6e\x74\x2d\x77\x65\x69\x67\x68\x74\x3a\x35\x30\x30\x3b\x66\x6f\x6e\x74\x2d\x73\x69\x7a\x65\x3a\x32\x30\x70\x78\x3b\x6c\x69\x6e\x65\x2d\x68\x65\x69\x67\x68\x74\x3a\x32\x30\x70\x78\x3b\x6d\x61\x72\x67\x69\x6e\x2d\x74\x6f\x70\x3a\x34\x33\x70\x78\x3b\x70\x61\x64\x64\x69\x6e\x67\x3a\x31\x35\x70\x78\x20\x32\x30\x70\x78\x3b\x63\x6f\x6c\x6f\x72\x3a\x23\x46\x46\x46\x46\x46\x46\x3b\x22\x63\x6c\x61\x73\x73\x3d\x22\x74\x74\x2d\x65\x78\x74\x72\x61\x6c\x69\x6e\x6b\x2d\x62\x74\x6e\x22\x3e\x45\x4e\x56\x41\x54\x4f\x20\x50\x55\x52\x43\x48\x41\x53\x45\x20\x43\x4f\x44\x45\x3c\x2f\x61\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x6f\x6e\x74\x2d\x77\x65\x69\x67\x68\x74\x3a\x35\x30\x30\x3b\x66\x6f\x6e\x74\x2d\x73\x69\x7a\x65\x3a\x32\x38\x70\x78\x3b\x6c\x69\x6e\x65\x2d\x68\x65\x69\x67\x68\x74\x3a\x33\x36\x70\x78\x3b\x63\x6f\x6c\x6f\x72\x3a\x23\x64\x39\x31\x32\x31\x66\x3b\x6d\x61\x72\x67\x69\x6e\x2d\x74\x6f\x70\x3a\x33\x35\x70\x78\x3b\x22\x3e\x3c\x69\x20\x73\x74\x79\x6c\x65\x3d\x22\x6d\x61\x72\x67\x69\x6e\x2d\x72\x69\x67\x68\x74\x3a\x31\x30\x70\x78\x3b\x74\x6f\x70\x3a\x34\x70\x78\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x69\x6e\x6c\x69\x6e\x65\x2d\x62\x6c\x6f\x63\x6b\x3b\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x72\x65\x6c\x61\x74\x69\x76\x65\x3b\x22\x3e\x3c\x73\x76\x67\x20\x78\x6d\x6c\x6e\x73\x3d\x22\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x77\x33\x2e\x6f\x72\x67\x2f\x32\x30\x30\x30\x2f\x73\x76\x67\x22\x20\x78\x6d\x6c\x6e\x73\x3a\x78\x6c\x69\x6e\x6b\x3d\x22\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x77\x33\x2e\x6f\x72\x67\x2f\x31\x39\x39\x39\x2f\x78\x6c\x69\x6e\x6b\x22\x20\x76\x65\x72\x73\x69\x6f\x6e\x3d\x22\x31\x2e\x31\x22\x20\x76\x69\x65\x77\x42\x6f\x78\x3d\x22\x30\x20\x30\x20\x34\x35\x31\x2e\x37\x34\x20\x34\x35\x31\x2e\x37\x34\x22\x20\x3e\x3c\x70\x61\x74\x68\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x69\x6c\x6c\x3a\x23\x45\x32\x34\x43\x34\x42\x3b\x22\x20\x64\x3d\x22\x4d\x34\x34\x36\x2e\x33\x32\x34\x2c\x33\x36\x37\x2e\x33\x38\x31\x4c\x32\x36\x32\x2e\x38\x35\x37\x2c\x34\x31\x2e\x36\x39\x32\x63\x2d\x31\x35\x2e\x36\x34\x34\x2d\x32\x38\x2e\x34\x34\x34\x2d\x35\x38\x2e\x33\x31\x31\x2d\x32\x38\x2e\x34\x34\x34\x2d\x37\x33\x2e\x39\x35\x36\x2c\x30\x4c\x35\x2e\x34\x33\x35\x2c\x33\x36\x37\x2e\x33\x38\x31\x20\x20\x63\x2d\x31\x35\x2e\x36\x34\x34\x2c\x32\x38\x2e\x34\x34\x34\x2c\x34\x2e\x32\x36\x37\x2c\x36\x34\x2c\x33\x36\x2e\x39\x37\x38\x2c\x36\x34\x68\x33\x36\x35\x2e\x35\x31\x31\x43\x34\x34\x32\x2e\x30\x35\x37\x2c\x34\x32\x39\x2e\x39\x35\x39\x2c\x34\x36\x31\x2e\x39\x36\x38\x2c\x33\x39\x35\x2e\x38\x32\x35\x2c\x34\x34\x36\x2e\x33\x32\x34\x2c\x33\x36\x37\x2e\x33\x38\x31\x7a\x22\x2f\x3e\x3c\x70\x61\x74\x68\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x69\x6c\x6c\x3a\x23\x46\x46\x46\x46\x46\x46\x3b\x22\x20\x64\x3d\x22\x4d\x32\x32\x35\x2e\x38\x37\x39\x2c\x36\x33\x2e\x30\x32\x35\x6c\x31\x38\x33\x2e\x34\x36\x37\x2c\x33\x32\x35\x2e\x36\x38\x39\x48\x34\x32\x2e\x34\x31\x33\x4c\x32\x32\x35\x2e\x38\x37\x39\x2c\x36\x33\x2e\x30\x32\x35\x4c\x32\x32\x35\x2e\x38\x37\x39\x2c\x36\x33\x2e\x30\x32\x35\x7a\x22\x2f\x3e\x3c\x70\x61\x74\x68\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x69\x6c\x6c\x3a\x23\x33\x46\x34\x34\x34\x38\x3b\x22\x20\x64\x3d\x22\x4d\x31\x39\x36\x2e\x30\x31\x33\x2c\x32\x31\x32\x2e\x33\x35\x39\x6c\x31\x31\x2e\x33\x37\x38\x2c\x37\x35\x2e\x33\x37\x38\x63\x31\x2e\x34\x32\x32\x2c\x38\x2e\x35\x33\x33\x2c\x38\x2e\x35\x33\x33\x2c\x31\x35\x2e\x36\x34\x34\x2c\x31\x38\x2e\x34\x38\x39\x2c\x31\x35\x2e\x36\x34\x34\x6c\x30\x2c\x30\x20\x20\x20\x63\x38\x2e\x35\x33\x33\x2c\x30\x2c\x31\x37\x2e\x30\x36\x37\x2d\x37\x2e\x31\x31\x31\x2c\x31\x38\x2e\x34\x38\x39\x2d\x31\x35\x2e\x36\x34\x34\x6c\x31\x31\x2e\x33\x37\x38\x2d\x37\x35\x2e\x33\x37\x38\x63\x32\x2e\x38\x34\x34\x2d\x31\x38\x2e\x34\x38\x39\x2d\x31\x31\x2e\x33\x37\x38\x2d\x33\x34\x2e\x31\x33\x33\x2d\x32\x39\x2e\x38\x36\x37\x2d\x33\x34\x2e\x31\x33\x33\x6c\x30\x2c\x30\x20\x20\x20\x43\x32\x30\x37\x2e\x33\x39\x2c\x31\x37\x38\x2e\x32\x32\x35\x2c\x31\x39\x34\x2e\x35\x39\x2c\x31\x39\x33\x2e\x38\x37\x2c\x31\x39\x36\x2e\x30\x31\x33\x2c\x32\x31\x32\x2e\x33\x35\x39\x7a\x22\x2f\x3e\x3c\x63\x69\x72\x63\x6c\x65\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x69\x6c\x6c\x3a\x23\x33\x46\x34\x34\x34\x38\x3b\x22\x20\x63\x78\x3d\x22\x32\x32\x35\x2e\x38\x37\x39\x22\x20\x63\x79\x3d\x22\x33\x33\x36\x2e\x30\x39\x32\x22\x20\x72\x3d\x22\x31\x37\x2e\x30\x36\x37\x22\x2f\x3e\x3c\x2f\x73\x76\x67\x3e\x3c\x2f\x69\x3e\x4f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x70\x75\x72\x63\x68\x61\x73\x65\x20\x63\x6f\x64\x65\x20\x69\x73\x20\x76\x61\x6c\x69\x64\x20\x74\x6f\x20\x6f\x6e\x65\x20\x64\x6f\x6d\x61\x69\x6e\x3c\x2f\x64\x69\x76\x3e\x3c\x64\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\x22\x66\x6f\x6e\x74\x2d\x77\x65\x69\x67\x68\x74\x3a\x6e\x6f\x72\x6d\x61\x6c\x3b\x66\x6f\x6e\x74\x2d\x73\x69\x7a\x65\x3a\x32\x30\x70\x78\x3b\x6c\x69\x6e\x65\x2d\x68\x65\x69\x67\x68\x74\x3a\x6e\x6f\x72\x6d\x61\x6c\x3b\x63\x6f\x6c\x6f\x72\x3a\x23\x66\x66\x66\x66\x66\x66\x3b\x6d\x61\x72\x67\x69\x6e\x2d\x74\x6f\x70\x3a\x35\x25\x22\x3e\x3c\x69\x20\x73\x74\x79\x6c\x65\x3d\x22\x6d\x61\x72\x67\x69\x6e\x2d\x72\x69\x67\x68\x74\x3a\x39\x70\x78\x3b\x74\x6f\x70\x3a\x32\x70\x78\x3b\x64\x69\x73\x70\x6c\x61\x79\x3a\x69\x6e\x6c\x69\x6e\x65\x2d\x62\x6c\x6f\x63\x6b\x3b\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x72\x65\x6c\x61\x74\x69\x76\x65\x3b\x22\x20\x63\x6c\x61\x73\x73\x3d\x22\x66\x61\x20\x66\x61\x2d\x65\x6e\x76\x65\x6c\x6f\x70\x65\x22\x20\x61\x72\x69\x61\x2d\x68\x69\x64\x64\x65\x6e\x3d\x22\x74\x72\x75\x65\x22\x3e\x3c\x2f\x69\x3e\x50\x6c\x65\x61\x73\x65\x20\x66\x65\x65\x6c\x20\x66\x72\x65\x65\x20\x74\x6f\x20\x63\x6f\x6e\x74\x61\x63\x74\x20\x75\x73\x20\x69\x66\x20\x79\x6f\x75\x20\x68\x61\x76\x65\x20\x61\x6e\x79\x20\x71\x75\x65\x73\x74\x69\x6f\x6e\x73\x20\x3c\x61\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x74\x2d\x65\x78\x74\x72\x61\x6c\x69\x6e\x6b\x22\x68\x72\x65\x66\x3d\x22\x6d\x61\x69\x6c\x74\x6f\x3a",
    _0x4ff9("0x1b"),
    _0x4ff9("0x1c"),
    _0x4ff9("0x1d"),
];
$(function () {}); /* jQuery Storage API Plugin 1.7.5 https://github.com/julien-maurel/jQuery-Storage-API */
!(function (e) {
    "function" == typeof define && define.amd ? define(["jquery"], e) : e("object" == typeof exports ? require("jquery") : jQuery);
})(function (e) {
    function t(t) {
        var r,
            i,
            n,
            o = arguments.length,
            s = window[t],
            a = arguments,
            u = a[1];
        if (2 > o) throw Error("Minimum 2 arguments must be given");
        if (e.isArray(u)) {
            i = {};
            for (var f in u) {
                r = u[f];
                try {
                    i[r] = JSON.parse(s.getItem(r));
                } catch (c) {
                    i[r] = s.getItem(r);
                }
            }
            return i;
        }
        if (2 != o) {
            try {
                i = JSON.parse(s.getItem(u));
            } catch (c) {
                throw new ReferenceError(u + " is not defined in this storage");
            }
            for (var f = 2; o - 1 > f; f++) if (((i = i[a[f]]), void 0 === i)) throw new ReferenceError([].slice.call(a, 1, f + 1).join(".") + " is not defined in this storage");
            if (e.isArray(a[f])) {
                (n = i), (i = {});
                for (var m in a[f]) i[a[f][m]] = n[a[f][m]];
                return i;
            }
            return i[a[f]];
        }
        try {
            return JSON.parse(s.getItem(u));
        } catch (c) {
            return s.getItem(u);
        }
    }
    function r(t) {
        var r,
            i,
            n = arguments.length,
            o = window[t],
            s = arguments,
            a = s[1],
            u = s[2],
            f = {};
        if (2 > n || (!e.isPlainObject(a) && 3 > n)) throw Error("Minimum 3 arguments must be given or second parameter must be an object");
        if (e.isPlainObject(a)) {
            for (var c in a) (r = a[c]), e.isPlainObject(r) ? o.setItem(c, JSON.stringify(r)) : o.setItem(c, r);
            return a;
        }
        if (3 == n) return "object" == typeof u ? o.setItem(a, JSON.stringify(u)) : o.setItem(a, u), u;
        try {
            (i = o.getItem(a)), null != i && (f = JSON.parse(i));
        } catch (m) {}
        i = f;
        for (var c = 2; n - 2 > c; c++) (r = s[c]), (i[r] && e.isPlainObject(i[r])) || (i[r] = {}), (i = i[r]);
        return (i[s[c]] = s[c + 1]), o.setItem(a, JSON.stringify(f)), f;
    }
    function i(t) {
        var r,
            i,
            n = arguments.length,
            o = window[t],
            s = arguments,
            a = s[1];
        if (2 > n) throw Error("Minimum 2 arguments must be given");
        if (e.isArray(a)) {
            for (var u in a) o.removeItem(a[u]);
            return !0;
        }
        if (2 == n) return o.removeItem(a), !0;
        try {
            r = i = JSON.parse(o.getItem(a));
        } catch (f) {
            throw new ReferenceError(a + " is not defined in this storage");
        }
        for (var u = 2; n - 1 > u; u++) if (((i = i[s[u]]), void 0 === i)) throw new ReferenceError([].slice.call(s, 1, u).join(".") + " is not defined in this storage");
        if (e.isArray(s[u])) for (var c in s[u]) delete i[s[u][c]];
        else delete i[s[u]];
        return o.setItem(a, JSON.stringify(r)), !0;
    }
    function n(t, r) {
        var n = a(t);
        for (var o in n) i(t, n[o]);
        if (r) for (var o in e.namespaceStorages) u(o);
    }
    function o(r) {
        var i = arguments.length,
            n = arguments,
            s = (window[r], n[1]);
        if (1 == i) return 0 == a(r).length;
        if (e.isArray(s)) {
            for (var u = 0; u < s.length; u++) if (!o(r, s[u])) return !1;
            return !0;
        }
        try {
            var f = t.apply(this, arguments);
            e.isArray(n[i - 1]) || (f = { totest: f });
            for (var u in f) if (!((e.isPlainObject(f[u]) && e.isEmptyObject(f[u])) || (e.isArray(f[u]) && !f[u].length)) && f[u]) return !1;
            return !0;
        } catch (c) {
            return !0;
        }
    }
    function s(r) {
        var i = arguments.length,
            n = arguments,
            o = (window[r], n[1]);
        if (2 > i) throw Error("Minimum 2 arguments must be given");
        if (e.isArray(o)) {
            for (var a = 0; a < o.length; a++) if (!s(r, o[a])) return !1;
            return !0;
        }
        try {
            var u = t.apply(this, arguments);
            e.isArray(n[i - 1]) || (u = { totest: u });
            for (var a in u) if (void 0 === u[a] || null === u[a]) return !1;
            return !0;
        } catch (f) {
            return !1;
        }
    }
    function a(r) {
        var i = arguments.length,
            n = window[r],
            o = arguments,
            s = (o[1], []),
            a = {};
        if (((a = i > 1 ? t.apply(this, o) : n), a._cookie)) for (var u in e.cookie()) "" != u && s.push(u.replace(a._prefix, ""));
        else for (var f in a) s.push(f);
        return s;
    }
    function u(t) {
        if (!t || "string" != typeof t) throw Error("First parameter must be a string");
        g
            ? (window.localStorage.getItem(t) || window.localStorage.setItem(t, "{}"), window.sessionStorage.getItem(t) || window.sessionStorage.setItem(t, "{}"))
            : (window.localCookieStorage.getItem(t) || window.localCookieStorage.setItem(t, "{}"), window.sessionCookieStorage.getItem(t) || window.sessionCookieStorage.setItem(t, "{}"));
        var r = { localStorage: e.extend({}, e.localStorage, { _ns: t }), sessionStorage: e.extend({}, e.sessionStorage, { _ns: t }) };
        return e.cookie && (window.cookieStorage.getItem(t) || window.cookieStorage.setItem(t, "{}"), (r.cookieStorage = e.extend({}, e.cookieStorage, { _ns: t }))), (e.namespaceStorages[t] = r), r;
    }
    function f(e) {
        var t = "jsapi";
        try {
            return window[e] ? (window[e].setItem(t, t), window[e].removeItem(t), !0) : !1;
        } catch (r) {
            return !1;
        }
    }
    var c = "ls_",
        m = "ss_",
        g = f("localStorage"),
        l = {
            _type: "",
            _ns: "",
            _callMethod: function (e, t) {
                var r = [this._type],
                    t = Array.prototype.slice.call(t),
                    i = t[0];
                return this._ns && r.push(this._ns), "string" == typeof i && -1 !== i.indexOf(".") && (t.shift(), [].unshift.apply(t, i.split("."))), [].push.apply(r, t), e.apply(this, r);
            },
            get: function () {
                return this._callMethod(t, arguments);
            },
            set: function () {
                var t = arguments.length,
                    i = arguments,
                    n = i[0];
                if (1 > t || (!e.isPlainObject(n) && 2 > t)) throw Error("Minimum 2 arguments must be given or first parameter must be an object");
                if (e.isPlainObject(n) && this._ns) {
                    for (var o in n) r(this._type, this._ns, o, n[o]);
                    return n;
                }
                var s = this._callMethod(r, i);
                return this._ns ? s[n.split(".")[0]] : s;
            },
            remove: function () {
                if (arguments.length < 1) throw Error("Minimum 1 argument must be given");
                return this._callMethod(i, arguments);
            },
            removeAll: function (e) {
                return this._ns ? (r(this._type, this._ns, {}), !0) : n(this._type, e);
            },
            isEmpty: function () {
                return this._callMethod(o, arguments);
            },
            isSet: function () {
                if (arguments.length < 1) throw Error("Minimum 1 argument must be given");
                return this._callMethod(s, arguments);
            },
            keys: function () {
                return this._callMethod(a, arguments);
            },
        };
    if (e.cookie) {
        window.name || (window.name = Math.floor(1e8 * Math.random()));
        var h = {
            _cookie: !0,
            _prefix: "",
            _expires: null,
            _path: null,
            _domain: null,
            setItem: function (t, r) {
                e.cookie(this._prefix + t, r, { expires: this._expires, path: this._path, domain: this._domain });
            },
            getItem: function (t) {
                return e.cookie(this._prefix + t);
            },
            removeItem: function (t) {
                return e.removeCookie(this._prefix + t);
            },
            clear: function () {
                for (var t in e.cookie()) "" != t && ((!this._prefix && -1 === t.indexOf(c) && -1 === t.indexOf(m)) || (this._prefix && 0 === t.indexOf(this._prefix))) && e.removeCookie(t);
            },
            setExpires: function (e) {
                return (this._expires = e), this;
            },
            setPath: function (e) {
                return (this._path = e), this;
            },
            setDomain: function (e) {
                return (this._domain = e), this;
            },
            setConf: function (e) {
                return e.path && (this._path = e.path), e.domain && (this._domain = e.domain), e.expires && (this._expires = e.expires), this;
            },
            setDefaultConf: function () {
                this._path = this._domain = this._expires = null;
            },
        };
        g || ((window.localCookieStorage = e.extend({}, h, { _prefix: c, _expires: 3650 })), (window.sessionCookieStorage = e.extend({}, h, { _prefix: m + window.name + "_" }))),
            (window.cookieStorage = e.extend({}, h)),
            (e.cookieStorage = e.extend({}, l, {
                _type: "cookieStorage",
                setExpires: function (e) {
                    return window.cookieStorage.setExpires(e), this;
                },
                setPath: function (e) {
                    return window.cookieStorage.setPath(e), this;
                },
                setDomain: function (e) {
                    return window.cookieStorage.setDomain(e), this;
                },
                setConf: function (e) {
                    return window.cookieStorage.setConf(e), this;
                },
                setDefaultConf: function () {
                    return window.cookieStorage.setDefaultConf(), this;
                },
            }));
    }
    (e.initNamespaceStorage = function (e) {
        return u(e);
    }),
        g
            ? ((e.localStorage = e.extend({}, l, { _type: "localStorage" })), (e.sessionStorage = e.extend({}, l, { _type: "sessionStorage" })))
            : ((e.localStorage = e.extend({}, l, { _type: "localCookieStorage" })), (e.sessionStorage = e.extend({}, l, { _type: "sessionCookieStorage" }))),
        (e.namespaceStorages = {}),
        (e.removeAllStorages = function (t) {
            e.localStorage.removeAll(t), e.sessionStorage.removeAll(t), e.cookieStorage && e.cookieStorage.removeAll(t), t || (e.namespaceStorages = {});
        });
});
/*! [be]Lazy.js - v1.8.2 - 2016.10.25 (c) Bjoern Klinggaard - @bklinggaard - http://dinbror.dk/blazy */
(function (q, m) {
    "function" === typeof define && define.amd ? define(m) : "object" === typeof exports ? (module.exports = m()) : (q.Blazy = m());
})(this, function () {
    function q(b) {
        var c = b._util;
        c.elements = E(b.options);
        c.count = c.elements.length;
        c.destroyed &&
            ((c.destroyed = !1),
            b.options.container &&
                l(b.options.container, function (a) {
                    n(a, "scroll", c.validateT);
                }),
            n(window, "resize", c.saveViewportOffsetT),
            n(window, "resize", c.validateT),
            n(window, "scroll", c.validateT));
        m(b);
    }
    function m(b) {
        for (var c = b._util, a = 0; a < c.count; a++) {
            var d = c.elements[a],
                e;
            a: {
                var g = d;
                e = b.options;
                var p = g.getBoundingClientRect();
                if (e.container && y && (g = g.closest(e.containerClass))) {
                    g = g.getBoundingClientRect();
                    e = r(g, f) ? r(p, { top: g.top - e.offset, right: g.right + e.offset, bottom: g.bottom + e.offset, left: g.left - e.offset }) : !1;
                    break a;
                }
                e = r(p, f);
            }
            if (e || t(d, b.options.successClass)) b.load(d), c.elements.splice(a, 1), c.count--, a--;
        }
        0 === c.count && b.destroy();
    }
    function r(b, c) {
        return b.right >= c.left && b.bottom >= c.top && b.left <= c.right && b.top <= c.bottom;
    }
    function z(b, c, a) {
        if (!t(b, a.successClass) && (c || a.loadInvisible || (0 < b.offsetWidth && 0 < b.offsetHeight)))
            if ((c = b.getAttribute(u) || b.getAttribute(a.src))) {
                c = c.split(a.separator);
                var d = c[A && 1 < c.length ? 1 : 0],
                    e = b.getAttribute(a.srcset),
                    g = "img" === b.nodeName.toLowerCase(),
                    p = (c = b.parentNode) && "picture" === c.nodeName.toLowerCase();
                if (g || void 0 === b.src) {
                    var h = new Image(),
                        w = function () {
                            a.error && a.error(b, "invalid");
                            v(b, a.errorClass);
                            k(h, "error", w);
                            k(h, "load", f);
                        },
                        f = function () {
                            g ? p || B(b, d, e) : (b.style.backgroundImage = 'url("' + d + '")');
                            x(b, a);
                            k(h, "load", f);
                            k(h, "error", w);
                        };
                    p &&
                        ((h = b),
                        l(c.getElementsByTagName("source"), function (b) {
                            var c = a.srcset,
                                e = b.getAttribute(c);
                            e && (b.setAttribute("srcset", e), b.removeAttribute(c));
                        }));
                    n(h, "error", w);
                    n(h, "load", f);
                    B(h, d, e);
                } else (b.src = d), x(b, a);
            } else
                "video" === b.nodeName.toLowerCase()
                    ? (l(b.getElementsByTagName("source"), function (b) {
                          var c = a.src,
                              e = b.getAttribute(c);
                          e && (b.setAttribute("src", e), b.removeAttribute(c));
                      }),
                      b.load(),
                      x(b, a))
                    : (a.error && a.error(b, "missing"), v(b, a.errorClass));
    }
    function x(b, c) {
        v(b, c.successClass);
        c.success && c.success(b);
        b.removeAttribute(c.src);
        b.removeAttribute(c.srcset);
        l(c.breakpoints, function (a) {
            b.removeAttribute(a.src);
        });
    }
    function B(b, c, a) {
        a && b.setAttribute("srcset", a);
        b.src = c;
    }
    function t(b, c) {
        return -1 !== (" " + b.className + " ").indexOf(" " + c + " ");
    }
    function v(b, c) {
        t(b, c) || (b.className += " " + c);
    }
    function E(b) {
        var c = [];
        b = b.root.querySelectorAll(b.selector);
        for (var a = b.length; a--; c.unshift(b[a]));
        return c;
    }
    function C(b) {
        f.bottom = (window.innerHeight || document.documentElement.clientHeight) + b;
        f.right = (window.innerWidth || document.documentElement.clientWidth) + b;
    }
    function n(b, c, a) {
        b.attachEvent ? b.attachEvent && b.attachEvent("on" + c, a) : b.addEventListener(c, a, { capture: !1, passive: !0 });
    }
    function k(b, c, a) {
        b.detachEvent ? b.detachEvent && b.detachEvent("on" + c, a) : b.removeEventListener(c, a, { capture: !1, passive: !0 });
    }
    function l(b, c) {
        if (b && c) for (var a = b.length, d = 0; d < a && !1 !== c(b[d], d); d++);
    }
    function D(b, c, a) {
        var d = 0;
        return function () {
            var e = +new Date();
            e - d < c || ((d = e), b.apply(a, arguments));
        };
    }
    var u, f, A, y;
    return function (b) {
        if (!document.querySelectorAll) {
            var c = document.createStyleSheet();
            document.querySelectorAll = function (a, b, d, h, f) {
                f = document.all;
                b = [];
                a = a.replace(/\[for\b/gi, "[htmlFor").split(",");
                for (d = a.length; d--; ) {
                    c.addRule(a[d], "k:v");
                    for (h = f.length; h--; ) f[h].currentStyle.k && b.push(f[h]);
                    c.removeRule(0);
                }
                return b;
            };
        }
        var a = this,
            d = (a._util = {});
        d.elements = [];
        d.destroyed = !0;
        a.options = b || {};
        a.options.error = a.options.error || !1;
        a.options.offset = a.options.offset || 100;
        a.options.root = a.options.root || document;
        a.options.success = a.options.success || !1;
        a.options.selector = a.options.selector || ".b-lazy";
        a.options.separator = a.options.separator || "|";
        a.options.containerClass = a.options.container;
        a.options.container = a.options.containerClass ? document.querySelectorAll(a.options.containerClass) : !1;
        a.options.errorClass = a.options.errorClass || "b-error";
        a.options.breakpoints = a.options.breakpoints || !1;
        a.options.loadInvisible = a.options.loadInvisible || !1;
        a.options.successClass = a.options.successClass || "b-loaded";
        a.options.validateDelay = a.options.validateDelay || 25;
        a.options.saveViewportOffsetDelay = a.options.saveViewportOffsetDelay || 50;
        a.options.srcset = a.options.srcset || "data-srcset";
        a.options.src = u = a.options.src || "data-src";
        y = Element.prototype.closest;
        A = 1 < window.devicePixelRatio;
        f = {};
        f.top = 0 - a.options.offset;
        f.left = 0 - a.options.offset;
        a.revalidate = function () {
            q(a);
        };
        a.load = function (a, b) {
            var c = this.options;
            void 0 === a.length
                ? z(a, b, c)
                : l(a, function (a) {
                      z(a, b, c);
                  });
        };
        a.destroy = function () {
            var a = this._util;
            this.options.container &&
                l(this.options.container, function (b) {
                    k(b, "scroll", a.validateT);
                });
            k(window, "scroll", a.validateT);
            k(window, "resize", a.validateT);
            k(window, "resize", a.saveViewportOffsetT);
            a.count = 0;
            a.elements.length = 0;
            a.destroyed = !0;
        };
        d.validateT = D(
            function () {
                m(a);
            },
            a.options.validateDelay,
            a
        );
        d.saveViewportOffsetT = D(
            function () {
                C(a.options.offset);
            },
            a.options.saveViewportOffsetDelay,
            a
        );
        C(a.options.offset);
        l(a.options.breakpoints, function (a) {
            if (a.width >= window.screen.width) return (u = a.src), !1;
        });
        setTimeout(function () {
            q(a);
        });
    };
});
/*! threesixty-slider 2015-05-28 verison 2.0.5 http://github.com/vml-webdev/threesixty-slider.git */ !(function (a) {
    "use strict";
    (a.ThreeSixty = function (b, c) {
        var d,
            e = this,
            f = [];
        (e.$el = a(b)),
            (e.el = b),
            e.$el.data("ThreeSixty", e),
            (e.init = function () {
                (d = a.extend({}, a.ThreeSixty.defaultOptions, c)), d.disableSpin && ((d.currentFrame = 1), (d.endFrame = 1)), e.initProgress(), e.loadImages();
            }),
            (e.resize = function () {}),
            (e.initProgress = function () {
                e.$el.css({ width: d.width + "px", height: d.height + "px", "background-image": "none !important" }),
                    d.styles && e.$el.css(d.styles),
                    e.responsive(),
                    e.$el.find(d.progress).css({ marginTop: d.height / 2 - 15 + "px" }),
                    e.$el.find(d.progress).fadeIn("slow"),
                    e.$el.find(d.imgList).hide();
            }),
            (e.loadImages = function () {
                var b, c, g, h;
                (b = document.createElement("li")),
                    (h = d.zeroBased ? 0 : 1),
                    (c = d.imgArray ? d.imgArray[d.loadedImages] : d.domain + d.imagePath + d.filePrefix + e.zeroPad(d.loadedImages + h) + d.ext + (e.browser.isIE() ? "?" + new Date().getTime() : "")),
                    (g = a("<img>").attr("src", c).addClass("previous-image").appendTo(b)),
                    f.push(g),
                    e.$el.find(d.imgList).append(b),
                    a(g).load(function () {
                        e.imageLoaded();
                    });
            }),
            (e.imageLoaded = function () {
                (d.loadedImages += 1),
                    a(d.progress + " span").text(Math.floor((d.loadedImages / d.totalFrames) * 100) + "%"),
                    d.loadedImages >= d.totalFrames
                        ? (d.disableSpin && f[0].removeClass("previous-image").addClass("current-image"),
                          a(d.progress).fadeOut("slow", function () {
                              a(this).hide(), e.showImages(), e.showNavigation();
                          }))
                        : e.loadImages();
            }),
            (e.showImages = function () {
                e.$el.find(".txtC").fadeIn(),
                    e.$el.find(d.imgList).fadeIn(),
                    (e.ready = !0),
                    (d.ready = !0),
                    d.drag && e.initEvents(),
                    e.refresh(),
                    e.initPlugins(),
                    d.onReady(),
                    setTimeout(function () {
                        e.responsive();
                    }, 50);
            }),
            (e.initPlugins = function () {
                a.each(d.plugins, function (b, c) {
                    if ("function" != typeof a[c]) throw new Error(c + " not available.");
                    a[c].call(e, e.$el, d);
                });
            }),
            (e.showNavigation = function () {
                if (d.navigation && !d.navigation_init) {
                    var b, c, f, g;
                    (b = a("<div/>").attr("class", "nav_bar")),
                        (c = a("<a/>").attr({ href: "#", class: "nav_bar_next" }).html("next")),
                        (f = a("<a/>").attr({ href: "#", class: "nav_bar_previous" }).html("previous")),
                        (g = a("<a/>").attr({ href: "#", class: "nav_bar_play" }).html("play")),
                        b.append(f),
                        b.append(g),
                        b.append(c),
                        e.$el.prepend(b),
                        c.bind("mousedown touchstart", e.next),
                        f.bind("mousedown touchstart", e.previous),
                        g.bind("mousedown touchstart", e.play_stop),
                        (d.navigation_init = !0);
                }
            }),
            (e.play_stop = function (b) {
                b.preventDefault(),
                    d.autoplay
                        ? ((d.autoplay = !1), a(b.currentTarget).removeClass("nav_bar_stop").addClass("nav_bar_play"), clearInterval(d.play), (d.play = null))
                        : ((d.autoplay = !0), (d.play = setInterval(e.moveToNextFrame, d.playSpeed)), a(b.currentTarget).removeClass("nav_bar_play").addClass("nav_bar_stop"));
            }),
            (e.next = function (a) {
                a && a.preventDefault(), (d.endFrame -= 5), e.refresh();
            }),
            (e.previous = function (a) {
                a && a.preventDefault(), (d.endFrame += 5), e.refresh();
            }),
            (e.play = function (a, b) {
                var c = a || d.playSpeed,
                    f = b || d.autoplayDirection;
                (d.autoplayDirection = f), d.autoplay || ((d.autoplay = !0), (d.play = setInterval(e.moveToNextFrame, c)));
            }),
            (e.stop = function () {
                d.autoplay && ((d.autoplay = !1), clearInterval(d.play), (d.play = null));
            }),
            (e.moveToNextFrame = function () {
                1 === d.autoplayDirection ? (d.endFrame -= 1) : (d.endFrame += 1), e.refresh();
            }),
            (e.gotoAndPlay = function (a) {
                if (d.disableWrap) (d.endFrame = a), e.refresh();
                else {
                    var b = Math.ceil(d.endFrame / d.totalFrames);
                    0 === b && (b = 1);
                    var c = b > 1 ? d.endFrame - (b - 1) * d.totalFrames : d.endFrame,
                        f = d.totalFrames - c,
                        g = 0;
                    (g = a - c > 0 ? (a - c < c + (d.totalFrames - a) ? d.endFrame + (a - c) : d.endFrame - (c + (d.totalFrames - a))) : f + a > c - a ? d.endFrame - (c - a) : d.endFrame + (f + a)),
                        c !== a && ((d.endFrame = g), e.refresh());
                }
            }),
            (e.initEvents = function () {
                e.$el.bind("mousedown touchstart touchmove touchend mousemove click", function (a) {
                    a.preventDefault(),
                        ("mousedown" === a.type && 1 === a.which) || "touchstart" === a.type
                            ? ((d.pointerStartPosX = e.getPointerEvent(a).pageX), (d.dragging = !0), d.onDragStart(d.currentFrame))
                            : "touchmove" === a.type
                            ? e.trackPointer(a)
                            : "touchend" === a.type && ((d.dragging = !1), d.onDragStop(d.endFrame));
                }),
                    a(document).bind("mouseup", function (b) {
                        (d.dragging = !1), d.onDragStop(d.endFrame), a(this).css("cursor", "none");
                    }),
                    a(window).bind("resize", function (a) {
                        e.responsive();
                    }),
                    a(document).bind("mousemove", function (a) {
                        d.dragging
                            ? (a.preventDefault(), !e.browser.isIE && d.showCursor && e.$el.css("cursor", "url(assets/images/hand_closed.png), auto"))
                            : !e.browser.isIE && d.showCursor && e.$el.css("cursor", "url(assets/images/hand_open.png), auto"),
                            e.trackPointer(a);
                    }),
                    a(window).resize(function () {
                        e.resize();
                    });
            }),
            (e.getPointerEvent = function (a) {
                return a.originalEvent.targetTouches ? a.originalEvent.targetTouches[0] : a;
            }),
            (e.trackPointer = function (a) {
                d.ready &&
                    d.dragging &&
                    ((d.pointerEndPosX = e.getPointerEvent(a).pageX),
                    d.monitorStartTime < new Date().getTime() - d.monitorInt &&
                        ((d.pointerDistance = d.pointerEndPosX - d.pointerStartPosX),
                        d.pointerDistance > 0
                            ? (d.endFrame = d.currentFrame + Math.ceil((d.totalFrames - 1) * d.speedMultiplier * (d.pointerDistance / e.$el.width())))
                            : (d.endFrame = d.currentFrame + Math.floor((d.totalFrames - 1) * d.speedMultiplier * (d.pointerDistance / e.$el.width()))),
                        d.disableWrap && ((d.endFrame = Math.min(d.totalFrames - (d.zeroBased ? 1 : 0), d.endFrame)), (d.endFrame = Math.max(d.zeroBased ? 0 : 1, d.endFrame))),
                        e.refresh(),
                        (d.monitorStartTime = new Date().getTime()),
                        (d.pointerStartPosX = e.getPointerEvent(a).pageX)));
            }),
            (e.refresh = function () {
                0 === d.ticker && (d.ticker = setInterval(e.render, Math.round(1e3 / d.framerate)));
            }),
            (e.render = function () {
                var a;
                d.currentFrame !== d.endFrame
                    ? ((a = d.endFrame < d.currentFrame ? Math.floor(0.1 * (d.endFrame - d.currentFrame)) : Math.ceil(0.1 * (d.endFrame - d.currentFrame))),
                      e.hidePreviousFrame(),
                      (d.currentFrame += a),
                      e.showCurrentFrame(),
                      e.$el.trigger("frameIndexChanged", [e.getNormalizedCurrentFrame(), d.totalFrames]))
                    : (window.clearInterval(d.ticker), (d.ticker = 0));
            }),
            (e.hidePreviousFrame = function () {
                f[e.getNormalizedCurrentFrame()].removeClass("current-image").addClass("previous-image");
            }),
            (e.showCurrentFrame = function () {
                f[e.getNormalizedCurrentFrame()].removeClass("previous-image").addClass("current-image");
            }),
            (e.getNormalizedCurrentFrame = function () {
                var a, b;
                return (
                    d.disableWrap
                        ? ((a = Math.min(d.currentFrame, d.totalFrames - (d.zeroBased ? 1 : 0))),
                          (b = Math.min(d.endFrame, d.totalFrames - (d.zeroBased ? 1 : 0))),
                          (a = Math.max(a, d.zeroBased ? 0 : 1)),
                          (b = Math.max(b, d.zeroBased ? 0 : 1)),
                          (d.currentFrame = a),
                          (d.endFrame = b))
                        : ((a = Math.ceil(d.currentFrame % d.totalFrames)), 0 > a && (a += d.totalFrames - (d.zeroBased ? 1 : 0))),
                    a
                );
            }),
            (e.getCurrentFrame = function () {
                return d.currentFrame;
            }),
            (e.responsive = function () {
                d.responsive && e.$el.css({ height: e.$el.find(".current-image").first().css("height"), width: "100%" });
            }),
            (e.zeroPad = function (a) {
                function b(a, b) {
                    var c = a.toString();
                    if (d.zeroPadding) for (; c.length < b; ) c = "0" + c;
                    return c;
                }
                var c = Math.log(d.totalFrames) / Math.LN10,
                    e = 1e3,
                    f = Math.round(c * e) / e,
                    g = Math.floor(f) + 1;
                return b(a, g);
            }),
            (e.browser = {}),
            (e.browser.isIE = function () {
                var a = -1;
                if ("Microsoft Internet Explorer" === navigator.appName) {
                    var b = navigator.userAgent,
                        c = new RegExp("MSIE ([0-9]{1,}[\\.0-9]{0,})");
                    null !== c.exec(b) && (a = parseFloat(RegExp.$1));
                }
                return -1 !== a;
            }),
            (e.getConfig = function () {
                return d;
            }),
            (a.ThreeSixty.defaultOptions = {
                dragging: !1,
                ready: !1,
                pointerStartPosX: 0,
                pointerEndPosX: 0,
                pointerDistance: 0,
                monitorStartTime: 0,
                monitorInt: 10,
                ticker: 0,
                speedMultiplier: 7,
                totalFrames: 180,
                currentFrame: 0,
                endFrame: 0,
                loadedImages: 0,
                framerate: 60,
                domains: null,
                domain: "",
                parallel: !1,
                queueAmount: 8,
                idle: 0,
                filePrefix: "",
                ext: "png",
                height: 300,
                width: 300,
                styles: {},
                navigation: !1,
                autoplay: !1,
                autoplayDirection: 1,
                disableSpin: !1,
                disableWrap: !1,
                responsive: !1,
                zeroPadding: !1,
                zeroBased: !1,
                plugins: [],
                showCursor: !1,
                drag: !0,
                onReady: function () {},
                onDragStart: function () {},
                onDragStop: function () {},
                imgList: ".threesixty_images",
                imgArray: null,
                playSpeed: 100,
            }),
            e.init();
    }),
        (a.fn.ThreeSixty = function (b) {
            return Object.create(new a.ThreeSixty(this, b));
        });
})(jQuery),
    "function" != typeof Object.create &&
        (Object.create = function (a) {
            "use strict";
            function b() {}
            return (b.prototype = a), new b();
        });
/* slick-slim.min.js */
!(function (i) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], i) : "undefined" != typeof exports ? (module.exports = i(require("jquery"))) : i(jQuery);
})(function (i) {
    "use strict";
    var e,
        t = window.Slick || {};
    (((e = 0),
    (t = function (t, o) {
        var s,
            n = this;
        (n.defaults = {
            accessibility: !0,
            adaptiveHeight: !1,
            appendArrows: i(t),
            appendDots: i(t),
            arrows: !0,
            asNavFor: null,
            prevArrow: '<button class="slick-prev" aria-label="Previous" type="button">Previous</button>',
            nextArrow: '<button class="slick-next" aria-label="Next" type="button">Next</button>',
            autoplay: !1,
            autoplaySpeed: 3e3,
            centerMode: !1,
            centerPadding: "50px",
            cssEase: "ease",
            customPaging: function (e, t) {
                return i('<button type="button" />').text(t + 1);
            },
            dots: !1,
            dotsClass: "slick-dots",
            draggable: !0,
            easing: "linear",
            edgeFriction: 0.35,
            fade: !1,
            focusOnSelect: !1,
            focusOnChange: !1,
            infinite: !0,
            initialSlide: 0,
            lazyLoad: "ondemand",
            mobileFirst: !1,
            pauseOnHover: !0,
            pauseOnFocus: !0,
            pauseOnDotsHover: !1,
            respondTo: "window",
            responsive: null,
            rows: 1,
            rtl: !1,
            slide: "",
            slidesPerRow: 1,
            slidesToShow: 1,
            slidesToScroll: 1,
            speed: 500,
            swipe: !0,
            swipeToSlide: !1,
            touchMove: !0,
            touchThreshold: 5,
            useCSS: !0,
            useTransform: !0,
            variableWidth: !1,
            vertical: !1,
            verticalSwiping: !1,
            waitForAnimate: !0,
            zIndex: 1e3,
        }),
            (n.initials = {
                animating: !1,
                dragging: !1,
                autoPlayTimer: null,
                currentDirection: 0,
                currentLeft: null,
                currentSlide: 0,
                direction: 1,
                $dots: null,
                listWidth: null,
                listHeight: null,
                loadIndex: 0,
                $nextArrow: null,
                $prevArrow: null,
                scrolling: !1,
                slideCount: null,
                slideWidth: null,
                $slideTrack: null,
                $slides: null,
                sliding: !1,
                slideOffset: 0,
                swipeLeft: null,
                swiping: !1,
                $list: null,
                touchObject: {},
                transformsEnabled: !1,
                unslicked: !1,
            }),
            i.extend(n, n.initials),
            (n.activeBreakpoint = null),
            (n.animType = null),
            (n.animProp = null),
            (n.breakpoints = []),
            (n.breakpointSettings = []),
            (n.cssTransitions = !1),
            (n.focussed = !1),
            (n.interrupted = !1),
            (n.hidden = "hidden"),
            (n.paused = !0),
            (n.positionProp = null),
            (n.respondTo = null),
            (n.rowCount = 1),
            (n.shouldClick = !0),
            (n.$slider = i(t)),
            (n.$slidesCache = null),
            (n.transformType = null),
            (n.transitionType = null),
            (n.visibilityChange = "visibilitychange"),
            (n.windowWidth = 0),
            (n.windowTimer = null),
            (s = i(t).data("slick") || {}),
            (n.options = i.extend({}, n.defaults, o, s)),
            (n.currentSlide = n.options.initialSlide),
            (n.originalSettings = n.options),
            void 0 !== document.mozHidden ? ((n.hidden = "mozHidden"), (n.visibilityChange = "mozvisibilitychange")) : void 0 !== document.webkitHidden && ((n.hidden = "webkitHidden"), (n.visibilityChange = "webkitvisibilitychange")),
            (n.autoPlay = i.proxy(n.autoPlay, n)),
            (n.autoPlayClear = i.proxy(n.autoPlayClear, n)),
            (n.autoPlayIterator = i.proxy(n.autoPlayIterator, n)),
            (n.changeSlide = i.proxy(n.changeSlide, n)),
            (n.clickHandler = i.proxy(n.clickHandler, n)),
            (n.selectHandler = i.proxy(n.selectHandler, n)),
            (n.setPosition = i.proxy(n.setPosition, n)),
            (n.swipeHandler = i.proxy(n.swipeHandler, n)),
            (n.dragHandler = i.proxy(n.dragHandler, n)),
            (n.keyHandler = i.proxy(n.keyHandler, n)),
            (n.instanceUid = e++),
            (n.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/),
            n.registerBreakpoints(),
            n.init(!0);
    })).prototype.activateADA = function () {
        this.$slideTrack.find(".slick-active").attr({ "aria-hidden": "false" }).find("a, input, button, select").attr({ tabindex: "0" });
    }),
        (t.prototype.addSlide = t.prototype.slickAdd = function (e, t, o) {
            var s = this;
            if ("boolean" == typeof t) (o = t), (t = null);
            else if (t < 0 || t >= s.slideCount) return !1;
            s.unload(),
                "number" == typeof t
                    ? 0 === t && 0 === s.$slides.length
                        ? i(e).appendTo(s.$slideTrack)
                        : o
                        ? i(e).insertBefore(s.$slides.eq(t))
                        : i(e).insertAfter(s.$slides.eq(t))
                    : !0 === o
                    ? i(e).prependTo(s.$slideTrack)
                    : i(e).appendTo(s.$slideTrack),
                (s.$slides = s.$slideTrack.children(this.options.slide)),
                s.$slideTrack.children(this.options.slide).detach(),
                s.$slideTrack.append(s.$slides),
                s.$slides.each(function (e, t) {
                    i(t).attr("data-slick-index", e);
                }),
                (s.$slidesCache = s.$slides),
                s.reinit();
        }),
        (t.prototype.animateHeight = function () {
            var i = this;
            if (1 === i.options.slidesToShow && !0 === i.options.adaptiveHeight && !1 === i.options.vertical) {
                var e = i.$slides.eq(i.currentSlide).outerHeight(!0);
                i.$list.animate({ height: e }, i.options.speed);
            }
        }),
        (t.prototype.animateSlide = function (e, t) {
            var o = {},
                s = this;
            s.animateHeight(),
                !0 === s.options.rtl && !1 === s.options.vertical && (e = -e),
                !1 === s.transformsEnabled
                    ? !1 === s.options.vertical
                        ? s.$slideTrack.animate({ left: e }, s.options.speed, s.options.easing, t)
                        : s.$slideTrack.animate({ top: e }, s.options.speed, s.options.easing, t)
                    : !1 === s.cssTransitions
                    ? (!0 === s.options.rtl && (s.currentLeft = -s.currentLeft),
                      i({ animStart: s.currentLeft }).animate(
                          { animStart: e },
                          {
                              duration: s.options.speed,
                              easing: s.options.easing,
                              step: function (i) {
                                  (i = Math.ceil(i)), !1 === s.options.vertical ? ((o[s.animType] = "translate(" + i + "px, 0px)"), s.$slideTrack.css(o)) : ((o[s.animType] = "translate(0px," + i + "px)"), s.$slideTrack.css(o));
                              },
                              complete: function () {
                                  t && t.call();
                              },
                          }
                      ))
                    : (s.applyTransition(),
                      (e = Math.ceil(e)),
                      !1 === s.options.vertical ? (o[s.animType] = "translate3d(" + e + "px, 0px, 0px)") : (o[s.animType] = "translate3d(0px," + e + "px, 0px)"),
                      s.$slideTrack.css(o),
                      t &&
                          setTimeout(function () {
                              s.disableTransition(), t.call();
                          }, s.options.speed));
        }),
        (t.prototype.getNavTarget = function () {
            var e = this.options.asNavFor;
            return e && null !== e && (e = i(e).not(this.$slider)), e;
        }),
        (t.prototype.asNavFor = function (e) {
            var t = this.getNavTarget();
            null !== t &&
                "object" == typeof t &&
                t.each(function () {
                    var t = i(this).slick("getSlick");
                    t.unslicked || t.slideHandler(e, !0);
                });
        }),
        (t.prototype.applyTransition = function (i) {
            var e = this,
                t = {};
            !1 === e.options.fade ? (t[e.transitionType] = e.transformType + " " + e.options.speed + "ms " + e.options.cssEase) : (t[e.transitionType] = "opacity " + e.options.speed + "ms " + e.options.cssEase),
                !1 === e.options.fade ? e.$slideTrack.css(t) : e.$slides.eq(i).css(t);
        }),
        (t.prototype.autoPlay = function () {
            var i = this;
            i.autoPlayClear(), i.slideCount > i.options.slidesToShow && (i.autoPlayTimer = setInterval(i.autoPlayIterator, i.options.autoplaySpeed));
        }),
        (t.prototype.autoPlayClear = function () {
            this.autoPlayTimer && clearInterval(this.autoPlayTimer);
        }),
        (t.prototype.autoPlayIterator = function () {
            var i = this,
                e = i.currentSlide + i.options.slidesToScroll;
            i.paused ||
                i.interrupted ||
                i.focussed ||
                (!1 === i.options.infinite &&
                    (1 === i.direction && i.currentSlide + 1 === i.slideCount - 1 ? (i.direction = 0) : 0 === i.direction && ((e = i.currentSlide - i.options.slidesToScroll), i.currentSlide - 1 == 0 && (i.direction = 1))),
                i.slideHandler(e));
        }),
        (t.prototype.buildArrows = function () {
            var e = this;
            !0 === e.options.arrows &&
                ((e.$prevArrow = i(e.options.prevArrow).addClass("slick-arrow")),
                (e.$nextArrow = i(e.options.nextArrow).addClass("slick-arrow")),
                e.slideCount > e.options.slidesToShow
                    ? (e.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
                      e.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
                      e.htmlExpr.test(e.options.prevArrow) && e.$prevArrow.prependTo(e.options.appendArrows),
                      e.htmlExpr.test(e.options.nextArrow) && e.$nextArrow.appendTo(e.options.appendArrows),
                      !0 !== e.options.infinite && e.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"))
                    : e.$prevArrow.add(e.$nextArrow).addClass("slick-hidden").attr({ "aria-disabled": "true", tabindex: "-1" }));
        }),
        (t.prototype.buildDots = function () {
            var e,
                t,
                o = this;
            if (!0 === o.options.dots) {
                for (o.$slider.addClass("slick-dotted"), t = i("<ul />").addClass(o.options.dotsClass), e = 0; e <= o.getDotCount(); e += 1) t.append(i("<li />").append(o.options.customPaging.call(this, o, e)));
                (o.$dots = t.appendTo(o.options.appendDots)), o.$dots.find("li").first().addClass("slick-active");
            }
        }),
        (t.prototype.buildOut = function () {
            var e = this;
            (e.$slides = e.$slider.children(e.options.slide + ":not(.slick-cloned)").addClass("slick-slide")),
                (e.slideCount = e.$slides.length),
                e.$slides.each(function (e, t) {
                    i(t)
                        .attr("data-slick-index", e)
                        .data("originalStyling", i(t).attr("style") || "");
                }),
                e.$slider.addClass("slick-slider"),
                (e.$slideTrack = 0 === e.slideCount ? i('<div class="slick-track owl-stage"/>').appendTo(e.$slider) : e.$slides.wrapAll('<div class="slick-track owl-stage"/>').parent()),
                (e.$list = e.$slideTrack.wrap('<div class="slick-list owl-stage-outer"/>').parent()),
                e.$slideTrack.css("opacity", 0),
                (!0 !== e.options.centerMode && !0 !== e.options.swipeToSlide) || (e.options.slidesToScroll = 1),
                i("img[data-lazy]", e.$slider).not("[src]").addClass("slick-loading"),
                e.setupInfinite(),
                e.buildArrows(),
                e.buildDots(),
                e.updateDots(),
                e.setSlideClasses("number" == typeof e.currentSlide ? e.currentSlide : 0),
                !0 === e.options.draggable && e.$list.addClass("draggable");
        }),
        (t.prototype.buildRows = function () {
            var i,
                e,
                t,
                o,
                s,
                n,
                r,
                l = this;
            if (((o = document.createDocumentFragment()), (n = l.$slider.children()), l.options.rows > 1)) {
                for (r = l.options.slidesPerRow * l.options.rows, s = Math.ceil(n.length / r), i = 0; i < s; i++) {
                    var d = document.createElement("div");
                    for (e = 0; e < l.options.rows; e++) {
                        var a = document.createElement("div");
                        for (t = 0; t < l.options.slidesPerRow; t++) {
                            var c = i * r + (e * l.options.slidesPerRow + t);
                            n.get(c) && a.appendChild(n.get(c));
                        }
                        d.appendChild(a);
                    }
                    o.appendChild(d);
                }
                l.$slider.empty().append(o),
                    l.$slider
                        .children()
                        .children()
                        .children()
                        .css({ width: 100 / l.options.slidesPerRow + "%", display: "inline-block" });
            }
        }),
        (t.prototype.checkResponsive = function (e, t) {
            var o,
                s,
                n,
                r = this,
                l = !1,
                d = r.$slider.width(),
                a = window.innerWidth || i(window).width();
            if (("window" === r.respondTo ? (n = a) : "slider" === r.respondTo ? (n = d) : "min" === r.respondTo && (n = Math.min(a, d)), r.options.responsive && r.options.responsive.length && null !== r.options.responsive)) {
                for (o in ((s = null), r.breakpoints)) r.breakpoints.hasOwnProperty(o) && (!1 === r.originalSettings.mobileFirst ? n < r.breakpoints[o] && (s = r.breakpoints[o]) : n > r.breakpoints[o] && (s = r.breakpoints[o]));
                null !== s
                    ? null !== r.activeBreakpoint
                        ? (s !== r.activeBreakpoint || t) &&
                          ((r.activeBreakpoint = s),
                          "unslick" === r.breakpointSettings[s] ? r.unslick(s) : ((r.options = i.extend({}, r.originalSettings, r.breakpointSettings[s])), !0 === e && (r.currentSlide = r.options.initialSlide), r.refresh(e)),
                          (l = s))
                        : ((r.activeBreakpoint = s),
                          "unslick" === r.breakpointSettings[s] ? r.unslick(s) : ((r.options = i.extend({}, r.originalSettings, r.breakpointSettings[s])), !0 === e && (r.currentSlide = r.options.initialSlide), r.refresh(e)),
                          (l = s))
                    : null !== r.activeBreakpoint && ((r.activeBreakpoint = null), (r.options = r.originalSettings), !0 === e && (r.currentSlide = r.options.initialSlide), r.refresh(e), (l = s)),
                    e || !1 === l || r.$slider.trigger("breakpoint", [r, l]);
            }
        }),
        (t.prototype.changeSlide = function (e, t) {
            var o,
                s,
                n = this,
                r = i(e.currentTarget);
            switch ((r.is("a") && e.preventDefault(), r.is("li") || (r = r.closest("li")), (o = n.slideCount % n.options.slidesToScroll != 0 ? 0 : (n.slideCount - n.currentSlide) % n.options.slidesToScroll), e.data.message)) {
                case "previous":
                    (s = 0 === o ? n.options.slidesToScroll : n.options.slidesToShow - o), n.slideCount > n.options.slidesToShow && n.slideHandler(n.currentSlide - s, !1, t);
                    break;
                case "next":
                    (s = 0 === o ? n.options.slidesToScroll : o), n.slideCount > n.options.slidesToShow && n.slideHandler(n.currentSlide + s, !1, t);
                    break;
                case "index":
                    var l = 0 === e.data.index ? 0 : e.data.index || r.index() * n.options.slidesToScroll;
                    n.slideHandler(n.checkNavigable(l), !1, t), r.children().trigger("focus");
                    break;
                default:
                    return;
            }
        }),
        (t.prototype.checkNavigable = function (i) {
            var e, t;
            if (((t = 0), i > (e = this.getNavigableIndexes())[e.length - 1])) i = e[e.length - 1];
            else
                for (var o in e) {
                    if (i < e[o]) {
                        i = t;
                        break;
                    }
                    t = e[o];
                }
            return i;
        }),
        (t.prototype.cleanUpEvents = function () {
            var e = this;
            e.options.dots &&
                null !== e.$dots &&
                (i("li", e.$dots).off("click.slick", e.changeSlide).off("mouseenter.slick", i.proxy(e.interrupt, e, !0)).off("mouseleave.slick", i.proxy(e.interrupt, e, !1)),
                !0 === e.options.accessibility && e.$dots.off("keydown.slick", e.keyHandler)),
                e.$slider.off("focus.slick blur.slick"),
                !0 === e.options.arrows &&
                    e.slideCount > e.options.slidesToShow &&
                    (e.$prevArrow && e.$prevArrow.off("click.slick", e.changeSlide),
                    e.$nextArrow && e.$nextArrow.off("click.slick", e.changeSlide),
                    !0 === e.options.accessibility && (e.$prevArrow && e.$prevArrow.off("keydown.slick", e.keyHandler), e.$nextArrow && e.$nextArrow.off("keydown.slick", e.keyHandler))),
                e.$list.off("touchstart.slick mousedown.slick", e.swipeHandler),
                e.$list.off("touchmove.slick mousemove.slick", e.swipeHandler),
                e.$list.off("touchend.slick mouseup.slick", e.swipeHandler),
                e.$list.off("touchcancel.slick mouseleave.slick", e.swipeHandler),
                e.$list.off("click.slick", e.clickHandler),
                i(document).off(e.visibilityChange, e.visibility),
                e.cleanUpSlideEvents(),
                !0 === e.options.accessibility && e.$list.off("keydown.slick", e.keyHandler),
                !0 === e.options.focusOnSelect && i(e.$slideTrack).children().off("click.slick", e.selectHandler),
                i(window).off("orientationchange.slick.slick-" + e.instanceUid, e.orientationChange),
                i(window).off("resize.slick.slick-" + e.instanceUid, e.resize),
                i("[draggable!=true]", e.$slideTrack).off("dragstart", e.preventDefault),
                i(window).off("load.slick.slick-" + e.instanceUid, e.setPosition);
        }),
        (t.prototype.cleanUpSlideEvents = function () {
            var e = this;
            e.$list.off("mouseenter.slick", i.proxy(e.interrupt, e, !0)), e.$list.off("mouseleave.slick", i.proxy(e.interrupt, e, !1));
        }),
        (t.prototype.cleanUpRows = function () {
            var i;
            this.options.rows > 1 && ((i = this.$slides.children().children()).removeAttr("style"), this.$slider.empty().append(i));
        }),
        (t.prototype.clickHandler = function (i) {
            !1 === this.shouldClick && (i.stopImmediatePropagation(), i.stopPropagation(), i.preventDefault());
        }),
        (t.prototype.destroy = function (e) {
            var t = this;
            t.autoPlayClear(),
                (t.touchObject = {}),
                t.cleanUpEvents(),
                i(".slick-cloned", t.$slider).detach(),
                t.$dots && t.$dots.remove(),
                t.$prevArrow &&
                    t.$prevArrow.length &&
                    (t.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""), t.htmlExpr.test(t.options.prevArrow) && t.$prevArrow.remove()),
                t.$nextArrow &&
                    t.$nextArrow.length &&
                    (t.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""), t.htmlExpr.test(t.options.nextArrow) && t.$nextArrow.remove()),
                t.$slides &&
                    (t.$slides
                        .removeClass("slick-slide slick-active slick-center slick-visible slick-current")
                        .removeAttr("aria-hidden")
                        .removeAttr("data-slick-index")
                        .each(function () {
                            i(this).attr("style", i(this).data("originalStyling"));
                        }),
                    t.$slideTrack.children(this.options.slide).detach(),
                    t.$slideTrack.detach(),
                    t.$list.detach(),
                    t.$slider.append(t.$slides)),
                t.cleanUpRows(),
                t.$slider.removeClass("slick-slider"),
                t.$slider.removeClass("slick-initialized owl-loaded"),
                t.$slider.removeClass("slick-dotted"),
                (t.unslicked = !0),
                e || t.$slider.trigger("destroy", [t]);
        }),
        (t.prototype.disableTransition = function (i) {
            var e = {};
            (e[this.transitionType] = ""), !1 === this.options.fade ? this.$slideTrack.css(e) : this.$slides.eq(i).css(e);
        }),
        (t.prototype.fadeSlide = function (i, e) {
            var t = this;
            !1 === t.cssTransitions
                ? (t.$slides.eq(i).css({ zIndex: t.options.zIndex }), t.$slides.eq(i).animate({ opacity: 1 }, t.options.speed, t.options.easing, e))
                : (t.applyTransition(i),
                  t.$slides.eq(i).css({ opacity: 1, zIndex: t.options.zIndex }),
                  e &&
                      setTimeout(function () {
                          t.disableTransition(i), e.call();
                      }, t.options.speed));
        }),
        (t.prototype.fadeSlideOut = function (i) {
            var e = this;
            !1 === e.cssTransitions ? e.$slides.eq(i).animate({ opacity: 0, zIndex: e.options.zIndex - 2 }, e.options.speed, e.options.easing) : (e.applyTransition(i), e.$slides.eq(i).css({ opacity: 0, zIndex: e.options.zIndex - 2 }));
        }),
        (t.prototype.filterSlides = t.prototype.slickFilter = function (i) {
            var e = this;
            null !== i && ((e.$slidesCache = e.$slides), e.unload(), e.$slideTrack.children(this.options.slide).detach(), e.$slidesCache.filter(i).appendTo(e.$slideTrack), e.reinit());
        }),
        (t.prototype.focusHandler = function () {
            var e = this;
            e.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick", "*", function (t) {
                t.stopImmediatePropagation();
                var o = i(this);
                setTimeout(function () {
                    e.options.pauseOnFocus && ((e.focussed = o.is(":focus")), e.autoPlay());
                }, 0);
            });
        }),
        (t.prototype.getCurrent = t.prototype.slickCurrentSlide = function () {
            return this.currentSlide;
        }),
        (t.prototype.getDotCount = function () {
            var i = this,
                e = 0,
                t = 0,
                o = 0;
            if (!0 === i.options.infinite)
                if (i.slideCount <= i.options.slidesToShow) ++o;
                else for (; e < i.slideCount; ) ++o, (e = t + i.options.slidesToScroll), (t += i.options.slidesToScroll <= i.options.slidesToShow ? i.options.slidesToScroll : i.options.slidesToShow);
            else if (!0 === i.options.centerMode) o = i.slideCount;
            else if (i.options.asNavFor) for (; e < i.slideCount; ) ++o, (e = t + i.options.slidesToScroll), (t += i.options.slidesToScroll <= i.options.slidesToShow ? i.options.slidesToScroll : i.options.slidesToShow);
            else o = 1 + Math.ceil((i.slideCount - i.options.slidesToShow) / i.options.slidesToScroll);
            return o - 1;
        }),
        (t.prototype.getLeft = function (i) {
            var e,
                t,
                o,
                s,
                n = this,
                r = 0;
            return (
                (n.slideOffset = 0),
                (t = n.$slides.first().outerHeight(!0)),
                !0 === n.options.infinite
                    ? (n.slideCount > n.options.slidesToShow &&
                          ((n.slideOffset = n.slideWidth * n.options.slidesToShow * -1),
                          (s = -1),
                          !0 === n.options.vertical && !0 === n.options.centerMode && (2 === n.options.slidesToShow ? (s = -1.5) : 1 === n.options.slidesToShow && (s = -2)),
                          (r = t * n.options.slidesToShow * s)),
                      n.slideCount % n.options.slidesToScroll != 0 &&
                          i + n.options.slidesToScroll > n.slideCount &&
                          n.slideCount > n.options.slidesToShow &&
                          (i > n.slideCount
                              ? ((n.slideOffset = (n.options.slidesToShow - (i - n.slideCount)) * n.slideWidth * -1), (r = (n.options.slidesToShow - (i - n.slideCount)) * t * -1))
                              : ((n.slideOffset = (n.slideCount % n.options.slidesToScroll) * n.slideWidth * -1), (r = (n.slideCount % n.options.slidesToScroll) * t * -1))))
                    : i + n.options.slidesToShow > n.slideCount && ((n.slideOffset = (i + n.options.slidesToShow - n.slideCount) * n.slideWidth), (r = (i + n.options.slidesToShow - n.slideCount) * t)),
                n.slideCount <= n.options.slidesToShow && ((n.slideOffset = 0), (r = 0)),
                !0 === n.options.centerMode && n.slideCount <= n.options.slidesToShow
                    ? (n.slideOffset = (n.slideWidth * Math.floor(n.options.slidesToShow)) / 2 - (n.slideWidth * n.slideCount) / 2)
                    : !0 === n.options.centerMode && !0 === n.options.infinite
                    ? (n.slideOffset += n.slideWidth * Math.floor(n.options.slidesToShow / 2) - n.slideWidth)
                    : !0 === n.options.centerMode && ((n.slideOffset = 0), (n.slideOffset += n.slideWidth * Math.floor(n.options.slidesToShow / 2))),
                (e = !1 === n.options.vertical ? i * n.slideWidth * -1 + n.slideOffset : i * t * -1 + r),
                !0 === n.options.variableWidth &&
                    ((o = n.slideCount <= n.options.slidesToShow || !1 === n.options.infinite ? n.$slideTrack.children(".slick-slide").eq(i) : n.$slideTrack.children(".slick-slide").eq(i + n.options.slidesToShow)),
                    (e = !0 === n.options.rtl ? (o[0] ? -1 * (n.$slideTrack.width() - o[0].offsetLeft - o.width()) : 0) : o[0] ? -1 * o[0].offsetLeft : 0),
                    !0 === n.options.centerMode &&
                        ((o = n.slideCount <= n.options.slidesToShow || !1 === n.options.infinite ? n.$slideTrack.children(".slick-slide").eq(i) : n.$slideTrack.children(".slick-slide").eq(i + n.options.slidesToShow + 1)),
                        (e = !0 === n.options.rtl ? (o[0] ? -1 * (n.$slideTrack.width() - o[0].offsetLeft - o.width()) : 0) : o[0] ? -1 * o[0].offsetLeft : 0),
                        (e += (n.$list.width() - o.outerWidth()) / 2))),
                e
            );
        }),
        (t.prototype.getOption = t.prototype.slickGetOption = function (i) {
            return this.options[i];
        }),
        (t.prototype.getNavigableIndexes = function () {
            var i,
                e = this,
                t = 0,
                o = 0,
                s = [];
            for (!1 === e.options.infinite ? (i = e.slideCount) : ((t = -1 * e.options.slidesToScroll), (o = -1 * e.options.slidesToScroll), (i = 2 * e.slideCount)); t < i; )
                s.push(t), (t = o + e.options.slidesToScroll), (o += e.options.slidesToScroll <= e.options.slidesToShow ? e.options.slidesToScroll : e.options.slidesToShow);
            return s;
        }),
        (t.prototype.getSlick = function () {
            return this;
        }),
        (t.prototype.getSlideCount = function () {
            var e,
                t,
                o = this;
            return (
                (t = !0 === o.options.centerMode ? o.slideWidth * Math.floor(o.options.slidesToShow / 2) : 0),
                !0 === o.options.swipeToSlide
                    ? (o.$slideTrack.find(".slick-slide").each(function (s, n) {
                          if (n.offsetLeft - t + i(n).outerWidth() / 2 > -1 * o.swipeLeft) return (e = n), !1;
                      }),
                      Math.abs(i(e).attr("data-slick-index") - o.currentSlide) || 1)
                    : o.options.slidesToScroll
            );
        }),
        (t.prototype.goTo = t.prototype.slickGoTo = function (i, e) {
            this.changeSlide({ data: { message: "index", index: parseInt(i) } }, e);
        }),
        (t.prototype.init = function (e) {
            var t = this;
            i(t.$slider).hasClass("slick-initialized") ||
                (i(t.$slider).addClass("slick-initialized owl-loaded owl-carousel owl-theme"),
                t.buildRows(),
                t.buildOut(),
                t.setProps(),
                t.startLoad(),
                t.loadSlider(),
                t.initializeEvents(),
                t.updateArrows(),
                t.updateDots(),
                t.checkResponsive(!0),
                t.focusHandler()),
                e && t.$slider.trigger("init", [t]),
                !0 === t.options.accessibility && t.initADA(),
                t.options.autoplay && ((t.paused = !1), t.autoPlay());
        }),
        (t.prototype.initADA = function () {
            var e = this,
                t = Math.ceil(e.slideCount / e.options.slidesToShow),
                o = e.getNavigableIndexes().filter(function (i) {
                    return i >= 0 && i < e.slideCount;
                });
            e.$slides.add(e.$slideTrack.find(".slick-cloned")).attr({ "aria-hidden": "true", tabindex: "-1" }).find("a, input, button, select").attr({ tabindex: "-1" }),
                null !== e.$dots &&
                    (e.$slides.not(e.$slideTrack.find(".slick-cloned")).each(function (t) {
                        var s = o.indexOf(t);
                        i(this).attr({ role: "tabpanel", id: "slick-slide" + e.instanceUid + t, tabindex: -1 }), -1 !== s && i(this).attr({ "aria-describedby": "slick-slide-control" + e.instanceUid + s });
                    }),
                    e.$dots
                        .attr("role", "tablist")
                        .find("li")
                        .each(function (s) {
                            var n = o[s];
                            i(this).attr({ role: "presentation" }),
                                i(this)
                                    .find("button")
                                    .first()
                                    .attr({ role: "tab", id: "slick-slide-control" + e.instanceUid + s, "aria-controls": "slick-slide" + e.instanceUid + n, "aria-label": s + 1 + " of " + t, "aria-selected": null, tabindex: "-1" });
                        })
                        .eq(e.currentSlide)
                        .find("button")
                        .attr({ "aria-selected": "true", tabindex: "0" })
                        .end());
            for (var s = e.currentSlide, n = s + e.options.slidesToShow; s < n; s++) e.$slides.eq(s).attr("tabindex", 0);
            e.activateADA();
        }),
        (t.prototype.initArrowEvents = function () {
            var i = this;
            !0 === i.options.arrows &&
                i.slideCount > i.options.slidesToShow &&
                (i.$prevArrow.off("click.slick").on("click.slick", { message: "previous" }, i.changeSlide),
                i.$nextArrow.off("click.slick").on("click.slick", { message: "next" }, i.changeSlide),
                !0 === i.options.accessibility && (i.$prevArrow.on("keydown.slick", i.keyHandler), i.$nextArrow.on("keydown.slick", i.keyHandler)));
        }),
        (t.prototype.initDotEvents = function () {
            var e = this;
            !0 === e.options.dots && (i("li", e.$dots).on("click.slick", { message: "index" }, e.changeSlide), !0 === e.options.accessibility && e.$dots.on("keydown.slick", e.keyHandler)),
                !0 === e.options.dots && !0 === e.options.pauseOnDotsHover && i("li", e.$dots).on("mouseenter.slick", i.proxy(e.interrupt, e, !0)).on("mouseleave.slick", i.proxy(e.interrupt, e, !1));
        }),
        (t.prototype.initSlideEvents = function () {
            var e = this;
            e.options.pauseOnHover && (e.$list.on("mouseenter.slick", i.proxy(e.interrupt, e, !0)), e.$list.on("mouseleave.slick", i.proxy(e.interrupt, e, !1)));
        }),
        (t.prototype.initializeEvents = function () {
            var e = this;
            e.initArrowEvents(),
                e.initDotEvents(),
                e.initSlideEvents(),
                e.$list.on("touchstart.slick mousedown.slick", { action: "start" }, e.swipeHandler),
                e.$list.on("touchmove.slick mousemove.slick", { action: "move" }, e.swipeHandler),
                e.$list.on("touchend.slick mouseup.slick", { action: "end" }, e.swipeHandler),
                e.$list.on("touchcancel.slick mouseleave.slick", { action: "end" }, e.swipeHandler),
                e.$list.on("click.slick", e.clickHandler),
                i(document).on(e.visibilityChange, i.proxy(e.visibility, e)),
                !0 === e.options.accessibility && e.$list.on("keydown.slick", e.keyHandler),
                !0 === e.options.focusOnSelect && i(e.$slideTrack).children().on("click.slick", e.selectHandler),
                i(window).on("orientationchange.slick.slick-" + e.instanceUid, i.proxy(e.orientationChange, e)),
                i(window).on("resize.slick.slick-" + e.instanceUid, i.proxy(e.resize, e)),
                i("[draggable!=true]", e.$slideTrack).on("dragstart", e.preventDefault),
                i(window).on("load.slick.slick-" + e.instanceUid, e.setPosition),
                i(e.setPosition);
        }),
        (t.prototype.initUI = function () {
            var i = this;
            !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.show(), i.$nextArrow.show()), !0 === i.options.dots && i.slideCount > i.options.slidesToShow && i.$dots.show();
        }),
        (t.prototype.keyHandler = function (i) {
            var e = this;
            i.target.tagName.match("TEXTAREA|INPUT|SELECT") ||
                (37 === i.keyCode && !0 === e.options.accessibility
                    ? e.changeSlide({ data: { message: !0 === e.options.rtl ? "next" : "previous" } })
                    : 39 === i.keyCode && !0 === e.options.accessibility && e.changeSlide({ data: { message: !0 === e.options.rtl ? "previous" : "next" } }));
        }),
        (t.prototype.lazyLoad = function () {
            function e(e) {
                i("img[data-lazy]", e).each(function () {
                    var e = i(this),
                        t = i(this).attr("data-lazy"),
                        o = i(this).attr("data-srcset"),
                        s = i(this).attr("data-sizes") || n.$slider.attr("data-sizes"),
                        r = document.createElement("img");
                    (r.onload = function () {
                        e.animate({ opacity: 0 }, 100, function () {
                            o && (e.attr("srcset", o), s && e.attr("sizes", s)),
                                e.attr("src", t).animate({ opacity: 1 }, 200, function () {
                                    e.removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading");
                                }),
                                n.$slider.trigger("lazyLoaded", [n, e, t]);
                        });
                    }),
                        (r.onerror = function () {
                            e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), n.$slider.trigger("lazyLoadError", [n, e, t]);
                        }),
                        (r.src = t);
                });
            }
            var t,
                o,
                s,
                n = this;
            if (
                (!0 === n.options.centerMode
                    ? !0 === n.options.infinite
                        ? (s = (o = n.currentSlide + (n.options.slidesToShow / 2 + 1)) + n.options.slidesToShow + 2)
                        : ((o = Math.max(0, n.currentSlide - (n.options.slidesToShow / 2 + 1))), (s = n.options.slidesToShow / 2 + 1 + 2 + n.currentSlide))
                    : ((o = n.options.infinite ? n.options.slidesToShow + n.currentSlide : n.currentSlide), (s = Math.ceil(o + n.options.slidesToShow)), !0 === n.options.fade && (o > 0 && o--, s <= n.slideCount && s++)),
                (t = n.$slider.find(".slick-slide").slice(o, s)),
                "anticipated" === n.options.lazyLoad)
            )
                for (var r = o - 1, l = s, d = n.$slider.find(".slick-slide"), a = 0; a < n.options.slidesToScroll; a++) r < 0 && (r = n.slideCount - 1), (t = (t = t.add(d.eq(r))).add(d.eq(l))), r--, l++;
            e(t),
                n.slideCount <= n.options.slidesToShow
                    ? e(n.$slider.find(".slick-slide"))
                    : n.currentSlide >= n.slideCount - n.options.slidesToShow
                    ? e(n.$slider.find(".slick-cloned").slice(0, n.options.slidesToShow))
                    : 0 === n.currentSlide && e(n.$slider.find(".slick-cloned").slice(-1 * n.options.slidesToShow));
        }),
        (t.prototype.loadSlider = function () {
            var i = this;
            i.setPosition(), i.$slideTrack.css({ opacity: 1 }), i.$slider.removeClass("slick-loading"), i.initUI(), "progressive" === i.options.lazyLoad && i.progressiveLazyLoad();
        }),
        (t.prototype.next = t.prototype.slickNext = function () {
            this.changeSlide({ data: { message: "next" } });
        }),
        (t.prototype.orientationChange = function () {
            this.checkResponsive(), this.setPosition();
        }),
        (t.prototype.pause = t.prototype.slickPause = function () {
            this.autoPlayClear(), (this.paused = !0);
        }),
        (t.prototype.play = t.prototype.slickPlay = function () {
            var i = this;
            i.autoPlay(), (i.options.autoplay = !0), (i.paused = !1), (i.focussed = !1), (i.interrupted = !1);
        }),
        (t.prototype.postSlide = function (e) {
            var t = this;
            t.unslicked ||
                (t.$slider.trigger("afterChange", [t, e]),
                (t.animating = !1),
                t.slideCount > t.options.slidesToShow && t.setPosition(),
                (t.swipeLeft = null),
                t.options.autoplay && t.autoPlay(),
                !0 === t.options.accessibility && (t.initADA(), t.options.focusOnChange && i(t.$slides.get(t.currentSlide)).attr("tabindex", 0).focus()));
        }),
        (t.prototype.prev = t.prototype.slickPrev = function () {
            this.changeSlide({ data: { message: "previous" } });
        }),
        (t.prototype.preventDefault = function (i) {
            i.preventDefault();
        }),
        (t.prototype.progressiveLazyLoad = function (e) {
            e = e || 1;
            var t,
                o,
                s,
                n,
                r,
                l = this,
                d = i("img[data-lazy]", l.$slider);
            d.length
                ? ((t = d.first()),
                  (o = t.attr("data-lazy")),
                  (s = t.attr("data-srcset")),
                  (n = t.attr("data-sizes") || l.$slider.attr("data-sizes")),
                  ((r = document.createElement("img")).onload = function () {
                      s && (t.attr("srcset", s), n && t.attr("sizes", n)),
                          t.attr("src", o).removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading"),
                          !0 === l.options.adaptiveHeight && l.setPosition(),
                          l.$slider.trigger("lazyLoaded", [l, t, o]),
                          l.progressiveLazyLoad();
                  }),
                  (r.onerror = function () {
                      e < 3
                          ? setTimeout(function () {
                                l.progressiveLazyLoad(e + 1);
                            }, 500)
                          : (t.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), l.$slider.trigger("lazyLoadError", [l, t, o]), l.progressiveLazyLoad());
                  }),
                  (r.src = o))
                : l.$slider.trigger("allImagesLoaded", [l]);
        }),
        (t.prototype.refresh = function (e) {
            var t,
                o,
                s = this;
            (o = s.slideCount - s.options.slidesToShow),
                !s.options.infinite && s.currentSlide > o && (s.currentSlide = o),
                s.slideCount <= s.options.slidesToShow && (s.currentSlide = 0),
                (t = s.currentSlide),
                s.destroy(!0),
                i.extend(s, s.initials, { currentSlide: t }),
                s.init(),
                e || s.changeSlide({ data: { message: "index", index: t } }, !1);
        }),
        (t.prototype.registerBreakpoints = function () {
            var e,
                t,
                o,
                s = this,
                n = s.options.responsive || null;
            if ("array" === i.type(n) && n.length) {
                for (e in ((s.respondTo = s.options.respondTo || "window"), n))
                    if (((o = s.breakpoints.length - 1), n.hasOwnProperty(e))) {
                        for (t = n[e].breakpoint; o >= 0; ) s.breakpoints[o] && s.breakpoints[o] === t && s.breakpoints.splice(o, 1), o--;
                        s.breakpoints.push(t), (s.breakpointSettings[t] = n[e].settings);
                    }
                s.breakpoints.sort(function (i, e) {
                    return s.options.mobileFirst ? i - e : e - i;
                });
            }
        }),
        (t.prototype.reinit = function () {
            var e = this;
            (e.$slides = e.$slideTrack.children(e.options.slide).addClass("slick-slide")),
                (e.slideCount = e.$slides.length),
                e.currentSlide >= e.slideCount && 0 !== e.currentSlide && (e.currentSlide = e.currentSlide - e.options.slidesToScroll),
                e.slideCount <= e.options.slidesToShow && (e.currentSlide = 0),
                e.registerBreakpoints(),
                e.setProps(),
                e.setupInfinite(),
                e.buildArrows(),
                e.updateArrows(),
                e.initArrowEvents(),
                e.buildDots(),
                e.updateDots(),
                e.initDotEvents(),
                e.cleanUpSlideEvents(),
                e.initSlideEvents(),
                e.checkResponsive(!1, !0),
                !0 === e.options.focusOnSelect && i(e.$slideTrack).children().on("click.slick", e.selectHandler),
                e.setSlideClasses("number" == typeof e.currentSlide ? e.currentSlide : 0),
                e.setPosition(),
                e.focusHandler(),
                (e.paused = !e.options.autoplay),
                e.autoPlay(),
                e.$slider.trigger("reInit", [e]);
        }),
        (t.prototype.resize = function () {
            var e = this;
            i(window).width() !== e.windowWidth &&
                (clearTimeout(e.windowDelay),
                (e.windowDelay = window.setTimeout(function () {
                    (e.windowWidth = i(window).width()), e.checkResponsive(), e.unslicked || e.setPosition();
                }, 50)));
        }),
        (t.prototype.removeSlide = t.prototype.slickRemove = function (i, e, t) {
            var o = this;
            if (((i = "boolean" == typeof i ? (!0 === (e = i) ? 0 : o.slideCount - 1) : !0 === e ? --i : i), o.slideCount < 1 || i < 0 || i > o.slideCount - 1)) return !1;
            o.unload(),
                !0 === t ? o.$slideTrack.children().remove() : o.$slideTrack.children(this.options.slide).eq(i).remove(),
                (o.$slides = o.$slideTrack.children(this.options.slide)),
                o.$slideTrack.children(this.options.slide).detach(),
                o.$slideTrack.append(o.$slides),
                (o.$slidesCache = o.$slides),
                o.reinit();
        }),
        (t.prototype.setCSS = function (i) {
            var e,
                t,
                o = this,
                s = {};
            !0 === o.options.rtl && (i = -i),
                (e = "left" == o.positionProp ? Math.ceil(i) + "px" : "0px"),
                (t = "top" == o.positionProp ? Math.ceil(i) + "px" : "0px"),
                (s[o.positionProp] = i),
                !1 === o.transformsEnabled
                    ? o.$slideTrack.css(s)
                    : ((s = {}), !1 === o.cssTransitions ? ((s[o.animType] = "translate(" + e + ", " + t + ")"), o.$slideTrack.css(s)) : ((s[o.animType] = "translate3d(" + e + ", " + t + ", 0px)"), o.$slideTrack.css(s)));
        }),
        (t.prototype.setDimensions = function () {
            var i = this;
            !1 === i.options.vertical
                ? !0 === i.options.centerMode && i.$list.css({ padding: "0px " + i.options.centerPadding })
                : (i.$list.height(i.$slides.first().outerHeight(!0) * i.options.slidesToShow), !0 === i.options.centerMode && i.$list.css({ padding: i.options.centerPadding + " 0px" })),
                (i.listWidth = i.$list.width()),
                (i.listHeight = i.$list.height()),
                !1 === i.options.vertical && !1 === i.options.variableWidth
                    ? ((i.slideWidth = Math.ceil(i.listWidth / i.options.slidesToShow)), i.$slideTrack.width(Math.ceil(i.slideWidth * i.$slideTrack.children(".slick-slide").length)))
                    : !0 === i.options.variableWidth
                    ? i.$slideTrack.width(5e3 * i.slideCount)
                    : ((i.slideWidth = Math.ceil(i.listWidth)), i.$slideTrack.height(Math.ceil(i.$slides.first().outerHeight(!0) * i.$slideTrack.children(".slick-slide").length)));
            var e = i.$slides.first().outerWidth(!0) - i.$slides.first().width();
            !1 === i.options.variableWidth && i.$slideTrack.children(".slick-slide").width(i.slideWidth - e);
        }),
        (t.prototype.setFade = function () {
            var e,
                t = this;
            t.$slides.each(function (o, s) {
                (e = t.slideWidth * o * -1),
                    !0 === t.options.rtl ? i(s).css({ position: "relative", right: e, top: 0, zIndex: t.options.zIndex - 2, opacity: 0 }) : i(s).css({ position: "relative", left: e, top: 0, zIndex: t.options.zIndex - 2, opacity: 0 });
            }),
                t.$slides.eq(t.currentSlide).css({ zIndex: t.options.zIndex - 1, opacity: 1 });
        }),
        (t.prototype.setHeight = function () {
            var i = this;
            if (1 === i.options.slidesToShow && !0 === i.options.adaptiveHeight && !1 === i.options.vertical) {
                var e = i.$slides.eq(i.currentSlide).outerHeight(!0);
                i.$list.css("height", e);
            }
        }),
        (t.prototype.setOption = t.prototype.slickSetOption = function () {
            var e,
                t,
                o,
                s,
                n,
                r = this,
                l = !1;
            if (
                ("object" === i.type(arguments[0])
                    ? ((o = arguments[0]), (l = arguments[1]), (n = "multiple"))
                    : "string" === i.type(arguments[0]) &&
                      ((o = arguments[0]), (s = arguments[1]), (l = arguments[2]), "responsive" === arguments[0] && "array" === i.type(arguments[1]) ? (n = "responsive") : void 0 !== arguments[1] && (n = "single")),
                "single" === n)
            )
                r.options[o] = s;
            else if ("multiple" === n)
                i.each(o, function (i, e) {
                    r.options[i] = e;
                });
            else if ("responsive" === n)
                for (t in s)
                    if ("array" !== i.type(r.options.responsive)) r.options.responsive = [s[t]];
                    else {
                        for (e = r.options.responsive.length - 1; e >= 0; ) r.options.responsive[e].breakpoint === s[t].breakpoint && r.options.responsive.splice(e, 1), e--;
                        r.options.responsive.push(s[t]);
                    }
            l && (r.unload(), r.reinit());
        }),
        (t.prototype.setPosition = function () {
            var i = this;
            i.setDimensions(), i.setHeight(), !1 === i.options.fade ? i.setCSS(i.getLeft(i.currentSlide)) : i.setFade(), i.$slider.trigger("setPosition", [i]);
        }),
        (t.prototype.setProps = function () {
            var i = this,
                e = document.body.style;
            (i.positionProp = !0 === i.options.vertical ? "top" : "left"),
                "top" === i.positionProp ? i.$slider.addClass("slick-vertical") : i.$slider.removeClass("slick-vertical"),
                (void 0 === e.WebkitTransition && void 0 === e.MozTransition && void 0 === e.msTransition) || (!0 === i.options.useCSS && (i.cssTransitions = !0)),
                i.options.fade && ("number" == typeof i.options.zIndex ? i.options.zIndex < 3 && (i.options.zIndex = 3) : (i.options.zIndex = i.defaults.zIndex)),
                void 0 !== e.OTransform && ((i.animType = "OTransform"), (i.transformType = "-o-transform"), (i.transitionType = "OTransition"), void 0 === e.perspectiveProperty && void 0 === e.webkitPerspective && (i.animType = !1)),
                void 0 !== e.MozTransform && ((i.animType = "MozTransform"), (i.transformType = "-moz-transform"), (i.transitionType = "MozTransition"), void 0 === e.perspectiveProperty && void 0 === e.MozPerspective && (i.animType = !1)),
                void 0 !== e.webkitTransform &&
                    ((i.animType = "webkitTransform"), (i.transformType = "-webkit-transform"), (i.transitionType = "webkitTransition"), void 0 === e.perspectiveProperty && void 0 === e.webkitPerspective && (i.animType = !1)),
                void 0 !== e.msTransform && ((i.animType = "msTransform"), (i.transformType = "-ms-transform"), (i.transitionType = "msTransition"), void 0 === e.msTransform && (i.animType = !1)),
                void 0 !== e.transform && !1 !== i.animType && ((i.animType = "transform"), (i.transformType = "transform"), (i.transitionType = "transition")),
                (i.transformsEnabled = i.options.useTransform && null !== i.animType && !1 !== i.animType);
        }),
        (t.prototype.setSlideClasses = function (i) {
            var e,
                t,
                o,
                s,
                n = this;
            if (((t = n.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden", "true")), n.$slides.eq(i).addClass("slick-current"), !0 === n.options.centerMode)) {
                var r = n.options.slidesToShow % 2 == 0 ? 1 : 0;
                (e = Math.floor(n.options.slidesToShow / 2)),
                    !0 === n.options.infinite &&
                        (i >= e && i <= n.slideCount - 1 - e
                            ? n.$slides
                                  .slice(i - e + r, i + e + 1)
                                  .addClass("slick-active")
                                  .attr("aria-hidden", "false")
                            : ((o = n.options.slidesToShow + i),
                              t
                                  .slice(o - e + 1 + r, o + e + 2)
                                  .addClass("slick-active")
                                  .attr("aria-hidden", "false")),
                        0 === i ? t.eq(t.length - 1 - n.options.slidesToShow).addClass("slick-center") : i === n.slideCount - 1 && t.eq(n.options.slidesToShow).addClass("slick-center")),
                    n.$slides.eq(i).addClass("slick-center");
            } else
                i >= 0 && i <= n.slideCount - n.options.slidesToShow
                    ? n.$slides
                          .slice(i, i + n.options.slidesToShow)
                          .addClass("slick-active")
                          .attr("aria-hidden", "false")
                    : t.length <= n.options.slidesToShow
                    ? t.addClass("slick-active").attr("aria-hidden", "false")
                    : ((s = n.slideCount % n.options.slidesToShow),
                      (o = !0 === n.options.infinite ? n.options.slidesToShow + i : i),
                      n.options.slidesToShow == n.options.slidesToScroll && n.slideCount - i < n.options.slidesToShow
                          ? t
                                .slice(o - (n.options.slidesToShow - s), o + s)
                                .addClass("slick-active")
                                .attr("aria-hidden", "false")
                          : t
                                .slice(o, o + n.options.slidesToShow)
                                .addClass("slick-active")
                                .attr("aria-hidden", "false"));
            ("ondemand" !== n.options.lazyLoad && "anticipated" !== n.options.lazyLoad) || n.lazyLoad();
        }),
        (t.prototype.setupInfinite = function () {
            var e,
                t,
                o,
                s = this;
            if ((!0 === s.options.fade && (s.options.centerMode = !1), !0 === s.options.infinite && !1 === s.options.fade && ((t = null), s.slideCount > s.options.slidesToShow))) {
                for (o = !0 === s.options.centerMode ? s.options.slidesToShow + 1 : s.options.slidesToShow, e = s.slideCount; e > s.slideCount - o; e -= 1)
                    (t = e - 1),
                        i(s.$slides[t])
                            .clone(!0)
                            .attr("id", "")
                            .attr("data-slick-index", t - s.slideCount)
                            .prependTo(s.$slideTrack)
                            .addClass("slick-cloned");
                for (e = 0; e < o + s.slideCount; e += 1)
                    (t = e),
                        i(s.$slides[t])
                            .clone(!0)
                            .attr("id", "")
                            .attr("data-slick-index", t + s.slideCount)
                            .appendTo(s.$slideTrack)
                            .addClass("slick-cloned");
                s.$slideTrack
                    .find(".slick-cloned")
                    .find("[id]")
                    .each(function () {
                        i(this).attr("id", "");
                    });
            }
        }),
        (t.prototype.interrupt = function (i) {
            i || this.autoPlay(), (this.interrupted = i);
        }),
        (t.prototype.selectHandler = function (e) {
            var t = i(e.target).is(".slick-slide") ? i(e.target) : i(e.target).parents(".slick-slide"),
                o = parseInt(t.attr("data-slick-index"));
            o || (o = 0), this.slideCount <= this.options.slidesToShow ? this.slideHandler(o, !1, !0) : this.slideHandler(o);
        }),
        (t.prototype.slideHandler = function (i, e, t) {
            var o,
                s,
                n,
                r,
                l,
                d = null,
                a = this;
            if (((e = e || !1), !((!0 === a.animating && !0 === a.options.waitForAnimate) || (!0 === a.options.fade && a.currentSlide === i))))
                if (
                    (!1 === e && a.asNavFor(i),
                    (o = i),
                    (d = a.getLeft(o)),
                    (r = a.getLeft(a.currentSlide)),
                    (a.currentLeft = null === a.swipeLeft ? r : a.swipeLeft),
                    !1 === a.options.infinite && !1 === a.options.centerMode && (i < 0 || i > a.getDotCount() * a.options.slidesToScroll))
                )
                    !1 === a.options.fade &&
                        ((o = a.currentSlide),
                        !0 !== t
                            ? a.animateSlide(r, function () {
                                  a.postSlide(o);
                              })
                            : a.postSlide(o));
                else if (!1 === a.options.infinite && !0 === a.options.centerMode && (i < 0 || i > a.slideCount - a.options.slidesToScroll))
                    !1 === a.options.fade &&
                        ((o = a.currentSlide),
                        !0 !== t
                            ? a.animateSlide(r, function () {
                                  a.postSlide(o);
                              })
                            : a.postSlide(o));
                else {
                    if (
                        (a.options.autoplay && clearInterval(a.autoPlayTimer),
                        (s =
                            o < 0
                                ? a.slideCount % a.options.slidesToScroll != 0
                                    ? a.slideCount - (a.slideCount % a.options.slidesToScroll)
                                    : a.slideCount + o
                                : o >= a.slideCount
                                ? a.slideCount % a.options.slidesToScroll != 0
                                    ? 0
                                    : o - a.slideCount
                                : o),
                        (a.animating = !0),
                        a.$slider.trigger("beforeChange", [a, a.currentSlide, s]),
                        (n = a.currentSlide),
                        (a.currentSlide = s),
                        a.setSlideClasses(a.currentSlide),
                        a.options.asNavFor && (l = (l = a.getNavTarget()).slick("getSlick")).slideCount <= l.options.slidesToShow && l.setSlideClasses(a.currentSlide),
                        a.updateDots(),
                        a.updateArrows(),
                        !0 === a.options.fade)
                    )
                        return (
                            !0 !== t
                                ? (a.fadeSlideOut(n),
                                  a.fadeSlide(s, function () {
                                      a.postSlide(s);
                                  }))
                                : a.postSlide(s),
                            void a.animateHeight()
                        );
                    !0 !== t
                        ? a.animateSlide(d, function () {
                              a.postSlide(s);
                          })
                        : a.postSlide(s);
                }
        }),
        (t.prototype.startLoad = function () {
            var i = this;
            !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.hide(), i.$nextArrow.hide()),
                !0 === i.options.dots && i.slideCount > i.options.slidesToShow && i.$dots.hide(),
                i.$slider.addClass("slick-loading");
        }),
        (t.prototype.swipeDirection = function () {
            var i,
                e,
                t,
                o,
                s = this;
            return (
                (i = s.touchObject.startX - s.touchObject.curX),
                (e = s.touchObject.startY - s.touchObject.curY),
                (t = Math.atan2(e, i)),
                (o = Math.round((180 * t) / Math.PI)) < 0 && (o = 360 - Math.abs(o)),
                o <= 45 && o >= 0
                    ? !1 === s.options.rtl
                        ? "left"
                        : "right"
                    : o <= 360 && o >= 315
                    ? !1 === s.options.rtl
                        ? "left"
                        : "right"
                    : o >= 135 && o <= 225
                    ? !1 === s.options.rtl
                        ? "right"
                        : "left"
                    : !0 === s.options.verticalSwiping
                    ? o >= 35 && o <= 135
                        ? "down"
                        : "up"
                    : "vertical"
            );
        }),
        (t.prototype.swipeEnd = function (i) {
            var e,
                t,
                o = this;
            if (((o.dragging = !1), (o.swiping = !1), o.scrolling)) return (o.scrolling = !1), !1;
            if (((o.interrupted = !1), (o.shouldClick = !(o.touchObject.swipeLength > 10)), void 0 === o.touchObject.curX)) return !1;
            if ((!0 === o.touchObject.edgeHit && o.$slider.trigger("edge", [o, o.swipeDirection()]), o.touchObject.swipeLength >= o.touchObject.minSwipe)) {
                switch ((t = o.swipeDirection())) {
                    case "left":
                    case "down":
                        (e = o.options.swipeToSlide ? o.checkNavigable(o.currentSlide + o.getSlideCount()) : o.currentSlide + o.getSlideCount()), (o.currentDirection = 0);
                        break;
                    case "right":
                    case "up":
                        (e = o.options.swipeToSlide ? o.checkNavigable(o.currentSlide - o.getSlideCount()) : o.currentSlide - o.getSlideCount()), (o.currentDirection = 1);
                }
                "vertical" != t && (o.slideHandler(e), (o.touchObject = {}), o.$slider.trigger("swipe", [o, t]));
            } else o.touchObject.startX !== o.touchObject.curX && (o.slideHandler(o.currentSlide), (o.touchObject = {}));
        }),
        (t.prototype.swipeHandler = function (i) {
            var e = this;
            if (!(!1 === e.options.swipe || ("ontouchend" in document && !1 === e.options.swipe) || (!1 === e.options.draggable && -1 !== i.type.indexOf("mouse"))))
                switch (
                    ((e.touchObject.fingerCount = i.originalEvent && void 0 !== i.originalEvent.touches ? i.originalEvent.touches.length : 1),
                    (e.touchObject.minSwipe = e.listWidth / e.options.touchThreshold),
                    !0 === e.options.verticalSwiping && (e.touchObject.minSwipe = e.listHeight / e.options.touchThreshold),
                    i.data.action)
                ) {
                    case "start":
                        e.swipeStart(i);
                        break;
                    case "move":
                        e.swipeMove(i);
                        break;
                    case "end":
                        e.swipeEnd(i);
                }
        }),
        (t.prototype.swipeMove = function (i) {
            var e,
                t,
                o,
                s,
                n,
                r,
                l = this;
            return (
                (n = void 0 !== i.originalEvent ? i.originalEvent.touches : null),
                !(!l.dragging || l.scrolling || (n && 1 !== n.length)) &&
                    ((e = l.getLeft(l.currentSlide)),
                    (l.touchObject.curX = void 0 !== n ? n[0].pageX : i.clientX),
                    (l.touchObject.curY = void 0 !== n ? n[0].pageY : i.clientY),
                    (l.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(l.touchObject.curX - l.touchObject.startX, 2)))),
                    (r = Math.round(Math.sqrt(Math.pow(l.touchObject.curY - l.touchObject.startY, 2)))),
                    !l.options.verticalSwiping && !l.swiping && r > 4
                        ? ((l.scrolling = !0), !1)
                        : (!0 === l.options.verticalSwiping && (l.touchObject.swipeLength = r),
                          (t = l.swipeDirection()),
                          void 0 !== i.originalEvent && l.touchObject.swipeLength > 4 && ((l.swiping = !0), i.preventDefault()),
                          (s = (!1 === l.options.rtl ? 1 : -1) * (l.touchObject.curX > l.touchObject.startX ? 1 : -1)),
                          !0 === l.options.verticalSwiping && (s = l.touchObject.curY > l.touchObject.startY ? 1 : -1),
                          (o = l.touchObject.swipeLength),
                          (l.touchObject.edgeHit = !1),
                          !1 === l.options.infinite &&
                              ((0 === l.currentSlide && "right" === t) || (l.currentSlide >= l.getDotCount() && "left" === t)) &&
                              ((o = l.touchObject.swipeLength * l.options.edgeFriction), (l.touchObject.edgeHit = !0)),
                          !1 === l.options.vertical ? (l.swipeLeft = e + o * s) : (l.swipeLeft = e + o * (l.$list.height() / l.listWidth) * s),
                          !0 === l.options.verticalSwiping && (l.swipeLeft = e + o * s),
                          !0 !== l.options.fade && !1 !== l.options.touchMove && (!0 === l.animating ? ((l.swipeLeft = null), !1) : void l.setCSS(l.swipeLeft))))
            );
        }),
        (t.prototype.swipeStart = function (i) {
            var e,
                t = this;
            if (((t.interrupted = !0), 1 !== t.touchObject.fingerCount || t.slideCount <= t.options.slidesToShow)) return (t.touchObject = {}), !1;
            void 0 !== i.originalEvent && void 0 !== i.originalEvent.touches && (e = i.originalEvent.touches[0]),
                (t.touchObject.startX = t.touchObject.curX = void 0 !== e ? e.pageX : i.clientX),
                (t.touchObject.startY = t.touchObject.curY = void 0 !== e ? e.pageY : i.clientY),
                (t.dragging = !0);
        }),
        (t.prototype.unfilterSlides = t.prototype.slickUnfilter = function () {
            var i = this;
            null !== i.$slidesCache && (i.unload(), i.$slideTrack.children(this.options.slide).detach(), i.$slidesCache.appendTo(i.$slideTrack), i.reinit());
        }),
        (t.prototype.unload = function () {
            var e = this;
            i(".slick-cloned", e.$slider).remove(),
                e.$dots && e.$dots.remove(),
                e.$prevArrow && e.htmlExpr.test(e.options.prevArrow) && e.$prevArrow.remove(),
                e.$nextArrow && e.htmlExpr.test(e.options.nextArrow) && e.$nextArrow.remove(),
                e.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden", "true").css("width", "");
        }),
        (t.prototype.unslick = function (i) {
            this.$slider.trigger("unslick", [this, i]), this.destroy();
        }),
        (t.prototype.updateArrows = function () {
            var i = this;
            Math.floor(i.options.slidesToShow / 2),
                !0 === i.options.arrows &&
                    i.slideCount > i.options.slidesToShow &&
                    !i.options.infinite &&
                    (i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
                    i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
                    0 === i.currentSlide
                        ? (i.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"), i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"))
                        : i.currentSlide >= i.slideCount - i.options.slidesToShow && !1 === i.options.centerMode
                        ? (i.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"), i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"))
                        : i.currentSlide >= i.slideCount - 1 &&
                          !0 === i.options.centerMode &&
                          (i.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"), i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")));
        }),
        (t.prototype.updateDots = function () {
            var i = this;
            null !== i.$dots &&
                (i.$dots.find("li").removeClass("slick-active").end(),
                i.$dots
                    .find("li")
                    .eq(Math.floor(i.currentSlide / i.options.slidesToScroll))
                    .addClass("slick-active"));
        }),
        (t.prototype.visibility = function () {
            this.options.autoplay && (document[this.hidden] ? (this.interrupted = !0) : (this.interrupted = !1));
        }),
        (i.fn.slick = function () {
            var i,
                e,
                o = this,
                s = arguments[0],
                n = Array.prototype.slice.call(arguments, 1),
                r = o.length;
            for (i = 0; i < r; i++) if (("object" == typeof s || void 0 === s ? (o[i].slick = new t(o[i], s)) : (e = o[i].slick[s].apply(o[i].slick, n)), void 0 !== e)) return e;
            return o;
        });
});
/*! easyzoom 2.5.0 */
!(function (a, b) {
    "use strict";
    "function" == typeof define && define.amd
        ? define(["jquery"], function (a) {
              b(a);
          })
        : "object" == typeof module && module.exports
        ? (module.exports = a.EasyZoom = b(require("jquery")))
        : (a.EasyZoom = b(a.jQuery));
})(this, function (a) {
    "use strict";
    function b(b, c) {
        (this.$target = a(b)), (this.opts = a.extend({}, i, c, this.$target.data())), void 0 === this.isOpen && this._init();
    }
    var c,
        d,
        e,
        f,
        g,
        h,
        i = {
            loadingNotice: "Loading image",
            errorNotice: "The image could not be loaded",
            errorDuration: 2500,
            linkAttribute: "href",
            preventClicks: !0,
            beforeShow: a.noop,
            beforeHide: a.noop,
            onShow: a.noop,
            onHide: a.noop,
            onMove: a.noop,
        };
    (b.prototype._init = function () {
        (this.$link = this.$target.find("a")),
            (this.$image = this.$target.find("img")),
            (this.$flyout = a('<div class="easyzoom-flyout" />')),
            (this.$notice = a('<div class="easyzoom-notice" />')),
            this.$target.on({
                "mousemove.easyzoom touchmove.easyzoom": a.proxy(this._onMove, this),
                "mouseleave.easyzoom touchend.easyzoom": a.proxy(this._onLeave, this),
                "mouseenter.easyzoom touchstart.easyzoom": a.proxy(this._onEnter, this),
            }),
            this.opts.preventClicks &&
                this.$target.on("click.easyzoom", function (a) {
                    a.preventDefault();
                });
    }),
        (b.prototype.show = function (a, b) {
            var g,
                h,
                i,
                j,
                k = this;
            if (this.opts.beforeShow.call(this) !== !1) {
                if (!this.isReady)
                    return this._loadImage(this.$link.attr(this.opts.linkAttribute), function () {
                        (!k.isMouseOver && b) || k.show(a);
                    });
                this.$target.append(this.$flyout),
                    (g = this.$target.width()),
                    (h = this.$target.height()),
                    (i = this.$flyout.width()),
                    (j = this.$flyout.height()),
                    (c = this.$zoom.width() - i),
                    (d = this.$zoom.height() - j),
                    c < 0 && (c = 0),
                    d < 0 && (d = 0),
                    (e = c / g),
                    (f = d / h),
                    (this.isOpen = !0),
                    this.opts.onShow.call(this),
                    a && this._move(a);
            }
        }),
        (b.prototype._onEnter = function (a) {
            var b = a.originalEvent.touches;
            (this.isMouseOver = !0), (b && 1 != b.length) || (a.preventDefault(), this.show(a, !0));
        }),
        (b.prototype._onMove = function (a) {
            this.isOpen && (a.preventDefault(), this._move(a));
        }),
        (b.prototype._onLeave = function () {
            (this.isMouseOver = !1), this.isOpen && this.hide();
        }),
        (b.prototype._onLoad = function (a) {
            a.currentTarget.width && ((this.isReady = !0), this.$notice.detach(), this.$flyout.html(this.$zoom), this.$target.removeClass("is-loading").addClass("is-ready"), a.data.call && a.data());
        }),
        (b.prototype._onError = function () {
            var a = this;
            this.$notice.text(this.opts.errorNotice),
                this.$target.removeClass("is-loading").addClass("is-error"),
                (this.detachNotice = setTimeout(function () {
                    a.$notice.detach(), (a.detachNotice = null);
                }, this.opts.errorDuration));
        }),
        (b.prototype._loadImage = function (b, c) {
            var d = new Image();
            this.$target.addClass("is-loading").append(this.$notice.text(this.opts.loadingNotice)),
                (this.$zoom = a(d).on("error", a.proxy(this._onError, this)).on("load", c, a.proxy(this._onLoad, this))),
                (d.style.position = "absolute"),
                (d.src = b);
        }),
        (b.prototype._move = function (a) {
            if (0 === a.type.indexOf("touch")) {
                var b = a.touches || a.originalEvent.touches;
                (g = b[0].pageX), (h = b[0].pageY);
            } else (g = a.pageX || g), (h = a.pageY || h);
            var i = this.$target.offset(),
                j = h - i.top,
                k = g - i.left,
                l = Math.ceil(j * f),
                m = Math.ceil(k * e);
            if (m < 0 || l < 0 || m > c || l > d) this.hide();
            else {
                var n = l * -1,
                    o = m * -1;
                this.$zoom.css({ top: n, left: o }), this.opts.onMove.call(this, n, o);
            }
        }),
        (b.prototype.hide = function () {
            this.isOpen && this.opts.beforeHide.call(this) !== !1 && (this.$flyout.detach(), (this.isOpen = !1), this.opts.onHide.call(this));
        }),
        (b.prototype.swap = function (b, c, d) {
            this.hide(),
                (this.isReady = !1),
                this.detachNotice && clearTimeout(this.detachNotice),
                this.$notice.parent().length && this.$notice.detach(),
                this.$target.removeClass("is-loading is-ready is-error"),
                this.$image.attr({ src: b, srcset: a.isArray(d) ? d.join() : d }),
                this.$link.attr(this.opts.linkAttribute, c);
        }),
        (b.prototype.teardown = function () {
            this.hide(),
                this.$target.off(".easyzoom").removeClass("is-loading is-ready is-error"),
                this.detachNotice && clearTimeout(this.detachNotice),
                delete this.$link,
                delete this.$zoom,
                delete this.$image,
                delete this.$notice,
                delete this.$flyout,
                delete this.isOpen,
                delete this.isReady;
        }),
        (a.fn.easyZoom = function (c) {
            return this.each(function () {
                var d = a.data(this, "easyZoom");
                d ? void 0 === d.isOpen && d._init() : a.data(this, "easyZoom", new b(this, c));
            });
        });
});
/*! PhotoSwipe - v4.1.1 - 2015-12-24
 * http://photoswipe.com
 * Copyright (c) 2015 Dmitry Semenov; */
!(function (a, b) {
    "function" == typeof define && define.amd ? define(b) : "object" == typeof exports ? (module.exports = b()) : (a.PhotoSwipe = b());
})(this, function () {
    "use strict";
    var a = function (a, b, c, d) {
        var e = {
            features: null,
            bind: function (a, b, c, d) {
                var e = (d ? "remove" : "add") + "EventListener";
                b = b.split(" ");
                for (var f = 0; f < b.length; f++) b[f] && a[e](b[f], c, !1);
            },
            isArray: function (a) {
                return a instanceof Array;
            },
            createEl: function (a, b) {
                var c = document.createElement(b || "div");
                return a && (c.className = a), c;
            },
            getScrollY: function () {
                var a = window.pageYOffset;
                return void 0 !== a ? a : document.documentElement.scrollTop;
            },
            unbind: function (a, b, c) {
                e.bind(a, b, c, !0);
            },
            removeClass: function (a, b) {
                var c = new RegExp("(\\s|^)" + b + "(\\s|$)");
                a.className = a.className
                    .replace(c, " ")
                    .replace(/^\s\s*/, "")
                    .replace(/\s\s*$/, "");
            },
            addClass: function (a, b) {
                e.hasClass(a, b) || (a.className += (a.className ? " " : "") + b);
            },
            hasClass: function (a, b) {
                return a.className && new RegExp("(^|\\s)" + b + "(\\s|$)").test(a.className);
            },
            getChildByClass: function (a, b) {
                for (var c = a.firstChild; c; ) {
                    if (e.hasClass(c, b)) return c;
                    c = c.nextSibling;
                }
            },
            arraySearch: function (a, b, c) {
                for (var d = a.length; d--; ) if (a[d][c] === b) return d;
                return -1;
            },
            extend: function (a, b, c) {
                for (var d in b)
                    if (b.hasOwnProperty(d)) {
                        if (c && a.hasOwnProperty(d)) continue;
                        a[d] = b[d];
                    }
            },
            easing: {
                sine: {
                    out: function (a) {
                        return Math.sin(a * (Math.PI / 2));
                    },
                    inOut: function (a) {
                        return -(Math.cos(Math.PI * a) - 1) / 2;
                    },
                },
                cubic: {
                    out: function (a) {
                        return --a * a * a + 1;
                    },
                },
            },
            detectFeatures: function () {
                if (e.features) return e.features;
                var a = e.createEl(),
                    b = a.style,
                    c = "",
                    d = {};
                if (
                    ((d.oldIE = document.all && !document.addEventListener),
                    (d.touch = "ontouchstart" in window),
                    window.requestAnimationFrame && ((d.raf = window.requestAnimationFrame), (d.caf = window.cancelAnimationFrame)),
                    (d.pointerEvent = navigator.pointerEnabled || navigator.msPointerEnabled),
                    !d.pointerEvent)
                ) {
                    var f = navigator.userAgent;
                    if (/iP(hone|od)/.test(navigator.platform)) {
                        var g = navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
                        g && g.length > 0 && ((g = parseInt(g[1], 10)), g >= 1 && g < 8 && (d.isOldIOSPhone = !0));
                    }
                    var h = f.match(/Android\s([0-9\.]*)/),
                        i = h ? h[1] : 0;
                    (i = parseFloat(i)), i >= 1 && (i < 4.4 && (d.isOldAndroid = !0), (d.androidVersion = i)), (d.isMobileOpera = /opera mini|opera mobi/i.test(f));
                }
                for (var j, k, l = ["transform", "perspective", "animationName"], m = ["", "webkit", "Moz", "ms", "O"], n = 0; n < 4; n++) {
                    c = m[n];
                    for (var o = 0; o < 3; o++) (j = l[o]), (k = c + (c ? j.charAt(0).toUpperCase() + j.slice(1) : j)), !d[j] && k in b && (d[j] = k);
                    c && !d.raf && ((c = c.toLowerCase()), (d.raf = window[c + "RequestAnimationFrame"]), d.raf && (d.caf = window[c + "CancelAnimationFrame"] || window[c + "CancelRequestAnimationFrame"]));
                }
                if (!d.raf) {
                    var p = 0;
                    (d.raf = function (a) {
                        var b = new Date().getTime(),
                            c = Math.max(0, 16 - (b - p)),
                            d = window.setTimeout(function () {
                                a(b + c);
                            }, c);
                        return (p = b + c), d;
                    }),
                        (d.caf = function (a) {
                            clearTimeout(a);
                        });
                }
                return (d.svg = !!document.createElementNS && !!document.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect), (e.features = d), d;
            },
        };
        e.detectFeatures(),
            e.features.oldIE &&
                (e.bind = function (a, b, c, d) {
                    b = b.split(" ");
                    for (
                        var e,
                            f = (d ? "detach" : "attach") + "Event",
                            g = function () {
                                c.handleEvent.call(c);
                            },
                            h = 0;
                        h < b.length;
                        h++
                    )
                        if ((e = b[h]))
                            if ("object" == typeof c && c.handleEvent) {
                                if (d) {
                                    if (!c["oldIE" + e]) return !1;
                                } else c["oldIE" + e] = g;
                                a[f]("on" + e, c["oldIE" + e]);
                            } else a[f]("on" + e, c);
                });
        var f = this,
            g = 25,
            h = 3,
            i = {
                allowPanToNext: !0,
                spacing: 0.12,
                bgOpacity: 1,
                mouseUsed: !1,
                loop: !0,
                pinchToClose: !0,
                closeOnScroll: !0,
                closeOnVerticalDrag: !0,
                verticalDragRange: 0.75,
                hideAnimationDuration: 333,
                showAnimationDuration: 333,
                showHideOpacity: !1,
                focus: !0,
                escKey: !0,
                arrowKeys: !0,
                mainScrollEndFriction: 0.35,
                panEndFriction: 0.35,
                isClickableElement: function (a) {
                    return "A" === a.tagName;
                },
                getDoubleTapZoom: function (a, b) {
                    return a ? 1 : b.initialZoomLevel < 0.7 ? 1 : 1.33;
                },
                maxSpreadZoom: 1.33,
                modal: !0,
                scaleMode: "fit",
            };
        e.extend(i, d);
        var j,
            k,
            l,
            m,
            n,
            o,
            p,
            q,
            r,
            s,
            t,
            u,
            v,
            w,
            x,
            y,
            z,
            A,
            B,
            C,
            D,
            E,
            F,
            G,
            H,
            I,
            J,
            K,
            L,
            M,
            N,
            O,
            P,
            Q,
            R,
            S,
            T,
            U,
            V,
            W,
            X,
            Y,
            Z,
            $,
            _,
            aa,
            ba,
            ca,
            da,
            ea,
            fa,
            ga,
            ha,
            ia,
            ja,
            ka,
            la = function () {
                return { x: 0, y: 0 };
            },
            ma = la(),
            na = la(),
            oa = la(),
            pa = {},
            qa = 0,
            ra = {},
            sa = la(),
            ta = 0,
            ua = !0,
            va = [],
            wa = {},
            xa = !1,
            ya = function (a, b) {
                e.extend(f, b.publicMethods), va.push(a);
            },
            za = function (a) {
                var b = _b();
                return a > b - 1 ? a - b : a < 0 ? b + a : a;
            },
            Aa = {},
            Ba = function (a, b) {
                return Aa[a] || (Aa[a] = []), Aa[a].push(b);
            },
            Ca = function (a) {
                var b = Aa[a];
                if (b) {
                    var c = Array.prototype.slice.call(arguments);
                    c.shift();
                    for (var d = 0; d < b.length; d++) b[d].apply(f, c);
                }
            },
            Da = function () {
                return new Date().getTime();
            },
            Ea = function (a) {
                (ia = a), (f.bg.style.opacity = a * i.bgOpacity);
            },
            Fa = function (a, b, c, d, e) {
                (!xa || (e && e !== f.currItem)) && (d /= e ? e.fitRatio : f.currItem.fitRatio), (a[E] = u + b + "px, " + c + "px" + v + " scale(" + d + ")");
            },
            Ga = function (a) {
                da && (a && (s > f.currItem.fitRatio ? xa || (lc(f.currItem, !1, !0), (xa = !0)) : xa && (lc(f.currItem), (xa = !1))), Fa(da, oa.x, oa.y, s));
            },
            Ha = function (a) {
                a.container && Fa(a.container.style, a.initialPosition.x, a.initialPosition.y, a.initialZoomLevel, a);
            },
            Ia = function (a, b) {
                b[E] = u + a + "px, 0px" + v;
            },
            Ja = function (a, b) {
                if (!i.loop && b) {
                    var c = m + (sa.x * qa - a) / sa.x,
                        d = Math.round(a - sb.x);
                    ((c < 0 && d > 0) || (c >= _b() - 1 && d < 0)) && (a = sb.x + d * i.mainScrollEndFriction);
                }
                (sb.x = a), Ia(a, n);
            },
            Ka = function (a, b) {
                var c = tb[a] - ra[a];
                return na[a] + ma[a] + c - c * (b / t);
            },
            La = function (a, b) {
                (a.x = b.x), (a.y = b.y), b.id && (a.id = b.id);
            },
            Ma = function (a) {
                (a.x = Math.round(a.x)), (a.y = Math.round(a.y));
            },
            Na = null,
            Oa = function () {
                Na && (e.unbind(document, "mousemove", Oa), e.addClass(a, "pswp--has_mouse"), (i.mouseUsed = !0), Ca("mouseUsed")),
                    (Na = setTimeout(function () {
                        Na = null;
                    }, 100));
            },
            Pa = function () {
                e.bind(document, "keydown", f), N.transform && e.bind(f.scrollWrap, "click", f), i.mouseUsed || e.bind(document, "mousemove", Oa), e.bind(window, "resize scroll", f), Ca("bindEvents");
            },
            Qa = function () {
                e.unbind(window, "resize", f),
                    e.unbind(window, "scroll", r.scroll),
                    e.unbind(document, "keydown", f),
                    e.unbind(document, "mousemove", Oa),
                    N.transform && e.unbind(f.scrollWrap, "click", f),
                    U && e.unbind(window, p, f),
                    Ca("unbindEvents");
            },
            Ra = function (a, b) {
                var c = hc(f.currItem, pa, a);
                return b && (ca = c), c;
            },
            Sa = function (a) {
                return a || (a = f.currItem), a.initialZoomLevel;
            },
            Ta = function (a) {
                return a || (a = f.currItem), a.w > 0 ? i.maxSpreadZoom : 1;
            },
            Ua = function (a, b, c, d) {
                return d === f.currItem.initialZoomLevel ? ((c[a] = f.currItem.initialPosition[a]), !0) : ((c[a] = Ka(a, d)), c[a] > b.min[a] ? ((c[a] = b.min[a]), !0) : c[a] < b.max[a] && ((c[a] = b.max[a]), !0));
            },
            Va = function () {
                if (E) {
                    var b = N.perspective && !G;
                    return (u = "translate" + (b ? "3d(" : "(")), void (v = N.perspective ? ", 0px)" : ")");
                }
                (E = "left"),
                    e.addClass(a, "pswp--ie"),
                    (Ia = function (a, b) {
                        b.left = a + "px";
                    }),
                    (Ha = function (a) {
                        var b = a.fitRatio > 1 ? 1 : a.fitRatio,
                            c = a.container.style,
                            d = b * a.w,
                            e = b * a.h;
                        (c.width = d + "px"), (c.height = e + "px"), (c.left = a.initialPosition.x + "px"), (c.top = a.initialPosition.y + "px");
                    }),
                    (Ga = function () {
                        if (da) {
                            var a = da,
                                b = f.currItem,
                                c = b.fitRatio > 1 ? 1 : b.fitRatio,
                                d = c * b.w,
                                e = c * b.h;
                            (a.width = d + "px"), (a.height = e + "px"), (a.left = oa.x + "px"), (a.top = oa.y + "px");
                        }
                    });
            },
            Wa = function (a) {
                var b = "";
                i.escKey && 27 === a.keyCode ? (b = "close") : i.arrowKeys && (37 === a.keyCode ? (b = "prev") : 39 === a.keyCode && (b = "next")),
                    b && (a.ctrlKey || a.altKey || a.shiftKey || a.metaKey || (a.preventDefault ? a.preventDefault() : (a.returnValue = !1), f[b]()));
            },
            Xa = function (a) {
                a && (X || W || ea || S) && (a.preventDefault(), a.stopPropagation());
            },
            Ya = function () {
                f.setScrollOffset(0, e.getScrollY());
            },
            Za = {},
            $a = 0,
            _a = function (a) {
                Za[a] && (Za[a].raf && I(Za[a].raf), $a--, delete Za[a]);
            },
            ab = function (a) {
                Za[a] && _a(a), Za[a] || ($a++, (Za[a] = {}));
            },
            bb = function () {
                for (var a in Za) Za.hasOwnProperty(a) && _a(a);
            },
            cb = function (a, b, c, d, e, f, g) {
                var h,
                    i = Da();
                ab(a);
                var j = function () {
                    if (Za[a]) {
                        if (((h = Da() - i), h >= d)) return _a(a), f(c), void (g && g());
                        f((c - b) * e(h / d) + b), (Za[a].raf = H(j));
                    }
                };
                j();
            },
            db = {
                shout: Ca,
                listen: Ba,
                viewportSize: pa,
                options: i,
                isMainScrollAnimating: function () {
                    return ea;
                },
                getZoomLevel: function () {
                    return s;
                },
                getCurrentIndex: function () {
                    return m;
                },
                isDragging: function () {
                    return U;
                },
                isZooming: function () {
                    return _;
                },
                setScrollOffset: function (a, b) {
                    (ra.x = a), (M = ra.y = b), Ca("updateScrollOffset", ra);
                },
                applyZoomPan: function (a, b, c, d) {
                    (oa.x = b), (oa.y = c), (s = a), Ga(d);
                },
                init: function () {
                    if (!j && !k) {
                        var c;
                        (f.framework = e),
                            (f.template = a),
                            (f.bg = e.getChildByClass(a, "pswp__bg")),
                            (J = a.className),
                            (j = !0),
                            (N = e.detectFeatures()),
                            (H = N.raf),
                            (I = N.caf),
                            (E = N.transform),
                            (L = N.oldIE),
                            (f.scrollWrap = e.getChildByClass(a, "pswp__scroll-wrap")),
                            (f.container = e.getChildByClass(f.scrollWrap, "pswp__container")),
                            (n = f.container.style),
                            (f.itemHolders = y = [
                                { el: f.container.children[0], wrap: 0, index: -1 },
                                { el: f.container.children[1], wrap: 0, index: -1 },
                                { el: f.container.children[2], wrap: 0, index: -1 },
                            ]),
                            (y[0].el.style.display = y[2].el.style.display = "none"),
                            Va(),
                            (r = { resize: f.updateSize, scroll: Ya, keydown: Wa, click: Xa });
                        var d = N.isOldIOSPhone || N.isOldAndroid || N.isMobileOpera;
                        for ((N.animationName && N.transform && !d) || (i.showAnimationDuration = i.hideAnimationDuration = 0), c = 0; c < va.length; c++) f["init" + va[c]]();
                        if (b) {
                            var g = (f.ui = new b(f, e));
                            g.init();
                        }
                        Ca("firstUpdate"),
                            (m = m || i.index || 0),
                            (isNaN(m) || m < 0 || m >= _b()) && (m = 0),
                            (f.currItem = $b(m)),
                            (N.isOldIOSPhone || N.isOldAndroid) && (ua = !1),
                            a.setAttribute("aria-hidden", "false"),
                            i.modal && (ua ? (a.style.position = "fixed") : ((a.style.position = "absolute"), (a.style.top = e.getScrollY() + "px"))),
                            void 0 === M && (Ca("initialLayout"), (M = K = e.getScrollY()));
                        var l = "pswp--open ";
                        for (
                            i.mainClass && (l += i.mainClass + " "),
                                i.showHideOpacity && (l += "pswp--animate_opacity "),
                                l += G ? "pswp--touch" : "pswp--notouch",
                                l += N.animationName ? " pswp--css_animation" : "",
                                l += N.svg ? " pswp--svg" : "",
                                e.addClass(a, l),
                                f.updateSize(),
                                o = -1,
                                ta = null,
                                c = 0;
                            c < h;
                            c++
                        )
                            Ia((c + o) * sa.x, y[c].el.style);
                        L || e.bind(f.scrollWrap, q, f),
                            Ba("initialZoomInEnd", function () {
                                f.setContent(y[0], m - 1), f.setContent(y[2], m + 1), (y[0].el.style.display = y[2].el.style.display = "block"), i.focus && a.focus(), Pa();
                            }),
                            f.setContent(y[1], m),
                            f.updateCurrItem(),
                            Ca("afterInit"),
                            ua ||
                                (w = setInterval(function () {
                                    $a || U || _ || s !== f.currItem.initialZoomLevel || f.updateSize();
                                }, 1e3)),
                            e.addClass(a, "pswp--visible");
                    }
                },
                close: function () {
                    j && ((j = !1), (k = !0), Ca("close"), Qa(), bc(f.currItem, null, !0, f.destroy));
                },
                destroy: function () {
                    Ca("destroy"), Wb && clearTimeout(Wb), a.setAttribute("aria-hidden", "true"), (a.className = J), w && clearInterval(w), e.unbind(f.scrollWrap, q, f), e.unbind(window, "scroll", f), yb(), bb(), (Aa = null);
                },
                panTo: function (a, b, c) {
                    c || (a > ca.min.x ? (a = ca.min.x) : a < ca.max.x && (a = ca.max.x), b > ca.min.y ? (b = ca.min.y) : b < ca.max.y && (b = ca.max.y)), (oa.x = a), (oa.y = b), Ga();
                },
                handleEvent: function (a) {
                    (a = a || window.event), r[a.type] && r[a.type](a);
                },
                goTo: function (a) {
                    a = za(a);
                    var b = a - m;
                    (ta = b), (m = a), (f.currItem = $b(m)), (qa -= b), Ja(sa.x * qa), bb(), (ea = !1), f.updateCurrItem();
                },
                next: function () {
                    f.goTo(m + 1);
                },
                prev: function () {
                    f.goTo(m - 1);
                },
                updateCurrZoomItem: function (a) {
                    if ((a && Ca("beforeChange", 0), y[1].el.children.length)) {
                        var b = y[1].el.children[0];
                        da = e.hasClass(b, "pswp__zoom-wrap") ? b.style : null;
                    } else da = null;
                    (ca = f.currItem.bounds), (t = s = f.currItem.initialZoomLevel), (oa.x = ca.center.x), (oa.y = ca.center.y), a && Ca("afterChange");
                },
                invalidateCurrItems: function () {
                    x = !0;
                    for (var a = 0; a < h; a++) y[a].item && (y[a].item.needsUpdate = !0);
                },
                updateCurrItem: function (a) {
                    if (0 !== ta) {
                        var b,
                            c = Math.abs(ta);
                        if (!(a && c < 2)) {
                            (f.currItem = $b(m)), (xa = !1), Ca("beforeChange", ta), c >= h && ((o += ta + (ta > 0 ? -h : h)), (c = h));
                            for (var d = 0; d < c; d++)
                                ta > 0
                                    ? ((b = y.shift()), (y[h - 1] = b), o++, Ia((o + 2) * sa.x, b.el.style), f.setContent(b, m - c + d + 1 + 1))
                                    : ((b = y.pop()), y.unshift(b), o--, Ia(o * sa.x, b.el.style), f.setContent(b, m + c - d - 1 - 1));
                            if (da && 1 === Math.abs(ta)) {
                                var e = $b(z);
                                e.initialZoomLevel !== s && (hc(e, pa), lc(e), Ha(e));
                            }
                            (ta = 0), f.updateCurrZoomItem(), (z = m), Ca("afterChange");
                        }
                    }
                },
                updateSize: function (b) {
                    if (!ua && i.modal) {
                        var c = e.getScrollY();
                        if ((M !== c && ((a.style.top = c + "px"), (M = c)), !b && wa.x === window.innerWidth && wa.y === window.innerHeight)) return;
                        (wa.x = window.innerWidth), (wa.y = window.innerHeight), (a.style.height = wa.y + "px");
                    }
                    if (((pa.x = f.scrollWrap.clientWidth), (pa.y = f.scrollWrap.clientHeight), Ya(), (sa.x = pa.x + Math.round(pa.x * i.spacing)), (sa.y = pa.y), Ja(sa.x * qa), Ca("beforeResize"), void 0 !== o)) {
                        for (var d, g, j, k = 0; k < h; k++)
                            (d = y[k]),
                                Ia((k + o) * sa.x, d.el.style),
                                (j = m + k - 1),
                                i.loop && _b() > 2 && (j = za(j)),
                                (g = $b(j)),
                                g && (x || g.needsUpdate || !g.bounds) ? (f.cleanSlide(g), f.setContent(d, j), 1 === k && ((f.currItem = g), f.updateCurrZoomItem(!0)), (g.needsUpdate = !1)) : d.index === -1 && j >= 0 && f.setContent(d, j),
                                g && g.container && (hc(g, pa), lc(g), Ha(g));
                        x = !1;
                    }
                    (t = s = f.currItem.initialZoomLevel), (ca = f.currItem.bounds), ca && ((oa.x = ca.center.x), (oa.y = ca.center.y), Ga(!0)), Ca("resize");
                },
                zoomTo: function (a, b, c, d, f) {
                    b && ((t = s), (tb.x = Math.abs(b.x) - oa.x), (tb.y = Math.abs(b.y) - oa.y), La(na, oa));
                    var g = Ra(a, !1),
                        h = {};
                    Ua("x", g, h, a), Ua("y", g, h, a);
                    var i = s,
                        j = { x: oa.x, y: oa.y };
                    Ma(h);
                    var k = function (b) {
                        1 === b ? ((s = a), (oa.x = h.x), (oa.y = h.y)) : ((s = (a - i) * b + i), (oa.x = (h.x - j.x) * b + j.x), (oa.y = (h.y - j.y) * b + j.y)), f && f(b), Ga(1 === b);
                    };
                    c ? cb("customZoomTo", 0, 1, c, d || e.easing.sine.inOut, k) : k(1);
                },
            },
            eb = 30,
            fb = 10,
            gb = {},
            hb = {},
            ib = {},
            jb = {},
            kb = {},
            lb = [],
            mb = {},
            nb = [],
            ob = {},
            pb = 0,
            qb = la(),
            rb = 0,
            sb = la(),
            tb = la(),
            ub = la(),
            vb = function (a, b) {
                return a.x === b.x && a.y === b.y;
            },
            wb = function (a, b) {
                return Math.abs(a.x - b.x) < g && Math.abs(a.y - b.y) < g;
            },
            xb = function (a, b) {
                return (ob.x = Math.abs(a.x - b.x)), (ob.y = Math.abs(a.y - b.y)), Math.sqrt(ob.x * ob.x + ob.y * ob.y);
            },
            yb = function () {
                Y && (I(Y), (Y = null));
            },
            zb = function () {
                U && ((Y = H(zb)), Pb());
            },
            Ab = function () {
                return !("fit" === i.scaleMode && s === f.currItem.initialZoomLevel);
            },
            Bb = function (a, b) {
                return !(!a || a === document) && !(a.getAttribute("class") && a.getAttribute("class").indexOf("pswp__scroll-wrap") > -1) && (b(a) ? a : Bb(a.parentNode, b));
            },
            Cb = {},
            Db = function (a, b) {
                return (Cb.prevent = !Bb(a.target, i.isClickableElement)), Ca("preventDragEvent", a, b, Cb), Cb.prevent;
            },
            Eb = function (a, b) {
                return (b.x = a.pageX), (b.y = a.pageY), (b.id = a.identifier), b;
            },
            Fb = function (a, b, c) {
                (c.x = 0.5 * (a.x + b.x)), (c.y = 0.5 * (a.y + b.y));
            },
            Gb = function (a, b, c) {
                if (a - P > 50) {
                    var d = nb.length > 2 ? nb.shift() : {};
                    (d.x = b), (d.y = c), nb.push(d), (P = a);
                }
            },
            Hb = function () {
                var a = oa.y - f.currItem.initialPosition.y;
                return 1 - Math.abs(a / (pa.y / 2));
            },
            Ib = {},
            Jb = {},
            Kb = [],
            Lb = function (a) {
                for (; Kb.length > 0; ) Kb.pop();
                return (
                    F
                        ? ((ka = 0),
                          lb.forEach(function (a) {
                              0 === ka ? (Kb[0] = a) : 1 === ka && (Kb[1] = a), ka++;
                          }))
                        : a.type.indexOf("touch") > -1
                        ? a.touches && a.touches.length > 0 && ((Kb[0] = Eb(a.touches[0], Ib)), a.touches.length > 1 && (Kb[1] = Eb(a.touches[1], Jb)))
                        : ((Ib.x = a.pageX), (Ib.y = a.pageY), (Ib.id = ""), (Kb[0] = Ib)),
                    Kb
                );
            },
            Mb = function (a, b) {
                var c,
                    d,
                    e,
                    g,
                    h = 0,
                    j = oa[a] + b[a],
                    k = b[a] > 0,
                    l = sb.x + b.x,
                    m = sb.x - mb.x;
                return (
                    (c = j > ca.min[a] || j < ca.max[a] ? i.panEndFriction : 1),
                    (j = oa[a] + b[a] * c),
                    (!i.allowPanToNext && s !== f.currItem.initialZoomLevel) ||
                    (da
                        ? "h" !== fa ||
                          "x" !== a ||
                          W ||
                          (k
                              ? (j > ca.min[a] && ((c = i.panEndFriction), (h = ca.min[a] - j), (d = ca.min[a] - na[a])), (d <= 0 || m < 0) && _b() > 1 ? ((g = l), m < 0 && l > mb.x && (g = mb.x)) : ca.min.x !== ca.max.x && (e = j))
                              : (j < ca.max[a] && ((c = i.panEndFriction), (h = j - ca.max[a]), (d = na[a] - ca.max[a])), (d <= 0 || m > 0) && _b() > 1 ? ((g = l), m > 0 && l < mb.x && (g = mb.x)) : ca.min.x !== ca.max.x && (e = j)))
                        : (g = l),
                    "x" !== a)
                        ? void (ea || Z || (s > f.currItem.fitRatio && (oa[a] += b[a] * c)))
                        : (void 0 !== g && (Ja(g, !0), (Z = g !== mb.x)), ca.min.x !== ca.max.x && (void 0 !== e ? (oa.x = e) : Z || (oa.x += b.x * c)), void 0 !== g)
                );
            },
            Nb = function (a) {
                if (!("mousedown" === a.type && a.button > 0)) {
                    if (Zb) return void a.preventDefault();
                    if (!T || "mousedown" !== a.type) {
                        if ((Db(a, !0) && a.preventDefault(), Ca("pointerDown"), F)) {
                            var b = e.arraySearch(lb, a.pointerId, "id");
                            b < 0 && (b = lb.length), (lb[b] = { x: a.pageX, y: a.pageY, id: a.pointerId });
                        }
                        var c = Lb(a),
                            d = c.length;
                        ($ = null),
                            bb(),
                            (U && 1 !== d) ||
                                ((U = ga = !0),
                                e.bind(window, p, f),
                                (R = ja = ha = S = Z = X = V = W = !1),
                                (fa = null),
                                Ca("firstTouchStart", c),
                                La(na, oa),
                                (ma.x = ma.y = 0),
                                La(jb, c[0]),
                                La(kb, jb),
                                (mb.x = sa.x * qa),
                                (nb = [{ x: jb.x, y: jb.y }]),
                                (P = O = Da()),
                                Ra(s, !0),
                                yb(),
                                zb()),
                            !_ &&
                                d > 1 &&
                                !ea &&
                                !Z &&
                                ((t = s), (W = !1), (_ = V = !0), (ma.y = ma.x = 0), La(na, oa), La(gb, c[0]), La(hb, c[1]), Fb(gb, hb, ub), (tb.x = Math.abs(ub.x) - oa.x), (tb.y = Math.abs(ub.y) - oa.y), (aa = ba = xb(gb, hb)));
                    }
                }
            },
            Ob = function (a) {
                if ((a.preventDefault(), F)) {
                    var b = e.arraySearch(lb, a.pointerId, "id");
                    if (b > -1) {
                        var c = lb[b];
                        (c.x = a.pageX), (c.y = a.pageY);
                    }
                }
                if (U) {
                    var d = Lb(a);
                    if (fa || X || _) $ = d;
                    else if (sb.x !== sa.x * qa) fa = "h";
                    else {
                        var f = Math.abs(d[0].x - jb.x) - Math.abs(d[0].y - jb.y);
                        Math.abs(f) >= fb && ((fa = f > 0 ? "h" : "v"), ($ = d));
                    }
                }
            },
            Pb = function () {
                if ($) {
                    var a = $.length;
                    if (0 !== a)
                        if ((La(gb, $[0]), (ib.x = gb.x - jb.x), (ib.y = gb.y - jb.y), _ && a > 1)) {
                            if (((jb.x = gb.x), (jb.y = gb.y), !ib.x && !ib.y && vb($[1], hb))) return;
                            La(hb, $[1]), W || ((W = !0), Ca("zoomGestureStarted"));
                            var b = xb(gb, hb),
                                c = Ub(b);
                            c > f.currItem.initialZoomLevel + f.currItem.initialZoomLevel / 15 && (ja = !0);
                            var d = 1,
                                e = Sa(),
                                g = Ta();
                            if (c < e)
                                if (i.pinchToClose && !ja && t <= f.currItem.initialZoomLevel) {
                                    var h = e - c,
                                        j = 1 - h / (e / 1.2);
                                    Ea(j), Ca("onPinchClose", j), (ha = !0);
                                } else (d = (e - c) / e), d > 1 && (d = 1), (c = e - d * (e / 3));
                            else c > g && ((d = (c - g) / (6 * e)), d > 1 && (d = 1), (c = g + d * e));
                            d < 0 && (d = 0), (aa = b), Fb(gb, hb, qb), (ma.x += qb.x - ub.x), (ma.y += qb.y - ub.y), La(ub, qb), (oa.x = Ka("x", c)), (oa.y = Ka("y", c)), (R = c > s), (s = c), Ga();
                        } else {
                            if (!fa) return;
                            if ((ga && ((ga = !1), Math.abs(ib.x) >= fb && (ib.x -= $[0].x - kb.x), Math.abs(ib.y) >= fb && (ib.y -= $[0].y - kb.y)), (jb.x = gb.x), (jb.y = gb.y), 0 === ib.x && 0 === ib.y)) return;
                            if ("v" === fa && i.closeOnVerticalDrag && !Ab()) {
                                (ma.y += ib.y), (oa.y += ib.y);
                                var k = Hb();
                                return (S = !0), Ca("onVerticalDrag", k), Ea(k), void Ga();
                            }
                            Gb(Da(), gb.x, gb.y), (X = !0), (ca = f.currItem.bounds);
                            var l = Mb("x", ib);
                            l || (Mb("y", ib), Ma(oa), Ga());
                        }
                }
            },
            Qb = function (a) {
                if (N.isOldAndroid) {
                    if (T && "mouseup" === a.type) return;
                    a.type.indexOf("touch") > -1 &&
                        (clearTimeout(T),
                        (T = setTimeout(function () {
                            T = 0;
                        }, 600)));
                }
                Ca("pointerUp"), Db(a, !1) && a.preventDefault();
                var b;
                if (F) {
                    var c = e.arraySearch(lb, a.pointerId, "id");
                    if (c > -1)
                        if (((b = lb.splice(c, 1)[0]), navigator.pointerEnabled)) b.type = a.pointerType || "mouse";
                        else {
                            var d = { 4: "mouse", 2: "touch", 3: "pen" };
                            (b.type = d[a.pointerType]), b.type || (b.type = a.pointerType || "mouse");
                        }
                }
                var g,
                    h = Lb(a),
                    j = h.length;
                if (("mouseup" === a.type && (j = 0), 2 === j)) return ($ = null), !0;
                1 === j && La(kb, h[0]),
                    0 !== j ||
                        fa ||
                        ea ||
                        (b || ("mouseup" === a.type ? (b = { x: a.pageX, y: a.pageY, type: "mouse" }) : a.changedTouches && a.changedTouches[0] && (b = { x: a.changedTouches[0].pageX, y: a.changedTouches[0].pageY, type: "touch" })),
                        Ca("touchRelease", a, b));
                var k = -1;
                if (
                    (0 === j && ((U = !1), e.unbind(window, p, f), yb(), _ ? (k = 0) : rb !== -1 && (k = Da() - rb)),
                    (rb = 1 === j ? Da() : -1),
                    (g = k !== -1 && k < 150 ? "zoom" : "swipe"),
                    _ && j < 2 && ((_ = !1), 1 === j && (g = "zoomPointerUp"), Ca("zoomGestureEnded")),
                    ($ = null),
                    X || W || ea || S)
                )
                    if ((bb(), Q || (Q = Rb()), Q.calculateSwipeSpeed("x"), S)) {
                        var l = Hb();
                        if (l < i.verticalDragRange) f.close();
                        else {
                            var m = oa.y,
                                n = ia;
                            cb("verticalDrag", 0, 1, 300, e.easing.cubic.out, function (a) {
                                (oa.y = (f.currItem.initialPosition.y - m) * a + m), Ea((1 - n) * a + n), Ga();
                            }),
                                Ca("onVerticalDrag", 1);
                        }
                    } else {
                        if ((Z || ea) && 0 === j) {
                            var o = Tb(g, Q);
                            if (o) return;
                            g = "zoomPointerUp";
                        }
                        if (!ea) return "swipe" !== g ? void Vb() : void (!Z && s > f.currItem.fitRatio && Sb(Q));
                    }
            },
            Rb = function () {
                var a,
                    b,
                    c = {
                        lastFlickOffset: {},
                        lastFlickDist: {},
                        lastFlickSpeed: {},
                        slowDownRatio: {},
                        slowDownRatioReverse: {},
                        speedDecelerationRatio: {},
                        speedDecelerationRatioAbs: {},
                        distanceOffset: {},
                        backAnimDestination: {},
                        backAnimStarted: {},
                        calculateSwipeSpeed: function (d) {
                            nb.length > 1 ? ((a = Da() - P + 50), (b = nb[nb.length - 2][d])) : ((a = Da() - O), (b = kb[d])),
                                (c.lastFlickOffset[d] = jb[d] - b),
                                (c.lastFlickDist[d] = Math.abs(c.lastFlickOffset[d])),
                                c.lastFlickDist[d] > 20 ? (c.lastFlickSpeed[d] = c.lastFlickOffset[d] / a) : (c.lastFlickSpeed[d] = 0),
                                Math.abs(c.lastFlickSpeed[d]) < 0.1 && (c.lastFlickSpeed[d] = 0),
                                (c.slowDownRatio[d] = 0.95),
                                (c.slowDownRatioReverse[d] = 1 - c.slowDownRatio[d]),
                                (c.speedDecelerationRatio[d] = 1);
                        },
                        calculateOverBoundsAnimOffset: function (a, b) {
                            c.backAnimStarted[a] ||
                                (oa[a] > ca.min[a] ? (c.backAnimDestination[a] = ca.min[a]) : oa[a] < ca.max[a] && (c.backAnimDestination[a] = ca.max[a]),
                                void 0 !== c.backAnimDestination[a] &&
                                    ((c.slowDownRatio[a] = 0.7),
                                    (c.slowDownRatioReverse[a] = 1 - c.slowDownRatio[a]),
                                    c.speedDecelerationRatioAbs[a] < 0.05 &&
                                        ((c.lastFlickSpeed[a] = 0),
                                        (c.backAnimStarted[a] = !0),
                                        cb("bounceZoomPan" + a, oa[a], c.backAnimDestination[a], b || 300, e.easing.sine.out, function (b) {
                                            (oa[a] = b), Ga();
                                        }))));
                        },
                        calculateAnimOffset: function (a) {
                            c.backAnimStarted[a] ||
                                ((c.speedDecelerationRatio[a] = c.speedDecelerationRatio[a] * (c.slowDownRatio[a] + c.slowDownRatioReverse[a] - (c.slowDownRatioReverse[a] * c.timeDiff) / 10)),
                                (c.speedDecelerationRatioAbs[a] = Math.abs(c.lastFlickSpeed[a] * c.speedDecelerationRatio[a])),
                                (c.distanceOffset[a] = c.lastFlickSpeed[a] * c.speedDecelerationRatio[a] * c.timeDiff),
                                (oa[a] += c.distanceOffset[a]));
                        },
                        panAnimLoop: function () {
                            if (
                                Za.zoomPan &&
                                ((Za.zoomPan.raf = H(c.panAnimLoop)),
                                (c.now = Da()),
                                (c.timeDiff = c.now - c.lastNow),
                                (c.lastNow = c.now),
                                c.calculateAnimOffset("x"),
                                c.calculateAnimOffset("y"),
                                Ga(),
                                c.calculateOverBoundsAnimOffset("x"),
                                c.calculateOverBoundsAnimOffset("y"),
                                c.speedDecelerationRatioAbs.x < 0.05 && c.speedDecelerationRatioAbs.y < 0.05)
                            )
                                return (oa.x = Math.round(oa.x)), (oa.y = Math.round(oa.y)), Ga(), void _a("zoomPan");
                        },
                    };
                return c;
            },
            Sb = function (a) {
                return (
                    a.calculateSwipeSpeed("y"),
                    (ca = f.currItem.bounds),
                    (a.backAnimDestination = {}),
                    (a.backAnimStarted = {}),
                    Math.abs(a.lastFlickSpeed.x) <= 0.05 && Math.abs(a.lastFlickSpeed.y) <= 0.05
                        ? ((a.speedDecelerationRatioAbs.x = a.speedDecelerationRatioAbs.y = 0), a.calculateOverBoundsAnimOffset("x"), a.calculateOverBoundsAnimOffset("y"), !0)
                        : (ab("zoomPan"), (a.lastNow = Da()), void a.panAnimLoop())
                );
            },
            Tb = function (a, b) {
                var c;
                ea || (pb = m);
                var d;
                if ("swipe" === a) {
                    var g = jb.x - kb.x,
                        h = b.lastFlickDist.x < 10;
                    g > eb && (h || b.lastFlickOffset.x > 20) ? (d = -1) : g < -eb && (h || b.lastFlickOffset.x < -20) && (d = 1);
                }
                var j;
                d && ((m += d), m < 0 ? ((m = i.loop ? _b() - 1 : 0), (j = !0)) : m >= _b() && ((m = i.loop ? 0 : _b() - 1), (j = !0)), (j && !i.loop) || ((ta += d), (qa -= d), (c = !0)));
                var k,
                    l = sa.x * qa,
                    n = Math.abs(l - sb.x);
                return (
                    c || l > sb.x == b.lastFlickSpeed.x > 0 ? ((k = Math.abs(b.lastFlickSpeed.x) > 0 ? n / Math.abs(b.lastFlickSpeed.x) : 333), (k = Math.min(k, 400)), (k = Math.max(k, 250))) : (k = 333),
                    pb === m && (c = !1),
                    (ea = !0),
                    Ca("mainScrollAnimStart"),
                    cb("mainScroll", sb.x, l, k, e.easing.cubic.out, Ja, function () {
                        bb(), (ea = !1), (pb = -1), (c || pb !== m) && f.updateCurrItem(), Ca("mainScrollAnimComplete");
                    }),
                    c && f.updateCurrItem(!0),
                    c
                );
            },
            Ub = function (a) {
                return (1 / ba) * a * t;
            },
            Vb = function () {
                var a = s,
                    b = Sa(),
                    c = Ta();
                s < b ? (a = b) : s > c && (a = c);
                var d,
                    g = 1,
                    h = ia;
                return ha && !R && !ja && s < b
                    ? (f.close(), !0)
                    : (ha &&
                          (d = function (a) {
                              Ea((g - h) * a + h);
                          }),
                      f.zoomTo(a, 0, 200, e.easing.cubic.out, d),
                      !0);
            };
        ya("Gestures", {
            publicMethods: {
                initGestures: function () {
                    var a = function (a, b, c, d, e) {
                        (A = a + b), (B = a + c), (C = a + d), (D = e ? a + e : "");
                    };
                    (F = N.pointerEvent),
                        F && N.touch && (N.touch = !1),
                        F
                            ? navigator.pointerEnabled
                                ? a("pointer", "down", "move", "up", "cancel")
                                : a("MSPointer", "Down", "Move", "Up", "Cancel")
                            : N.touch
                            ? (a("touch", "start", "move", "end", "cancel"), (G = !0))
                            : a("mouse", "down", "move", "up"),
                        (p = B + " " + C + " " + D),
                        (q = A),
                        F && !G && (G = navigator.maxTouchPoints > 1 || navigator.msMaxTouchPoints > 1),
                        (f.likelyTouchDevice = G),
                        (r[A] = Nb),
                        (r[B] = Ob),
                        (r[C] = Qb),
                        D && (r[D] = r[C]),
                        N.touch && ((q += " mousedown"), (p += " mousemove mouseup"), (r.mousedown = r[A]), (r.mousemove = r[B]), (r.mouseup = r[C])),
                        G || (i.allowPanToNext = !1);
                },
            },
        });
        var Wb,
            Xb,
            Yb,
            Zb,
            $b,
            _b,
            ac,
            bc = function (b, c, d, g) {
                Wb && clearTimeout(Wb), (Zb = !0), (Yb = !0);
                var h;
                b.initialLayout ? ((h = b.initialLayout), (b.initialLayout = null)) : (h = i.getThumbBoundsFn && i.getThumbBoundsFn(m));
                var j = d ? i.hideAnimationDuration : i.showAnimationDuration,
                    k = function () {
                        _a("initialZoom"),
                            d ? (f.template.removeAttribute("style"), f.bg.removeAttribute("style")) : (Ea(1), c && (c.style.display = "block"), e.addClass(a, "pswp--animated-in"), Ca("initialZoom" + (d ? "OutEnd" : "InEnd"))),
                            g && g(),
                            (Zb = !1);
                    };
                if (!j || !h || void 0 === h.x)
                    return (
                        Ca("initialZoom" + (d ? "Out" : "In")),
                        (s = b.initialZoomLevel),
                        La(oa, b.initialPosition),
                        Ga(),
                        (a.style.opacity = d ? 0 : 1),
                        Ea(1),
                        void (j
                            ? setTimeout(function () {
                                  k();
                              }, j)
                            : k())
                    );
                var n = function () {
                    var c = l,
                        g = !f.currItem.src || f.currItem.loadError || i.showHideOpacity;
                    b.miniImg && (b.miniImg.style.webkitBackfaceVisibility = "hidden"),
                        d || ((s = h.w / b.w), (oa.x = h.x), (oa.y = h.y - K), (f[g ? "template" : "bg"].style.opacity = 0.001), Ga()),
                        ab("initialZoom"),
                        d && !c && e.removeClass(a, "pswp--animated-in"),
                        g &&
                            (d
                                ? e[(c ? "remove" : "add") + "Class"](a, "pswp--animate_opacity")
                                : setTimeout(function () {
                                      e.addClass(a, "pswp--animate_opacity");
                                  }, 30)),
                        (Wb = setTimeout(
                            function () {
                                if ((Ca("initialZoom" + (d ? "Out" : "In")), d)) {
                                    var f = h.w / b.w,
                                        i = { x: oa.x, y: oa.y },
                                        l = s,
                                        m = ia,
                                        n = function (b) {
                                            1 === b ? ((s = f), (oa.x = h.x), (oa.y = h.y - M)) : ((s = (f - l) * b + l), (oa.x = (h.x - i.x) * b + i.x), (oa.y = (h.y - M - i.y) * b + i.y)),
                                                Ga(),
                                                g ? (a.style.opacity = 1 - b) : Ea(m - b * m);
                                        };
                                    c ? cb("initialZoom", 0, 1, j, e.easing.cubic.out, n, k) : (n(1), (Wb = setTimeout(k, j + 20)));
                                } else (s = b.initialZoomLevel), La(oa, b.initialPosition), Ga(), Ea(1), g ? (a.style.opacity = 1) : Ea(1), (Wb = setTimeout(k, j + 20));
                            },
                            d ? 25 : 90
                        ));
                };
                n();
            },
            cc = {},
            dc = [],
            ec = {
                index: 0,
                errorMsg: '<div class="pswp__error-msg"><a href="%url%" target="_blank">The image</a> could not be loaded.</div>',
                forceProgressiveLoading: !1,
                preload: [1, 1],
                getNumItemsFn: function () {
                    return Xb.length;
                },
            },
            fc = function () {
                return { center: { x: 0, y: 0 }, max: { x: 0, y: 0 }, min: { x: 0, y: 0 } };
            },
            gc = function (a, b, c) {
                var d = a.bounds;
                (d.center.x = Math.round((cc.x - b) / 2)),
                    (d.center.y = Math.round((cc.y - c) / 2) + a.vGap.top),
                    (d.max.x = b > cc.x ? Math.round(cc.x - b) : d.center.x),
                    (d.max.y = c > cc.y ? Math.round(cc.y - c) + a.vGap.top : d.center.y),
                    (d.min.x = b > cc.x ? 0 : d.center.x),
                    (d.min.y = c > cc.y ? a.vGap.top : d.center.y);
            },
            hc = function (a, b, c) {
                if (a.src && !a.loadError) {
                    var d = !c;
                    if ((d && (a.vGap || (a.vGap = { top: 0, bottom: 0 }), Ca("parseVerticalMargin", a)), (cc.x = b.x), (cc.y = b.y - a.vGap.top - a.vGap.bottom), d)) {
                        var e = cc.x / a.w,
                            f = cc.y / a.h;
                        a.fitRatio = e < f ? e : f;
                        var g = i.scaleMode;
                        "orig" === g ? (c = 1) : "fit" === g && (c = a.fitRatio), c > 1 && (c = 1), (a.initialZoomLevel = c), a.bounds || (a.bounds = fc());
                    }
                    if (!c) return;
                    return gc(a, a.w * c, a.h * c), d && c === a.initialZoomLevel && (a.initialPosition = a.bounds.center), a.bounds;
                }
                return (a.w = a.h = 0), (a.initialZoomLevel = a.fitRatio = 1), (a.bounds = fc()), (a.initialPosition = a.bounds.center), a.bounds;
            },
            ic = function (a, b, c, d, e, g) {
                b.loadError ||
                    (d &&
                        ((b.imageAppended = !0),
                        lc(b, d, b === f.currItem && xa),
                        c.appendChild(d),
                        g &&
                            setTimeout(function () {
                                b && b.loaded && b.placeholder && ((b.placeholder.style.display = "none"), (b.placeholder = null));
                            }, 500)));
            },
            jc = function (a) {
                (a.loading = !0), (a.loaded = !1);
                var b = (a.img = e.createEl("pswp__img", "img")),
                    c = function () {
                        (a.loading = !1), (a.loaded = !0), a.loadComplete ? a.loadComplete(a) : (a.img = null), (b.onload = b.onerror = null), (b = null);
                    };
                return (
                    (b.onload = c),
                    (b.onerror = function () {
                        (a.loadError = !0), c();
                    }),
                    (b.src = a.src),
                    b
                );
            },
            kc = function (a, b) {
                if (a.src && a.loadError && a.container) return b && (a.container.innerHTML = ""), (a.container.innerHTML = i.errorMsg.replace("%url%", a.src)), !0;
            },
            lc = function (a, b, c) {
                if (a.src) {
                    b || (b = a.container.lastChild);
                    var d = c ? a.w : Math.round(a.w * a.fitRatio),
                        e = c ? a.h : Math.round(a.h * a.fitRatio);
                    a.placeholder && !a.loaded && ((a.placeholder.style.width = d + "px"), (a.placeholder.style.height = e + "px")), (b.style.width = d + "px"), (b.style.height = e + "px");
                }
            },
            mc = function () {
                if (dc.length) {
                    for (var a, b = 0; b < dc.length; b++) (a = dc[b]), a.holder.index === a.index && ic(a.index, a.item, a.baseDiv, a.img, !1, a.clearPlaceholder);
                    dc = [];
                }
            };
        ya("Controller", {
            publicMethods: {
                lazyLoadItem: function (a) {
                    a = za(a);
                    var b = $b(a);
                    b && ((!b.loaded && !b.loading) || x) && (Ca("gettingData", a, b), b.src && jc(b));
                },
                initController: function () {
                    e.extend(i, ec, !0),
                        (f.items = Xb = c),
                        ($b = f.getItemAt),
                        (_b = i.getNumItemsFn),
                        (ac = i.loop),
                        _b() < 3 && (i.loop = !1),
                        Ba("beforeChange", function (a) {
                            var b,
                                c = i.preload,
                                d = null === a || a >= 0,
                                e = Math.min(c[0], _b()),
                                g = Math.min(c[1], _b());
                            for (b = 1; b <= (d ? g : e); b++) f.lazyLoadItem(m + b);
                            for (b = 1; b <= (d ? e : g); b++) f.lazyLoadItem(m - b);
                        }),
                        Ba("initialLayout", function () {
                            f.currItem.initialLayout = i.getThumbBoundsFn && i.getThumbBoundsFn(m);
                        }),
                        Ba("mainScrollAnimComplete", mc),
                        Ba("initialZoomInEnd", mc),
                        Ba("destroy", function () {
                            for (var a, b = 0; b < Xb.length; b++)
                                (a = Xb[b]), a.container && (a.container = null), a.placeholder && (a.placeholder = null), a.img && (a.img = null), a.preloader && (a.preloader = null), a.loadError && (a.loaded = a.loadError = !1);
                            dc = null;
                        });
                },
                getItemAt: function (a) {
                    return a >= 0 && void 0 !== Xb[a] && Xb[a];
                },
                allowProgressiveImg: function () {
                    return i.forceProgressiveLoading || !G || i.mouseUsed || screen.width > 1200;
                },
                setContent: function (a, b) {
                    i.loop && (b = za(b));
                    var c = f.getItemAt(a.index);
                    c && (c.container = null);
                    var d,
                        g = f.getItemAt(b);
                    if (!g) return void (a.el.innerHTML = "");
                    Ca("gettingData", b, g), (a.index = b), (a.item = g);
                    var h = (g.container = e.createEl("pswp__zoom-wrap"));
                    if ((!g.src && g.html && (g.html.tagName ? h.appendChild(g.html) : (h.innerHTML = g.html)), kc(g), hc(g, pa), !g.src || g.loadError || g.loaded))
                        g.src && !g.loadError && ((d = e.createEl("pswp__img", "img")), (d.style.opacity = 1), (d.src = g.src), lc(g, d), ic(b, g, h, d, !0));
                    else {
                        if (
                            ((g.loadComplete = function (c) {
                                if (j) {
                                    if (a && a.index === b) {
                                        if (kc(c, !0)) return (c.loadComplete = c.img = null), hc(c, pa), Ha(c), void (a.index === m && f.updateCurrZoomItem());
                                        c.imageAppended
                                            ? !Zb && c.placeholder && ((c.placeholder.style.display = "none"), (c.placeholder = null))
                                            : N.transform && (ea || Zb)
                                            ? dc.push({ item: c, baseDiv: h, img: c.img, index: b, holder: a, clearPlaceholder: !0 })
                                            : ic(b, c, h, c.img, ea || Zb, !0);
                                    }
                                    (c.loadComplete = null), (c.img = null), Ca("imageLoadComplete", b, c);
                                }
                            }),
                            e.features.transform)
                        ) {
                            var k = "pswp__img pswp__img--placeholder";
                            k += g.msrc ? "" : " pswp__img--placeholder--blank";
                            var l = e.createEl(k, g.msrc ? "img" : "");
                            g.msrc && (l.src = g.msrc), lc(g, l), h.appendChild(l), (g.placeholder = l);
                        }
                        g.loading || jc(g), f.allowProgressiveImg() && (!Yb && N.transform ? dc.push({ item: g, baseDiv: h, img: g.img, index: b, holder: a }) : ic(b, g, h, g.img, !0, !0));
                    }
                    Yb || b !== m ? Ha(g) : ((da = h.style), bc(g, d || g.img)), (a.el.innerHTML = ""), a.el.appendChild(h);
                },
                cleanSlide: function (a) {
                    a.img && (a.img.onload = a.img.onerror = null), (a.loaded = a.loading = a.img = a.imageAppended = !1);
                },
            },
        });
        var nc,
            oc = {},
            pc = function (a, b, c) {
                var d = document.createEvent("CustomEvent"),
                    e = { origEvent: a, target: a.target, releasePoint: b, pointerType: c || "touch" };
                d.initCustomEvent("pswpTap", !0, !0, e), a.target.dispatchEvent(d);
            };
        ya("Tap", {
            publicMethods: {
                initTap: function () {
                    Ba("firstTouchStart", f.onTapStart),
                        Ba("touchRelease", f.onTapRelease),
                        Ba("destroy", function () {
                            (oc = {}), (nc = null);
                        });
                },
                onTapStart: function (a) {
                    a.length > 1 && (clearTimeout(nc), (nc = null));
                },
                onTapRelease: function (a, b) {
                    if (b && !X && !V && !$a) {
                        var c = b;
                        if (nc && (clearTimeout(nc), (nc = null), wb(c, oc))) return void Ca("doubleTap", c);
                        if ("mouse" === b.type) return void pc(a, b, "mouse");
                        var d = a.target.tagName.toUpperCase();
                        if ("BUTTON" === d || e.hasClass(a.target, "pswp__single-tap")) return void pc(a, b);
                        La(oc, c),
                            (nc = setTimeout(function () {
                                pc(a, b), (nc = null);
                            }, 300));
                    }
                },
            },
        });
        var qc;
        ya("DesktopZoom", {
            publicMethods: {
                initDesktopZoom: function () {
                    L ||
                        (G
                            ? Ba("mouseUsed", function () {
                                  f.setupDesktopZoom();
                              })
                            : f.setupDesktopZoom(!0));
                },
                setupDesktopZoom: function (b) {
                    qc = {};
                    var c = "wheel mousewheel DOMMouseScroll";
                    Ba("bindEvents", function () {
                        e.bind(a, c, f.handleMouseWheel);
                    }),
                        Ba("unbindEvents", function () {
                            qc && e.unbind(a, c, f.handleMouseWheel);
                        }),
                        (f.mouseZoomedIn = !1);
                    var d,
                        g = function () {
                            f.mouseZoomedIn && (e.removeClass(a, "pswp--zoomed-in"), (f.mouseZoomedIn = !1)), s < 1 ? e.addClass(a, "pswp--zoom-allowed") : e.removeClass(a, "pswp--zoom-allowed"), h();
                        },
                        h = function () {
                            d && (e.removeClass(a, "pswp--dragging"), (d = !1));
                        };
                    Ba("resize", g),
                        Ba("afterChange", g),
                        Ba("pointerDown", function () {
                            f.mouseZoomedIn && ((d = !0), e.addClass(a, "pswp--dragging"));
                        }),
                        Ba("pointerUp", h),
                        b || g();
                },
                handleMouseWheel: function (a) {
                    if (s <= f.currItem.fitRatio) return i.modal && (!i.closeOnScroll || $a || U ? a.preventDefault() : E && Math.abs(a.deltaY) > 2 && ((l = !0), f.close())), !0;
                    if ((a.stopPropagation(), (qc.x = 0), "deltaX" in a)) 1 === a.deltaMode ? ((qc.x = 18 * a.deltaX), (qc.y = 18 * a.deltaY)) : ((qc.x = a.deltaX), (qc.y = a.deltaY));
                    else if ("wheelDelta" in a) a.wheelDeltaX && (qc.x = -0.16 * a.wheelDeltaX), a.wheelDeltaY ? (qc.y = -0.16 * a.wheelDeltaY) : (qc.y = -0.16 * a.wheelDelta);
                    else {
                        if (!("detail" in a)) return;
                        qc.y = a.detail;
                    }
                    Ra(s, !0);
                    var b = oa.x - qc.x,
                        c = oa.y - qc.y;
                    (i.modal || (b <= ca.min.x && b >= ca.max.x && c <= ca.min.y && c >= ca.max.y)) && a.preventDefault(), f.panTo(b, c);
                },
                toggleDesktopZoom: function (b) {
                    b = b || { x: pa.x / 2 + ra.x, y: pa.y / 2 + ra.y };
                    var c = i.getDoubleTapZoom(!0, f.currItem),
                        d = s === c;
                    (f.mouseZoomedIn = !d), f.zoomTo(d ? f.currItem.initialZoomLevel : c, b, 333), e[(d ? "remove" : "add") + "Class"](a, "pswp--zoomed-in");
                },
            },
        });
        var rc,
            sc,
            tc,
            uc,
            vc,
            wc,
            xc,
            yc,
            zc,
            Ac,
            Bc,
            Cc,
            Dc = { history: !0, galleryUID: 1 },
            Ec = function () {
                return Bc.hash.substring(1);
            },
            Fc = function () {
                rc && clearTimeout(rc), tc && clearTimeout(tc);
            },
            Gc = function () {
                var a = Ec(),
                    b = {};
                if (a.length < 5) return b;
                var c,
                    d = a.split("&");
                for (c = 0; c < d.length; c++)
                    if (d[c]) {
                        var e = d[c].split("=");
                        e.length < 2 || (b[e[0]] = e[1]);
                    }
                if (i.galleryPIDs) {
                    var f = b.pid;
                    for (b.pid = 0, c = 0; c < Xb.length; c++)
                        if (Xb[c].pid === f) {
                            b.pid = c;
                            break;
                        }
                } else b.pid = parseInt(b.pid, 10) - 1;
                return b.pid < 0 && (b.pid = 0), b;
            },
            Hc = function () {
                if ((tc && clearTimeout(tc), $a || U)) return void (tc = setTimeout(Hc, 500));
                uc ? clearTimeout(sc) : (uc = !0);
                var a = m + 1,
                    b = $b(m);
                b.hasOwnProperty("pid") && (a = b.pid);
                var c = xc + "&gid=" + i.galleryUID + "&pid=" + a;
                yc || (Bc.hash.indexOf(c) === -1 && (Ac = !0));
                var d = Bc.href.split("#")[0] + "#" + c;
                Cc ? "#" + c !== window.location.hash && history[yc ? "replaceState" : "pushState"]("", document.title, d) : yc ? Bc.replace(d) : (Bc.hash = c),
                    (yc = !0),
                    (sc = setTimeout(function () {
                        uc = !1;
                    }, 60));
            };
        ya("History", {
            publicMethods: {
                initHistory: function () {
                    if ((e.extend(i, Dc, !0), i.history)) {
                        (Bc = window.location),
                            (Ac = !1),
                            (zc = !1),
                            (yc = !1),
                            (xc = Ec()),
                            (Cc = "pushState" in history),
                            xc.indexOf("gid=") > -1 && ((xc = xc.split("&gid=")[0]), (xc = xc.split("?gid=")[0])),
                            Ba("afterChange", f.updateURL),
                            Ba("unbindEvents", function () {
                                e.unbind(window, "hashchange", f.onHashChange);
                            });
                        var a = function () {
                            (wc = !0), zc || (Ac ? history.back() : xc ? (Bc.hash = xc) : Cc ? history.pushState("", document.title, Bc.pathname + Bc.search) : (Bc.hash = "")), Fc();
                        };
                        Ba("unbindEvents", function () {
                            l && a();
                        }),
                            Ba("destroy", function () {
                                wc || a();
                            }),
                            Ba("firstUpdate", function () {
                                m = Gc().pid;
                            });
                        var b = xc.indexOf("pid=");
                        b > -1 && ((xc = xc.substring(0, b)), "&" === xc.slice(-1) && (xc = xc.slice(0, -1))),
                            setTimeout(function () {
                                j && e.bind(window, "hashchange", f.onHashChange);
                            }, 40);
                    }
                },
                onHashChange: function () {
                    return Ec() === xc ? ((zc = !0), void f.close()) : void (uc || ((vc = !0), f.goTo(Gc().pid), (vc = !1)));
                },
                updateURL: function () {
                    Fc(), vc || (yc ? (rc = setTimeout(Hc, 800)) : Hc());
                },
            },
        }),
            e.extend(f, db);
    };
    return a;
});
/*! PhotoSwipe Default UI - 4.1.1 - 2015-12-24
 * http://photoswipe.com
 * Copyright (c) 2015 Dmitry Semenov; */
!(function (a, b) {
    "function" == typeof define && define.amd ? define(b) : "object" == typeof exports ? (module.exports = b()) : (a.PhotoSwipeUI_Default = b());
})(this, function () {
    "use strict";
    var a = function (a, b) {
        var c,
            d,
            e,
            f,
            g,
            h,
            i,
            j,
            k,
            l,
            m,
            n,
            o,
            p,
            q,
            r,
            s,
            t,
            u,
            v = this,
            w = !1,
            x = !0,
            y = !0,
            z = {
                barsSize: { top: 44, bottom: "auto" },
                closeElClasses: ["item", "caption", "zoom-wrap", "ui", "top-bar"],
                timeToIdle: 4e3,
                timeToIdleOutside: 1e3,
                loadingIndicatorDelay: 1e3,
                addCaptionHTMLFn: function (a, b) {
                    return a.title ? ((b.children[0].innerHTML = a.title), !0) : ((b.children[0].innerHTML = ""), !1);
                },
                closeEl: !0,
                captionEl: !0,
                fullscreenEl: !0,
                zoomEl: !0,
                shareEl: !0,
                counterEl: !0,
                arrowEl: !0,
                preloaderEl: !0,
                tapToClose: !1,
                tapToToggleControls: !0,
                clickToCloseNonZoomable: !0,
                shareButtons: [
                    { id: "facebook", label: "Share on Facebook", url: "https://www.facebook.com/sharer/sharer.php?u={{url}}" },
                    { id: "twitter", label: "Tweet", url: "https://twitter.com/intent/tweet?text={{text}}&url={{url}}" },
                    { id: "pinterest", label: "Pin it", url: "http://www.pinterest.com/pin/create/button/?url={{url}}&media={{image_url}}&description={{text}}" },
                    { id: "download", label: "Download image", url: "{{raw_image_url}}", download: !0 },
                ],
                getImageURLForShare: function () {
                    return a.currItem.src || "";
                },
                getPageURLForShare: function () {
                    return window.location.href;
                },
                getTextForShare: function () {
                    return a.currItem.title || "";
                },
                indexIndicatorSep: " / ",
                fitControlsWidth: 1200,
            },
            A = function (a) {
                if (r) return !0;
                (a = a || window.event), q.timeToIdle && q.mouseUsed && !k && K();
                for (var c, d, e = a.target || a.srcElement, f = e.getAttribute("class") || "", g = 0; g < S.length; g++) (c = S[g]), c.onTap && f.indexOf("pswp__" + c.name) > -1 && (c.onTap(), (d = !0));
                if (d) {
                    a.stopPropagation && a.stopPropagation(), (r = !0);
                    var h = b.features.isOldAndroid ? 600 : 30;
                    s = setTimeout(function () {
                        r = !1;
                    }, h);
                }
            },
            B = function () {
                return !a.likelyTouchDevice || q.mouseUsed || screen.width > q.fitControlsWidth;
            },
            C = function (a, c, d) {
                b[(d ? "add" : "remove") + "Class"](a, "pswp__" + c);
            },
            D = function () {
                var a = 1 === q.getNumItemsFn();
                a !== p && (C(d, "ui--one-slide", a), (p = a));
            },
            E = function () {
                C(i, "share-modal--hidden", y);
            },
            F = function () {
                return (
                    (y = !y),
                    y
                        ? (b.removeClass(i, "pswp__share-modal--fade-in"),
                          setTimeout(function () {
                              y && E();
                          }, 300))
                        : (E(),
                          setTimeout(function () {
                              y || b.addClass(i, "pswp__share-modal--fade-in");
                          }, 30)),
                    y || H(),
                    !1
                );
            },
            G = function (b) {
                b = b || window.event;
                var c = b.target || b.srcElement;
                return (
                    a.shout("shareLinkClick", b, c),
                    !!c.href &&
                        (!!c.hasAttribute("download") ||
                            (window.open(c.href, "pswp_share", "scrollbars=yes,resizable=yes,toolbar=no,location=yes,width=550,height=420,top=100,left=" + (window.screen ? Math.round(screen.width / 2 - 275) : 100)), y || F(), !1))
                );
            },
            H = function () {
                for (var a, b, c, d, e, f = "", g = 0; g < q.shareButtons.length; g++)
                    (a = q.shareButtons[g]),
                        (c = q.getImageURLForShare(a)),
                        (d = q.getPageURLForShare(a)),
                        (e = q.getTextForShare(a)),
                        (b = a.url.replace("{{url}}", encodeURIComponent(d)).replace("{{image_url}}", encodeURIComponent(c)).replace("{{raw_image_url}}", c).replace("{{text}}", encodeURIComponent(e))),
                        (f += '<a href="' + b + '" target="_blank" class="pswp__share--' + a.id + '"' + (a.download ? "download" : "") + ">" + a.label + "</a>"),
                        q.parseShareButtonOut && (f = q.parseShareButtonOut(a, f));
                (i.children[0].innerHTML = f), (i.children[0].onclick = G);
            },
            I = function (a) {
                for (var c = 0; c < q.closeElClasses.length; c++) if (b.hasClass(a, "pswp__" + q.closeElClasses[c])) return !0;
            },
            J = 0,
            K = function () {
                clearTimeout(u), (J = 0), k && v.setIdle(!1);
            },
            L = function (a) {
                a = a ? a : window.event;
                var b = a.relatedTarget || a.toElement;
                (b && "HTML" !== b.nodeName) ||
                    (clearTimeout(u),
                    (u = setTimeout(function () {
                        v.setIdle(!0);
                    }, q.timeToIdleOutside)));
            },
            M = function () {
                q.fullscreenEl &&
                    !b.features.isOldAndroid &&
                    (c || (c = v.getFullscreenAPI()), c ? (b.bind(document, c.eventK, v.updateFullscreen), v.updateFullscreen(), b.addClass(a.template, "pswp--supports-fs")) : b.removeClass(a.template, "pswp--supports-fs"));
            },
            N = function () {
                q.preloaderEl &&
                    (O(!0),
                    l("beforeChange", function () {
                        clearTimeout(o),
                            (o = setTimeout(function () {
                                a.currItem && a.currItem.loading ? (!a.allowProgressiveImg() || (a.currItem.img && !a.currItem.img.naturalWidth)) && O(!1) : O(!0);
                            }, q.loadingIndicatorDelay));
                    }),
                    l("imageLoadComplete", function (b, c) {
                        a.currItem === c && O(!0);
                    }));
            },
            O = function (a) {
                n !== a && (C(m, "preloader--active", !a), (n = a));
            },
            P = function (a) {
                var c = a.vGap;
                if (B()) {
                    var g = q.barsSize;
                    if (q.captionEl && "auto" === g.bottom)
                        if ((f || ((f = b.createEl("pswp__caption pswp__caption--fake")), f.appendChild(b.createEl("pswp__caption__center")), d.insertBefore(f, e), b.addClass(d, "pswp__ui--fit")), q.addCaptionHTMLFn(a, f, !0))) {
                            var h = f.clientHeight;
                            c.bottom = parseInt(h, 10) || 44;
                        } else c.bottom = g.top;
                    else c.bottom = "auto" === g.bottom ? 0 : g.bottom;
                    c.top = g.top;
                } else c.top = c.bottom = 0;
            },
            Q = function () {
                q.timeToIdle &&
                    l("mouseUsed", function () {
                        b.bind(document, "mousemove", K),
                            b.bind(document, "mouseout", L),
                            (t = setInterval(function () {
                                J++, 2 === J && v.setIdle(!0);
                            }, q.timeToIdle / 2));
                    });
            },
            R = function () {
                l("onVerticalDrag", function (a) {
                    x && a < 0.95 ? v.hideControls() : !x && a >= 0.95 && v.showControls();
                });
                var a;
                l("onPinchClose", function (b) {
                    x && b < 0.9 ? (v.hideControls(), (a = !0)) : a && !x && b > 0.9 && v.showControls();
                }),
                    l("zoomGestureEnded", function () {
                        (a = !1), a && !x && v.showControls();
                    });
            },
            S = [
                {
                    name: "caption",
                    option: "captionEl",
                    onInit: function (a) {
                        e = a;
                    },
                },
                {
                    name: "share-modal",
                    option: "shareEl",
                    onInit: function (a) {
                        i = a;
                    },
                    onTap: function () {
                        F();
                    },
                },
                {
                    name: "button--share",
                    option: "shareEl",
                    onInit: function (a) {
                        h = a;
                    },
                    onTap: function () {
                        F();
                    },
                },
                { name: "button--zoom", option: "zoomEl", onTap: a.toggleDesktopZoom },
                {
                    name: "counter",
                    option: "counterEl",
                    onInit: function (a) {
                        g = a;
                    },
                },
                { name: "button--close", option: "closeEl", onTap: a.close },
                { name: "button--arrow--left", option: "arrowEl", onTap: a.prev },
                { name: "button--arrow--right", option: "arrowEl", onTap: a.next },
                {
                    name: "button--fs",
                    option: "fullscreenEl",
                    onTap: function () {
                        c.isFullscreen() ? c.exit() : c.enter();
                    },
                },
                {
                    name: "preloader",
                    option: "preloaderEl",
                    onInit: function (a) {
                        m = a;
                    },
                },
            ],
            T = function () {
                var a,
                    c,
                    e,
                    f = function (d) {
                        if (d)
                            for (var f = d.length, g = 0; g < f; g++) {
                                (a = d[g]), (c = a.className);
                                for (var h = 0; h < S.length; h++)
                                    (e = S[h]), c.indexOf("pswp__" + e.name) > -1 && (q[e.option] ? (b.removeClass(a, "pswp__element--disabled"), e.onInit && e.onInit(a)) : b.addClass(a, "pswp__element--disabled"));
                            }
                    };
                f(d.children);
                var g = b.getChildByClass(d, "pswp__top-bar");
                g && f(g.children);
            };
        (v.init = function () {
            b.extend(a.options, z, !0),
                (q = a.options),
                (d = b.getChildByClass(a.scrollWrap, "pswp__ui")),
                (l = a.listen),
                R(),
                l("beforeChange", v.update),
                l("doubleTap", function (b) {
                    var c = a.currItem.initialZoomLevel;
                    a.getZoomLevel() !== c ? a.zoomTo(c, b, 333) : a.zoomTo(q.getDoubleTapZoom(!1, a.currItem), b, 333);
                }),
                l("preventDragEvent", function (a, b, c) {
                    var d = a.target || a.srcElement;
                    d && d.getAttribute("class") && a.type.indexOf("mouse") > -1 && (d.getAttribute("class").indexOf("__caption") > 0 || /(SMALL|STRONG|EM)/i.test(d.tagName)) && (c.prevent = !1);
                }),
                l("bindEvents", function () {
                    b.bind(d, "pswpTap click", A), b.bind(a.scrollWrap, "pswpTap", v.onGlobalTap), a.likelyTouchDevice || b.bind(a.scrollWrap, "mouseover", v.onMouseOver);
                }),
                l("unbindEvents", function () {
                    y || F(),
                        t && clearInterval(t),
                        b.unbind(document, "mouseout", L),
                        b.unbind(document, "mousemove", K),
                        b.unbind(d, "pswpTap click", A),
                        b.unbind(a.scrollWrap, "pswpTap", v.onGlobalTap),
                        b.unbind(a.scrollWrap, "mouseover", v.onMouseOver),
                        c && (b.unbind(document, c.eventK, v.updateFullscreen), c.isFullscreen() && ((q.hideAnimationDuration = 0), c.exit()), (c = null));
                }),
                l("destroy", function () {
                    q.captionEl && (f && d.removeChild(f), b.removeClass(e, "pswp__caption--empty")), i && (i.children[0].onclick = null), b.removeClass(d, "pswp__ui--over-close"), b.addClass(d, "pswp__ui--hidden"), v.setIdle(!1);
                }),
                q.showAnimationDuration || b.removeClass(d, "pswp__ui--hidden"),
                l("initialZoomIn", function () {
                    q.showAnimationDuration && b.removeClass(d, "pswp__ui--hidden");
                }),
                l("initialZoomOut", function () {
                    b.addClass(d, "pswp__ui--hidden");
                }),
                l("parseVerticalMargin", P),
                T(),
                q.shareEl && h && i && (y = !0),
                D(),
                Q(),
                M(),
                N();
        }),
            (v.setIdle = function (a) {
                (k = a), C(d, "ui--idle", a);
            }),
            (v.update = function () {
                x && a.currItem ? (v.updateIndexIndicator(), q.captionEl && (q.addCaptionHTMLFn(a.currItem, e), C(e, "caption--empty", !a.currItem.title)), (w = !0)) : (w = !1), y || F(), D();
            }),
            (v.updateFullscreen = function (d) {
                d &&
                    setTimeout(function () {
                        a.setScrollOffset(0, b.getScrollY());
                    }, 50),
                    b[(c.isFullscreen() ? "add" : "remove") + "Class"](a.template, "pswp--fs");
            }),
            (v.updateIndexIndicator = function () {
                q.counterEl && (g.innerHTML = a.getCurrentIndex() + 1 + q.indexIndicatorSep + q.getNumItemsFn());
            }),
            (v.onGlobalTap = function (c) {
                c = c || window.event;
                var d = c.target || c.srcElement;
                if (!r)
                    if (c.detail && "mouse" === c.detail.pointerType) {
                        if (I(d)) return void a.close();
                        b.hasClass(d, "pswp__img") && (1 === a.getZoomLevel() && a.getZoomLevel() <= a.currItem.fitRatio ? q.clickToCloseNonZoomable && a.close() : a.toggleDesktopZoom(c.detail.releasePoint));
                    } else if ((q.tapToToggleControls && (x ? v.hideControls() : v.showControls()), q.tapToClose && (b.hasClass(d, "pswp__img") || I(d)))) return void a.close();
            }),
            (v.onMouseOver = function (a) {
                a = a || window.event;
                var b = a.target || a.srcElement;
                C(d, "ui--over-close", I(b));
            }),
            (v.hideControls = function () {
                b.addClass(d, "pswp__ui--hidden"), (x = !1);
            }),
            (v.showControls = function () {
                (x = !0), w || v.update(), b.removeClass(d, "pswp__ui--hidden");
            }),
            (v.supportsFullscreen = function () {
                var a = document;
                return !!(a.exitFullscreen || a.mozCancelFullScreen || a.webkitExitFullscreen || a.msExitFullscreen);
            }),
            (v.getFullscreenAPI = function () {
                var b,
                    c = document.documentElement,
                    d = "fullscreenchange";
                return (
                    c.requestFullscreen
                        ? (b = { enterK: "requestFullscreen", exitK: "exitFullscreen", elementK: "fullscreenElement", eventK: d })
                        : c.mozRequestFullScreen
                        ? (b = { enterK: "mozRequestFullScreen", exitK: "mozCancelFullScreen", elementK: "mozFullScreenElement", eventK: "moz" + d })
                        : c.webkitRequestFullscreen
                        ? (b = { enterK: "webkitRequestFullscreen", exitK: "webkitExitFullscreen", elementK: "webkitFullscreenElement", eventK: "webkit" + d })
                        : c.msRequestFullscreen && (b = { enterK: "msRequestFullscreen", exitK: "msExitFullscreen", elementK: "msFullscreenElement", eventK: "MSFullscreenChange" }),
                    b &&
                        ((b.enter = function () {
                            return (j = q.closeOnScroll), (q.closeOnScroll = !1), "webkitRequestFullscreen" !== this.enterK ? a.template[this.enterK]() : void a.template[this.enterK](Element.ALLOW_KEYBOARD_INPUT);
                        }),
                        (b.exit = function () {
                            return (q.closeOnScroll = j), document[this.exitK]();
                        }),
                        (b.isFullscreen = function () {
                            return document[this.elementK];
                        })),
                    b
                );
            });
    };
    return a;
});
/*
 2017 Julian Garnier
 Released under the MIT license
*/
var $jscomp$this = this;
(function (v, p) {
    "function" === typeof define && define.amd ? define([], p) : "object" === typeof module && module.exports ? (module.exports = p()) : (v.anime = p());
})(this, function () {
    function v(a) {
        if (!g.col(a))
            try {
                return document.querySelectorAll(a);
            } catch (b) {}
    }
    function p(a) {
        return a.reduce(function (a, d) {
            return a.concat(g.arr(d) ? p(d) : d);
        }, []);
    }
    function w(a) {
        if (g.arr(a)) return a;
        g.str(a) && (a = v(a) || a);
        return a instanceof NodeList || a instanceof HTMLCollection ? [].slice.call(a) : [a];
    }
    function F(a, b) {
        return a.some(function (a) {
            return a === b;
        });
    }
    function A(a) {
        var b = {},
            d;
        for (d in a) b[d] = a[d];
        return b;
    }
    function G(a, b) {
        var d = A(a),
            c;
        for (c in a) d[c] = b.hasOwnProperty(c) ? b[c] : a[c];
        return d;
    }
    function B(a, b) {
        var d = A(a),
            c;
        for (c in b) d[c] = g.und(a[c]) ? b[c] : a[c];
        return d;
    }
    function S(a) {
        a = a.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function (a, b, d, h) {
            return b + b + d + d + h + h;
        });
        var b = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(a);
        a = parseInt(b[1], 16);
        var d = parseInt(b[2], 16),
            b = parseInt(b[3], 16);
        return "rgb(" + a + "," + d + "," + b + ")";
    }
    function T(a) {
        function b(a, b, c) {
            0 > c && (c += 1);
            1 < c && --c;
            return c < 1 / 6 ? a + 6 * (b - a) * c : 0.5 > c ? b : c < 2 / 3 ? a + (b - a) * (2 / 3 - c) * 6 : a;
        }
        var d = /hsl\((\d+),\s*([\d.]+)%,\s*([\d.]+)%\)/g.exec(a);
        a = parseInt(d[1]) / 360;
        var c = parseInt(d[2]) / 100,
            d = parseInt(d[3]) / 100;
        if (0 == c) c = d = a = d;
        else {
            var e = 0.5 > d ? d * (1 + c) : d + c - d * c,
                l = 2 * d - e,
                c = b(l, e, a + 1 / 3),
                d = b(l, e, a);
            a = b(l, e, a - 1 / 3);
        }
        return "rgb(" + 255 * c + "," + 255 * d + "," + 255 * a + ")";
    }
    function x(a) {
        if ((a = /([\+\-]?[0-9#\.]+)(%|px|pt|em|rem|in|cm|mm|ex|pc|vw|vh|deg|rad|turn)?/.exec(a))) return a[2];
    }
    function U(a) {
        if (-1 < a.indexOf("translate")) return "px";
        if (-1 < a.indexOf("rotate") || -1 < a.indexOf("skew")) return "deg";
    }
    function H(a, b) {
        return g.fnc(a) ? a(b.target, b.id, b.total) : a;
    }
    function C(a, b) {
        if (b in a.style) return getComputedStyle(a).getPropertyValue(b.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()) || "0";
    }
    function I(a, b) {
        if (g.dom(a) && F(V, b)) return "transform";
        if (g.dom(a) && (a.getAttribute(b) || (g.svg(a) && a[b]))) return "attribute";
        if (g.dom(a) && "transform" !== b && C(a, b)) return "css";
        if (null != a[b]) return "object";
    }
    function W(a, b) {
        var d = U(b),
            d = -1 < b.indexOf("scale") ? 1 : 0 + d;
        a = a.style.transform;
        if (!a) return d;
        for (var c = [], e = [], l = [], h = /(\w+)\((.+?)\)/g; (c = h.exec(a)); ) e.push(c[1]), l.push(c[2]);
        a = l.filter(function (a, c) {
            return e[c] === b;
        });
        return a.length ? a[0] : d;
    }
    function J(a, b) {
        switch (I(a, b)) {
            case "transform":
                return W(a, b);
            case "css":
                return C(a, b);
            case "attribute":
                return a.getAttribute(b);
        }
        return a[b] || 0;
    }
    function K(a, b) {
        var d = /^(\*=|\+=|-=)/.exec(a);
        if (!d) return a;
        b = parseFloat(b);
        a = parseFloat(a.replace(d[0], ""));
        switch (d[0][0]) {
            case "+":
                return b + a;
            case "-":
                return b - a;
            case "*":
                return b * a;
        }
    }
    function D(a) {
        return g.obj(a) && a.hasOwnProperty("totalLength");
    }
    function X(a, b) {
        function d(c) {
            c = void 0 === c ? 0 : c;
            return a.el.getPointAtLength(1 <= b + c ? b + c : 0);
        }
        var c = d(),
            e = d(-1),
            l = d(1);
        switch (a.property) {
            case "x":
                return c.x;
            case "y":
                return c.y;
            case "angle":
                return (180 * Math.atan2(l.y - e.y, l.x - e.x)) / Math.PI;
        }
    }
    function L(a, b) {
        var d = /-?\d*\.?\d+/g;
        a = D(a) ? a.totalLength : a;
        if (g.col(a)) b = g.rgb(a) ? a : g.hex(a) ? S(a) : g.hsl(a) ? T(a) : void 0;
        else {
            var c = x(a);
            a = c ? a.substr(0, a.length - c.length) : a;
            b = b ? a + b : a;
        }
        b += "";
        return { original: b, numbers: b.match(d) ? b.match(d).map(Number) : [0], strings: b.split(d) };
    }
    function Y(a, b) {
        return b.reduce(function (b, c, e) {
            return b + a[e - 1] + c;
        });
    }
    function M(a) {
        return (a ? p(g.arr(a) ? a.map(w) : w(a)) : []).filter(function (a, d, c) {
            return c.indexOf(a) === d;
        });
    }
    function Z(a) {
        var b = M(a);
        return b.map(function (a, c) {
            return { target: a, id: c, total: b.length };
        });
    }
    function aa(a, b) {
        var d = A(b);
        if (g.arr(a)) {
            var c = a.length;
            2 !== c || g.obj(a[0]) ? g.fnc(b.duration) || (d.duration = b.duration / c) : (a = { value: a });
        }
        return w(a)
            .map(function (a, c) {
                c = c ? 0 : b.delay;
                a = g.obj(a) && !D(a) ? a : { value: a };
                g.und(a.delay) && (a.delay = c);
                return a;
            })
            .map(function (a) {
                return B(a, d);
            });
    }
    function ba(a, b) {
        var d = {},
            c;
        for (c in a) {
            var e = H(a[c], b);
            g.arr(e) &&
                ((e = e.map(function (a) {
                    return H(a, b);
                })),
                1 === e.length && (e = e[0]));
            d[c] = e;
        }
        d.duration = parseFloat(d.duration);
        d.delay = parseFloat(d.delay);
        return d;
    }
    function ca(a) {
        return g.arr(a) ? y.apply(this, a) : N[a];
    }
    function da(a, b) {
        var d;
        return a.tweens.map(function (c) {
            c = ba(c, b);
            var e = c.value,
                l = J(b.target, a.name),
                h = d ? d.to.original : l,
                h = g.arr(e) ? e[0] : h,
                m = K(g.arr(e) ? e[1] : e, h),
                l = x(m) || x(h) || x(l);
            c.isPath = D(e);
            c.from = L(h, l);
            c.to = L(m, l);
            c.start = d ? d.end : a.offset;
            c.end = c.start + c.delay + c.duration;
            c.easing = ca(c.easing);
            c.elasticity = (1e3 - Math.min(Math.max(c.elasticity, 1), 999)) / 1e3;
            g.col(c.from.original) && (c.round = 1);
            return (d = c);
        });
    }
    function ea(a, b) {
        return p(
            a.map(function (a) {
                return b.map(function (b) {
                    var c = I(a.target, b.name);
                    if (c) {
                        var d = da(b, a);
                        b = { type: c, property: b.name, animatable: a, tweens: d, duration: d[d.length - 1].end, delay: d[0].delay };
                    } else b = void 0;
                    return b;
                });
            })
        ).filter(function (a) {
            return !g.und(a);
        });
    }
    function O(a, b, d) {
        var c = "delay" === a ? Math.min : Math.max;
        return b.length
            ? c.apply(
                  Math,
                  b.map(function (b) {
                      return b[a];
                  })
              )
            : d[a];
    }
    function fa(a) {
        var b = G(ga, a),
            d = G(ha, a),
            c = Z(a.targets),
            e = [],
            g = B(b, d),
            h;
        for (h in a) g.hasOwnProperty(h) || "targets" === h || e.push({ name: h, offset: g.offset, tweens: aa(a[h], d) });
        a = ea(c, e);
        return B(b, { children: [], animatables: c, animations: a, duration: O("duration", a, d), delay: O("delay", a, d) });
    }
    function n(a) {
        function b() {
            return (
                window.Promise &&
                new Promise(function (a) {
                    return (Q = a);
                })
            );
        }
        function d(a) {
            return f.reversed ? f.duration - a : a;
        }
        function c(a) {
            for (var b = 0, c = {}, d = f.animations, e = {}; b < d.length; ) {
                var g = d[b],
                    h = g.animatable,
                    m = g.tweens;
                e.tween =
                    m.filter(function (b) {
                        return a < b.end;
                    })[0] || m[m.length - 1];
                e.isPath$1 = e.tween.isPath;
                e.round = e.tween.round;
                e.eased = e.tween.easing(Math.min(Math.max(a - e.tween.start - e.tween.delay, 0), e.tween.duration) / e.tween.duration, e.tween.elasticity);
                m = Y(
                    e.tween.to.numbers.map(
                        (function (a) {
                            return function (b, c) {
                                c = a.isPath$1 ? 0 : a.tween.from.numbers[c];
                                b = c + a.eased * (b - c);
                                a.isPath$1 && (b = X(a.tween.value, b));
                                a.round && (b = Math.round(b * a.round) / a.round);
                                return b;
                            };
                        })(e)
                    ),
                    e.tween.to.strings
                );
                ia[g.type](h.target, g.property, m, c, h.id);
                g.currentValue = m;
                b++;
                e = { isPath$1: e.isPath$1, tween: e.tween, eased: e.eased, round: e.round };
            }
            if (c) for (var k in c) E || (E = C(document.body, "transform") ? "transform" : "-webkit-transform"), (f.animatables[k].target.style[E] = c[k].join(" "));
            f.currentTime = a;
            f.progress = (a / f.duration) * 100;
        }
        function e(a) {
            if (f[a]) f[a](f);
        }
        function g() {
            f.remaining && !0 !== f.remaining && f.remaining--;
        }
        function h(a) {
            var h = f.duration,
                l = f.offset,
                n = f.delay,
                P = f.currentTime,
                q = f.reversed,
                r = d(a),
                r = Math.min(Math.max(r, 0), h);
            if (f.children) {
                var p = f.children;
                if (r >= f.currentTime) for (var u = 0; u < p.length; u++) p[u].seek(r);
                else for (u = p.length; u--; ) p[u].seek(r);
            }
            r > l && r < h ? (c(r), !f.began && r >= n && ((f.began = !0), e("begin")), e("run")) : (r <= l && 0 !== P && (c(0), q && g()), r >= h && P !== h && (c(h), q || g()));
            a >= h && (f.remaining ? ((t = m), "alternate" === f.direction && (f.reversed = !f.reversed)) : (f.pause(), "Promise" in window && (Q(), (R = b())), f.completed || ((f.completed = !0), e("complete"))), (k = 0));
            e("update");
        }
        a = void 0 === a ? {} : a;
        var m,
            t,
            k = 0,
            Q = null,
            R = b(),
            f = fa(a);
        f.reset = function () {
            var a = f.direction,
                b = f.loop;
            f.currentTime = 0;
            f.progress = 0;
            f.paused = !0;
            f.began = !1;
            f.completed = !1;
            f.reversed = "reverse" === a;
            f.remaining = "alternate" === a && 1 === b ? 2 : b;
            for (a = f.children.length; a--; ) (b = f.children[a]), b.seek(b.offset), b.reset();
        };
        f.tick = function (a) {
            m = a;
            t || (t = m);
            h((k + m - t) * n.speed);
        };
        f.seek = function (a) {
            h(d(a));
        };
        f.pause = function () {
            var a = q.indexOf(f);
            -1 < a && q.splice(a, 1);
            f.paused = !0;
        };
        f.play = function () {
            f.paused && ((f.paused = !1), (t = 0), (k = d(f.currentTime)), q.push(f), z || ja());
        };
        f.reverse = function () {
            f.reversed = !f.reversed;
            t = 0;
            k = d(f.currentTime);
        };
        f.restart = function () {
            f.pause();
            f.reset();
            f.play();
        };
        f.finished = R;
        f.reset();
        f.autoplay && f.play();
        return f;
    }
    var ga = { update: void 0, begin: void 0, run: void 0, complete: void 0, loop: 1, direction: "normal", autoplay: !0, offset: 0 },
        ha = { duration: 1e3, delay: 0, easing: "easeOutElastic", elasticity: 500, round: 0 },
        V = "translateX translateY translateZ rotate rotateX rotateY rotateZ scale scaleX scaleY scaleZ skewX skewY".split(" "),
        E,
        g = {
            arr: function (a) {
                return Array.isArray(a);
            },
            obj: function (a) {
                return -1 < Object.prototype.toString.call(a).indexOf("Object");
            },
            svg: function (a) {
                return a instanceof SVGElement;
            },
            dom: function (a) {
                return a.nodeType || g.svg(a);
            },
            str: function (a) {
                return "string" === typeof a;
            },
            fnc: function (a) {
                return "function" === typeof a;
            },
            und: function (a) {
                return "undefined" === typeof a;
            },
            hex: function (a) {
                return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(a);
            },
            rgb: function (a) {
                return /^rgb/.test(a);
            },
            hsl: function (a) {
                return /^hsl/.test(a);
            },
            col: function (a) {
                return g.hex(a) || g.rgb(a) || g.hsl(a);
            },
        },
        y = (function () {
            function a(a, d, c) {
                return (((1 - 3 * c + 3 * d) * a + (3 * c - 6 * d)) * a + 3 * d) * a;
            }
            return function (b, d, c, e) {
                if (0 <= b && 1 >= b && 0 <= c && 1 >= c) {
                    var g = new Float32Array(11);
                    if (b !== d || c !== e) for (var h = 0; 11 > h; ++h) g[h] = a(0.1 * h, b, c);
                    return function (h) {
                        if (b === d && c === e) return h;
                        if (0 === h) return 0;
                        if (1 === h) return 1;
                        for (var m = 0, k = 1; 10 !== k && g[k] <= h; ++k) m += 0.1;
                        --k;
                        var k = m + ((h - g[k]) / (g[k + 1] - g[k])) * 0.1,
                            l = 3 * (1 - 3 * c + 3 * b) * k * k + 2 * (3 * c - 6 * b) * k + 3 * b;
                        if (0.001 <= l) {
                            for (m = 0; 4 > m; ++m) {
                                l = 3 * (1 - 3 * c + 3 * b) * k * k + 2 * (3 * c - 6 * b) * k + 3 * b;
                                if (0 === l) break;
                                var n = a(k, b, c) - h,
                                    k = k - n / l;
                            }
                            h = k;
                        } else if (0 === l) h = k;
                        else {
                            var k = m,
                                m = m + 0.1,
                                f = 0;
                            do (n = k + (m - k) / 2), (l = a(n, b, c) - h), 0 < l ? (m = n) : (k = n);
                            while (1e-7 < Math.abs(l) && 10 > ++f);
                            h = n;
                        }
                        return a(h, d, e);
                    };
                }
            };
        })(),
        N = (function () {
            function a(a, b) {
                return 0 === a || 1 === a ? a : -Math.pow(2, 10 * (a - 1)) * Math.sin((2 * (a - 1 - (b / (2 * Math.PI)) * Math.asin(1)) * Math.PI) / b);
            }
            var b = "Quad Cubic Quart Quint Sine Expo Circ Back Elastic".split(" "),
                d = {
                    In: [
                        [0.55, 0.085, 0.68, 0.53],
                        [0.55, 0.055, 0.675, 0.19],
                        [0.895, 0.03, 0.685, 0.22],
                        [0.755, 0.05, 0.855, 0.06],
                        [0.47, 0, 0.745, 0.715],
                        [0.95, 0.05, 0.795, 0.035],
                        [0.6, 0.04, 0.98, 0.335],
                        [0.6, -0.28, 0.735, 0.045],
                        a,
                    ],
                    Out: [
                        [0.25, 0.46, 0.45, 0.94],
                        [0.215, 0.61, 0.355, 1],
                        [0.165, 0.84, 0.44, 1],
                        [0.23, 1, 0.32, 1],
                        [0.39, 0.575, 0.565, 1],
                        [0.19, 1, 0.22, 1],
                        [0.075, 0.82, 0.165, 1],
                        [0.175, 0.885, 0.32, 1.275],
                        function (b, c) {
                            return 1 - a(1 - b, c);
                        },
                    ],
                    InOut: [
                        [0.455, 0.03, 0.515, 0.955],
                        [0.645, 0.045, 0.355, 1],
                        [0.77, 0, 0.175, 1],
                        [0.86, 0, 0.07, 1],
                        [0.445, 0.05, 0.55, 0.95],
                        [1, 0, 0, 1],
                        [0.785, 0.135, 0.15, 0.86],
                        [0.68, -0.55, 0.265, 1.55],
                        function (b, c) {
                            return 0.5 > b ? a(2 * b, c) / 2 : 1 - a(-2 * b + 2, c) / 2;
                        },
                    ],
                },
                c = { linear: y(0.25, 0.25, 0.75, 0.75) },
                e = {},
                l;
            for (l in d)
                (e.type = l),
                    d[e.type].forEach(
                        (function (a) {
                            return function (d, e) {
                                c["ease" + a.type + b[e]] = g.fnc(d) ? d : y.apply($jscomp$this, d);
                            };
                        })(e)
                    ),
                    (e = { type: e.type });
            return c;
        })(),
        ia = {
            css: function (a, b, d) {
                return (a.style[b] = d);
            },
            attribute: function (a, b, d) {
                return a.setAttribute(b, d);
            },
            object: function (a, b, d) {
                return (a[b] = d);
            },
            transform: function (a, b, d, c, e) {
                c[e] || (c[e] = []);
                c[e].push(b + "(" + d + ")");
            },
        },
        q = [],
        z = 0,
        ja = (function () {
            function a() {
                z = requestAnimationFrame(b);
            }
            function b(b) {
                var c = q.length;
                if (c) {
                    for (var d = 0; d < c; ) q[d] && q[d].tick(b), d++;
                    a();
                } else cancelAnimationFrame(z), (z = 0);
            }
            return a;
        })();
    n.version = "2.0.2";
    n.speed = 1;
    n.running = q;
    n.remove = function (a) {
        a = M(a);
        for (var b = q.length; b--; ) for (var d = q[b], c = d.animations, e = c.length; e--; ) F(a, c[e].animatable.target) && (c.splice(e, 1), c.length || d.pause());
    };
    n.getValue = J;
    n.path = function (a, b) {
        var d = g.str(a) ? v(a)[0] : a,
            c = b || 100;
        return function (a) {
            return { el: d, property: a, totalLength: d.getTotalLength() * (c / 100) };
        };
    };
    n.setDashoffset = function (a) {
        var b = a.getTotalLength();
        a.setAttribute("stroke-dasharray", b);
        return b;
    };
    n.bezier = y;
    n.easings = N;
    n.timeline = function (a) {
        var b = n(a);
        b.pause();
        b.duration = 0;
        b.add = function (a) {
            b.children.forEach(function (a) {
                a.began = !0;
                a.completed = !0;
            });
            w(a).forEach(function (a) {
                var c = b.duration,
                    d = a.offset;
                a.autoplay = !1;
                a.offset = g.und(d) ? c : K(d, c);
                b.seek(a.offset);
                a = n(a);
                a.duration > c && (b.duration = a.duration);
                a.began = !0;
                b.children.push(a);
            });
            b.reset();
            b.seek(0);
            b.autoplay && b.restart();
            return b;
        };
        return b;
    };
    n.random = function (a, b) {
        return Math.floor(Math.random() * (b - a + 1)) + a;
    };
    return n;
});
/**
 * @license
 * Lodash (Custom Build) lodash.com/license | Underscore.js 1.8.3 underscorejs.org/LICENSE
 * Build: `lodash core -o ./dist/lodash.core.js`
 */
(function () {
    function n(n) {
        return H(n) && pn.call(n, "callee") && !yn.call(n, "callee");
    }
    function t(n, t) {
        return n.push.apply(n, t), n;
    }
    function r(n) {
        return function (t) {
            return null == t ? Z : t[n];
        };
    }
    function e(n, t, r, e, u) {
        return (
            u(n, function (n, u, o) {
                r = e ? ((e = false), n) : t(r, n, u, o);
            }),
            r
        );
    }
    function u(n, t) {
        return j(t, function (t) {
            return n[t];
        });
    }
    function o(n) {
        return n instanceof i ? n : new i(n);
    }
    function i(n, t) {
        (this.__wrapped__ = n), (this.__actions__ = []), (this.__chain__ = !!t);
    }
    function c(n, t, r) {
        if (typeof n != "function") throw new TypeError("Expected a function");
        return setTimeout(function () {
            n.apply(Z, r);
        }, t);
    }
    function f(n, t) {
        var r = true;
        return (
            mn(n, function (n, e, u) {
                return (r = !!t(n, e, u));
            }),
            r
        );
    }
    function a(n, t, r) {
        for (var e = -1, u = n.length; ++e < u; ) {
            var o = n[e],
                i = t(o);
            if (null != i && (c === Z ? i === i : r(i, c)))
                var c = i,
                    f = o;
        }
        return f;
    }
    function l(n, t) {
        var r = [];
        return (
            mn(n, function (n, e, u) {
                t(n, e, u) && r.push(n);
            }),
            r
        );
    }
    function p(n, r, e, u, o) {
        var i = -1,
            c = n.length;
        for (e || (e = R), o || (o = []); ++i < c; ) {
            var f = n[i];
            0 < r && e(f) ? (1 < r ? p(f, r - 1, e, u, o) : t(o, f)) : u || (o[o.length] = f);
        }
        return o;
    }
    function s(n, t) {
        return n && On(n, t, Dn);
    }
    function h(n, t) {
        return l(t, function (t) {
            return U(n[t]);
        });
    }
    function v(n, t) {
        return n > t;
    }
    function b(n, t, r, e, u) {
        return n === t || (null == n || null == t || (!H(n) && !H(t)) ? n !== n && t !== t : y(n, t, r, e, b, u));
    }
    function y(n, t, r, e, u, o) {
        var i = Nn(n),
            c = Nn(t),
            f = i ? "[object Array]" : hn.call(n),
            a = c ? "[object Array]" : hn.call(t),
            f = "[object Arguments]" == f ? "[object Object]" : f,
            a = "[object Arguments]" == a ? "[object Object]" : a,
            l = "[object Object]" == f,
            c = "[object Object]" == a,
            a = f == a;
        o || (o = []);
        var p = An(o, function (t) {
                return t[0] == n;
            }),
            s = An(o, function (n) {
                return n[0] == t;
            });
        if (p && s) return p[1] == t;
        if ((o.push([n, t]), o.push([t, n]), a && !l)) {
            if (i) r = T(n, t, r, e, u, o);
            else
                n: {
                    switch (f) {
                        case "[object Boolean]":
                        case "[object Date]":
                        case "[object Number]":
                            r = J(+n, +t);
                            break n;
                        case "[object Error]":
                            r = n.name == t.name && n.message == t.message;
                            break n;
                        case "[object RegExp]":
                        case "[object String]":
                            r = n == t + "";
                            break n;
                    }
                    r = false;
                }
            return o.pop(), r;
        }
        return 1 & r || ((i = l && pn.call(n, "__wrapped__")), (f = c && pn.call(t, "__wrapped__")), !i && !f)
            ? !!a && ((r = B(n, t, r, e, u, o)), o.pop(), r)
            : ((i = i ? n.value() : n), (f = f ? t.value() : t), (r = u(i, f, r, e, o)), o.pop(), r);
    }
    function g(n) {
        return typeof n == "function" ? n : null == n ? X : (typeof n == "object" ? d : r)(n);
    }
    function _(n, t) {
        return n < t;
    }
    function j(n, t) {
        var r = -1,
            e = M(n) ? Array(n.length) : [];
        return (
            mn(n, function (n, u, o) {
                e[++r] = t(n, u, o);
            }),
            e
        );
    }
    function d(n) {
        var t = _n(n);
        return function (r) {
            var e = t.length;
            if (null == r) return !e;
            for (r = Object(r); e--; ) {
                var u = t[e];
                if (!(u in r && b(n[u], r[u], 3))) return false;
            }
            return true;
        };
    }
    function m(n, t) {
        return (
            (n = Object(n)),
            C(
                t,
                function (t, r) {
                    return r in n && (t[r] = n[r]), t;
                },
                {}
            )
        );
    }
    function O(n) {
        return xn(I(n, void 0, X), n + "");
    }
    function x(n, t, r) {
        var e = -1,
            u = n.length;
        for (0 > t && (t = -t > u ? 0 : u + t), r = r > u ? u : r, 0 > r && (r += u), u = t > r ? 0 : (r - t) >>> 0, t >>>= 0, r = Array(u); ++e < u; ) r[e] = n[e + t];
        return r;
    }
    function A(n) {
        return x(n, 0, n.length);
    }
    function E(n, t) {
        var r;
        return (
            mn(n, function (n, e, u) {
                return (r = t(n, e, u)), !r;
            }),
            !!r
        );
    }
    function w(n, r) {
        return C(
            r,
            function (n, r) {
                return r.func.apply(r.thisArg, t([n], r.args));
            },
            n
        );
    }
    function k(n, t, r) {
        var e = !r;
        r || (r = {});
        for (var u = -1, o = t.length; ++u < o; ) {
            var i = t[u],
                c = Z;
            if ((c === Z && (c = n[i]), e)) r[i] = c;
            else {
                var f = r,
                    a = f[i];
                (pn.call(f, i) && J(a, c) && (c !== Z || i in f)) || (f[i] = c);
            }
        }
        return r;
    }
    function N(n) {
        return O(function (t, r) {
            var e = -1,
                u = r.length,
                o = 1 < u ? r[u - 1] : Z,
                o = 3 < n.length && typeof o == "function" ? (u--, o) : Z;
            for (t = Object(t); ++e < u; ) {
                var i = r[e];
                i && n(t, i, e, o);
            }
            return t;
        });
    }
    function F(n) {
        return function () {
            var t = arguments,
                r = dn(n.prototype),
                t = n.apply(r, t);
            return V(t) ? t : r;
        };
    }
    function S(n, t, r) {
        function e() {
            for (var o = -1, i = arguments.length, c = -1, f = r.length, a = Array(f + i), l = this && this !== on && this instanceof e ? u : n; ++c < f; ) a[c] = r[c];
            for (; i--; ) a[c++] = arguments[++o];
            return l.apply(t, a);
        }
        if (typeof n != "function") throw new TypeError("Expected a function");
        var u = F(n);
        return e;
    }
    function T(n, t, r, e, u, o) {
        var i = n.length,
            c = t.length;
        if (i != c && !(1 & r && c > i)) return false;
        for (var c = -1, f = true, a = 2 & r ? [] : Z; ++c < i; ) {
            var l = n[c],
                p = t[c];
            if (void 0 !== Z) {
                f = false;
                break;
            }
            if (a) {
                if (
                    !E(t, function (n, t) {
                        if (!P(a, t) && (l === n || u(l, n, r, e, o))) return a.push(t);
                    })
                ) {
                    f = false;
                    break;
                }
            } else if (l !== p && !u(l, p, r, e, o)) {
                f = false;
                break;
            }
        }
        return f;
    }
    function B(n, t, r, e, u, o) {
        var i = 1 & r,
            c = Dn(n),
            f = c.length,
            a = Dn(t).length;
        if (f != a && !i) return false;
        for (var l = f; l--; ) {
            var p = c[l];
            if (!(i ? p in t : pn.call(t, p))) return false;
        }
        for (a = true; ++l < f; ) {
            var p = c[l],
                s = n[p],
                h = t[p];
            if (void 0 !== Z || (s !== h && !u(s, h, r, e, o))) {
                a = false;
                break;
            }
            i || (i = "constructor" == p);
        }
        return a && !i && ((r = n.constructor), (e = t.constructor), r != e && "constructor" in n && "constructor" in t && !(typeof r == "function" && r instanceof r && typeof e == "function" && e instanceof e) && (a = false)), a;
    }
    function R(t) {
        return Nn(t) || n(t);
    }
    function D(n) {
        var t = [];
        if (null != n) for (var r in Object(n)) t.push(r);
        return t;
    }
    function I(n, t, r) {
        return (
            (t = jn(t === Z ? n.length - 1 : t, 0)),
            function () {
                for (var e = arguments, u = -1, o = jn(e.length - t, 0), i = Array(o); ++u < o; ) i[u] = e[t + u];
                for (u = -1, o = Array(t + 1); ++u < t; ) o[u] = e[u];
                return (o[t] = r(i)), n.apply(this, o);
            }
        );
    }
    function $(n) {
        return (null == n ? 0 : n.length) ? p(n, 1) : [];
    }
    function q(n) {
        return n && n.length ? n[0] : Z;
    }
    function P(n, t, r) {
        var e = null == n ? 0 : n.length;
        (r = typeof r == "number" ? (0 > r ? jn(e + r, 0) : r) : 0), (r = (r || 0) - 1);
        for (var u = t === t; ++r < e; ) {
            var o = n[r];
            if (u ? o === t : o !== o) return r;
        }
        return -1;
    }
    function z(n, t) {
        return mn(n, g(t));
    }
    function C(n, t, r) {
        return e(n, g(t), r, 3 > arguments.length, mn);
    }
    function G(n, t) {
        var r;
        if (typeof t != "function") throw new TypeError("Expected a function");
        return (
            (n = Fn(n)),
            function () {
                return 0 < --n && (r = t.apply(this, arguments)), 1 >= n && (t = Z), r;
            }
        );
    }
    function J(n, t) {
        return n === t || (n !== n && t !== t);
    }
    function M(n) {
        var t;
        return (t = null != n) && ((t = n.length), (t = typeof t == "number" && -1 < t && 0 == t % 1 && 9007199254740991 >= t)), t && !U(n);
    }
    function U(n) {
        return !!V(n) && ((n = hn.call(n)), "[object Function]" == n || "[object GeneratorFunction]" == n || "[object AsyncFunction]" == n || "[object Proxy]" == n);
    }
    function V(n) {
        var t = typeof n;
        return null != n && ("object" == t || "function" == t);
    }
    function H(n) {
        return null != n && typeof n == "object";
    }
    function K(n) {
        return typeof n == "number" || (H(n) && "[object Number]" == hn.call(n));
    }
    function L(n) {
        return typeof n == "string" || (!Nn(n) && H(n) && "[object String]" == hn.call(n));
    }
    function Q(n) {
        return typeof n == "string" ? n : null == n ? "" : n + "";
    }
    function W(n) {
        return null == n ? [] : u(n, Dn(n));
    }
    function X(n) {
        return n;
    }
    function Y(n, r, e) {
        var u = Dn(r),
            o = h(r, u);
        null != e || (V(r) && (o.length || !u.length)) || ((e = r), (r = n), (n = this), (o = h(r, Dn(r))));
        var i = !(V(e) && "chain" in e && !e.chain),
            c = U(n);
        return (
            mn(o, function (e) {
                var u = r[e];
                (n[e] = u),
                    c &&
                        (n.prototype[e] = function () {
                            var r = this.__chain__;
                            if (i || r) {
                                var e = n(this.__wrapped__);
                                return (e.__actions__ = A(this.__actions__)).push({ func: u, args: arguments, thisArg: n }), (e.__chain__ = r), e;
                            }
                            return u.apply(n, t([this.value()], arguments));
                        });
            }),
            n
        );
    }
    var Z,
        nn = 1 / 0,
        tn = /[&<>"']/g,
        rn = RegExp(tn.source),
        en = /^(?:0|[1-9]\d*)$/,
        un = typeof self == "object" && self && self.Object === Object && self,
        on = (typeof global == "object" && global && global.Object === Object && global) || un || Function("return this")(),
        cn = (un = typeof exports == "object" && exports && !exports.nodeType && exports) && typeof module == "object" && module && !module.nodeType && module,
        fn = (function (n) {
            return function (t) {
                return null == n ? Z : n[t];
            };
        })({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }),
        an = Array.prototype,
        ln = Object.prototype,
        pn = ln.hasOwnProperty,
        sn = 0,
        hn = ln.toString,
        vn = on._,
        bn = Object.create,
        yn = ln.propertyIsEnumerable,
        gn = on.isFinite,
        _n = (function (n, t) {
            return function (r) {
                return n(t(r));
            };
        })(Object.keys, Object),
        jn = Math.max,
        dn = (function () {
            function n() {}
            return function (t) {
                return V(t) ? (bn ? bn(t) : ((n.prototype = t), (t = new n()), (n.prototype = Z), t)) : {};
            };
        })();
    (i.prototype = dn(o.prototype)), (i.prototype.constructor = i);
    var mn = (function (n, t) {
            return function (r, e) {
                if (null == r) return r;
                if (!M(r)) return n(r, e);
                for (var u = r.length, o = t ? u : -1, i = Object(r); (t ? o-- : ++o < u) && false !== e(i[o], o, i); );
                return r;
            };
        })(s),
        On = (function (n) {
            return function (t, r, e) {
                var u = -1,
                    o = Object(t);
                e = e(t);
                for (var i = e.length; i--; ) {
                    var c = e[n ? i : ++u];
                    if (false === r(o[c], c, o)) break;
                }
                return t;
            };
        })(),
        xn = X,
        An = (function (n) {
            return function (t, r, e) {
                var u = Object(t);
                if (!M(t)) {
                    var o = g(r);
                    (t = Dn(t)),
                        (r = function (n) {
                            return o(u[n], n, u);
                        });
                }
                return (r = n(t, r, e)), -1 < r ? u[o ? t[r] : r] : Z;
            };
        })(function (n, t, r) {
            var e = null == n ? 0 : n.length;
            if (!e) return -1;
            (r = null == r ? 0 : Fn(r)), 0 > r && (r = jn(e + r, 0));
            n: {
                for (t = g(t), e = n.length, r += -1; ++r < e; )
                    if (t(n[r], r, n)) {
                        n = r;
                        break n;
                    }
                n = -1;
            }
            return n;
        }),
        En = O(function (n, t, r) {
            return S(n, t, r);
        }),
        wn = O(function (n, t) {
            return c(n, 1, t);
        }),
        kn = O(function (n, t, r) {
            return c(n, Sn(t) || 0, r);
        }),
        Nn = Array.isArray,
        Fn = Number,
        Sn = Number,
        Tn = N(function (n, t) {
            k(t, _n(t), n);
        }),
        Bn = N(function (n, t) {
            k(t, D(t), n);
        }),
        Rn = O(function (n, t) {
            n = Object(n);
            var r,
                e = -1,
                u = t.length,
                o = 2 < u ? t[2] : Z;
            if ((r = o)) {
                r = t[0];
                var i = t[1];
                if (V(o)) {
                    var c = typeof i;
                    if ("number" == c) {
                        if ((c = M(o)))
                            var c = o.length,
                                f = typeof i,
                                c = null == c ? 9007199254740991 : c,
                                c = !!c && ("number" == f || ("symbol" != f && en.test(i))) && -1 < i && 0 == i % 1 && i < c;
                    } else c = "string" == c && i in o;
                    r = !!c && J(o[i], r);
                } else r = false;
            }
            for (r && (u = 1); ++e < u; )
                for (o = t[e], r = In(o), i = -1, c = r.length; ++i < c; ) {
                    var f = r[i],
                        a = n[f];
                    (a === Z || (J(a, ln[f]) && !pn.call(n, f))) && (n[f] = o[f]);
                }
            return n;
        }),
        Dn = _n,
        In = D,
        $n = (function (n) {
            return xn(I(n, Z, $), n + "");
        })(function (n, t) {
            return null == n ? {} : m(n, t);
        });
    (o.assignIn = Bn),
        (o.before = G),
        (o.bind = En),
        (o.chain = function (n) {
            return (n = o(n)), (n.__chain__ = true), n;
        }),
        (o.compact = function (n) {
            return l(n, Boolean);
        }),
        (o.concat = function () {
            var n = arguments.length;
            if (!n) return [];
            for (var r = Array(n - 1), e = arguments[0]; n--; ) r[n - 1] = arguments[n];
            return t(Nn(e) ? A(e) : [e], p(r, 1));
        }),
        (o.create = function (n, t) {
            var r = dn(n);
            return null == t ? r : Tn(r, t);
        }),
        (o.defaults = Rn),
        (o.defer = wn),
        (o.delay = kn),
        (o.filter = function (n, t) {
            return l(n, g(t));
        }),
        (o.flatten = $),
        (o.flattenDeep = function (n) {
            return (null == n ? 0 : n.length) ? p(n, nn) : [];
        }),
        (o.iteratee = g),
        (o.keys = Dn),
        (o.map = function (n, t) {
            return j(n, g(t));
        }),
        (o.matches = function (n) {
            return d(Tn({}, n));
        }),
        (o.mixin = Y),
        (o.negate = function (n) {
            if (typeof n != "function") throw new TypeError("Expected a function");
            return function () {
                return !n.apply(this, arguments);
            };
        }),
        (o.once = function (n) {
            return G(2, n);
        }),
        (o.pick = $n),
        (o.slice = function (n, t, r) {
            var e = null == n ? 0 : n.length;
            return (r = r === Z ? e : +r), e ? x(n, null == t ? 0 : +t, r) : [];
        }),
        (o.sortBy = function (n, t) {
            var e = 0;
            return (
                (t = g(t)),
                j(
                    j(n, function (n, r, u) {
                        return { value: n, index: e++, criteria: t(n, r, u) };
                    }).sort(function (n, t) {
                        var r;
                        n: {
                            r = n.criteria;
                            var e = t.criteria;
                            if (r !== e) {
                                var u = r !== Z,
                                    o = null === r,
                                    i = r === r,
                                    c = e !== Z,
                                    f = null === e,
                                    a = e === e;
                                if ((!f && r > e) || (o && c && a) || (!u && a) || !i) {
                                    r = 1;
                                    break n;
                                }
                                if ((!o && r < e) || (f && u && i) || (!c && i) || !a) {
                                    r = -1;
                                    break n;
                                }
                            }
                            r = 0;
                        }
                        return r || n.index - t.index;
                    }),
                    r("value")
                )
            );
        }),
        (o.tap = function (n, t) {
            return t(n), n;
        }),
        (o.thru = function (n, t) {
            return t(n);
        }),
        (o.toArray = function (n) {
            return M(n) ? (n.length ? A(n) : []) : W(n);
        }),
        (o.values = W),
        (o.extend = Bn),
        Y(o, o),
        (o.clone = function (n) {
            return V(n) ? (Nn(n) ? A(n) : k(n, _n(n))) : n;
        }),
        (o.escape = function (n) {
            return (n = Q(n)) && rn.test(n) ? n.replace(tn, fn) : n;
        }),
        (o.every = function (n, t, r) {
            return (t = r ? Z : t), f(n, g(t));
        }),
        (o.find = An),
        (o.forEach = z),
        (o.has = function (n, t) {
            return null != n && pn.call(n, t);
        }),
        (o.head = q),
        (o.identity = X),
        (o.indexOf = P),
        (o.isArguments = n),
        (o.isArray = Nn),
        (o.isBoolean = function (n) {
            return true === n || false === n || (H(n) && "[object Boolean]" == hn.call(n));
        }),
        (o.isDate = function (n) {
            return H(n) && "[object Date]" == hn.call(n);
        }),
        (o.isEmpty = function (t) {
            return M(t) && (Nn(t) || L(t) || U(t.splice) || n(t)) ? !t.length : !_n(t).length;
        }),
        (o.isEqual = function (n, t) {
            return b(n, t);
        }),
        (o.isFinite = function (n) {
            return typeof n == "number" && gn(n);
        }),
        (o.isFunction = U),
        (o.isNaN = function (n) {
            return K(n) && n != +n;
        }),
        (o.isNull = function (n) {
            return null === n;
        }),
        (o.isNumber = K),
        (o.isObject = V),
        (o.isRegExp = function (n) {
            return H(n) && "[object RegExp]" == hn.call(n);
        }),
        (o.isString = L),
        (o.isUndefined = function (n) {
            return n === Z;
        }),
        (o.last = function (n) {
            var t = null == n ? 0 : n.length;
            return t ? n[t - 1] : Z;
        }),
        (o.max = function (n) {
            return n && n.length ? a(n, X, v) : Z;
        }),
        (o.min = function (n) {
            return n && n.length ? a(n, X, _) : Z;
        }),
        (o.noConflict = function () {
            return on._ === this && (on._ = vn), this;
        }),
        (o.noop = function () {}),
        (o.reduce = C),
        (o.result = function (n, t, r) {
            return (t = null == n ? Z : n[t]), t === Z && (t = r), U(t) ? t.call(n) : t;
        }),
        (o.size = function (n) {
            return null == n ? 0 : ((n = M(n) ? n : _n(n)), n.length);
        }),
        (o.some = function (n, t, r) {
            return (t = r ? Z : t), E(n, g(t));
        }),
        (o.uniqueId = function (n) {
            var t = ++sn;
            return Q(n) + t;
        }),
        (o.each = z),
        (o.first = q),
        Y(
            o,
            (function () {
                var n = {};
                return (
                    s(o, function (t, r) {
                        pn.call(o.prototype, r) || (n[r] = t);
                    }),
                    n
                );
            })(),
            { chain: false }
        ),
        (o.VERSION = "4.17.10"),
        mn("pop join replace reverse split push shift sort splice unshift".split(" "), function (n) {
            var t = (/^(?:replace|split)$/.test(n) ? String.prototype : an)[n],
                r = /^(?:push|sort|unshift)$/.test(n) ? "tap" : "thru",
                e = /^(?:pop|join|replace|shift)$/.test(n);
            o.prototype[n] = function () {
                var n = arguments;
                if (e && !this.__chain__) {
                    var u = this.value();
                    return t.apply(Nn(u) ? u : [], n);
                }
                return this[r](function (r) {
                    return t.apply(Nn(r) ? r : [], n);
                });
            };
        }),
        (o.prototype.toJSON = o.prototype.valueOf = o.prototype.value = function () {
            return w(this.__wrapped__, this.__actions__);
        }),
        typeof define == "function" && typeof define.amd == "object" && define.amd
            ? ((on._ = o),
              define(function () {
                  return o;
              }))
            : cn
            ? (((cn.exports = o)._ = o), (un._ = o))
            : (on._ = o);
}.call(this));
